(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require2() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // node_modules/@capacitor/core/dist/index.js
  var ExceptionCode, CapacitorException, getPlatformId, createCapacitor, initCapacitorGlobal, Capacitor, registerPlugin, WebPlugin, encode, decode, CapacitorCookiesPluginWeb, CapacitorCookies, readBlobAsBase64, normalizeHttpHeaders, buildUrlParams, buildRequestInit, CapacitorHttpPluginWeb, CapacitorHttp, SystemBarsStyle, SystemBarType, SystemBarsPluginWeb, SystemBars;
  var init_dist = __esm({
    "node_modules/@capacitor/core/dist/index.js"() {
      (function(ExceptionCode2) {
        ExceptionCode2["Unimplemented"] = "UNIMPLEMENTED";
        ExceptionCode2["Unavailable"] = "UNAVAILABLE";
      })(ExceptionCode || (ExceptionCode = {}));
      CapacitorException = class extends Error {
        constructor(message, code, data) {
          super(message);
          this.message = message;
          this.code = code;
          this.data = data;
        }
      };
      getPlatformId = (win) => {
        var _a, _b;
        if (win === null || win === void 0 ? void 0 : win.androidBridge) {
          return "android";
        } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
          return "ios";
        } else {
          return "web";
        }
      };
      createCapacitor = (win) => {
        const capCustomPlatform = win.CapacitorCustomPlatform || null;
        const cap = win.Capacitor || {};
        const Plugins = cap.Plugins = cap.Plugins || {};
        const getPlatform = () => {
          return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
        };
        const isNativePlatform = () => getPlatform() !== "web";
        const isPluginAvailable = (pluginName) => {
          const plugin = registeredPlugins.get(pluginName);
          if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
            return true;
          }
          if (getPluginHeader(pluginName)) {
            return true;
          }
          return false;
        };
        const getPluginHeader = (pluginName) => {
          var _a;
          return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
        };
        const handleError = (err) => win.console.error(err);
        const registeredPlugins = /* @__PURE__ */ new Map();
        const registerPlugin2 = (pluginName, jsImplementations = {}) => {
          const registeredPlugin = registeredPlugins.get(pluginName);
          if (registeredPlugin) {
            console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
            return registeredPlugin.proxy;
          }
          const platform = getPlatform();
          const pluginHeader = getPluginHeader(pluginName);
          let jsImplementation;
          const loadPluginImplementation = async () => {
            if (!jsImplementation && platform in jsImplementations) {
              jsImplementation = typeof jsImplementations[platform] === "function" ? jsImplementation = await jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
            } else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) {
              jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
            }
            return jsImplementation;
          };
          const createPluginMethod = (impl, prop) => {
            var _a, _b;
            if (pluginHeader) {
              const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
              if (methodHeader) {
                if (methodHeader.rtype === "promise") {
                  return (options) => cap.nativePromise(pluginName, prop.toString(), options);
                } else {
                  return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
                }
              } else if (impl) {
                return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
              }
            } else if (impl) {
              return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
            } else {
              throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
            }
          };
          const createPluginMethodWrapper = (prop) => {
            let remove;
            const wrapper = (...args) => {
              const p = loadPluginImplementation().then((impl) => {
                const fn = createPluginMethod(impl, prop);
                if (fn) {
                  const p2 = fn(...args);
                  remove = p2 === null || p2 === void 0 ? void 0 : p2.remove;
                  return p2;
                } else {
                  throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
                }
              });
              if (prop === "addListener") {
                p.remove = async () => remove();
              }
              return p;
            };
            wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
            Object.defineProperty(wrapper, "name", {
              value: prop,
              writable: false,
              configurable: false
            });
            return wrapper;
          };
          const addListener = createPluginMethodWrapper("addListener");
          const removeListener = createPluginMethodWrapper("removeListener");
          const addListenerNative = (eventName, callback) => {
            const call = addListener({ eventName }, callback);
            const remove = async () => {
              const callbackId = await call;
              removeListener({
                eventName,
                callbackId
              }, callback);
            };
            const p = new Promise((resolve2) => call.then(() => resolve2({ remove })));
            p.remove = async () => {
              console.warn(`Using addListener() without 'await' is deprecated.`);
              await remove();
            };
            return p;
          };
          const proxy = new Proxy({}, {
            get(_, prop) {
              switch (prop) {
                // https://github.com/facebook/react/issues/20030
                case "$$typeof":
                  return void 0;
                case "toJSON":
                  return () => ({});
                case "addListener":
                  return pluginHeader ? addListenerNative : addListener;
                case "removeListener":
                  return removeListener;
                default:
                  return createPluginMethodWrapper(prop);
              }
            }
          });
          Plugins[pluginName] = proxy;
          registeredPlugins.set(pluginName, {
            name: pluginName,
            proxy,
            platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform] : []])
          });
          return proxy;
        };
        if (!cap.convertFileSrc) {
          cap.convertFileSrc = (filePath) => filePath;
        }
        cap.getPlatform = getPlatform;
        cap.handleError = handleError;
        cap.isNativePlatform = isNativePlatform;
        cap.isPluginAvailable = isPluginAvailable;
        cap.registerPlugin = registerPlugin2;
        cap.Exception = CapacitorException;
        cap.DEBUG = !!cap.DEBUG;
        cap.isLoggingEnabled = !!cap.isLoggingEnabled;
        return cap;
      };
      initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
      Capacitor = /* @__PURE__ */ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
      registerPlugin = Capacitor.registerPlugin;
      WebPlugin = class {
        constructor() {
          this.listeners = {};
          this.retainedEventArguments = {};
          this.windowListeners = {};
        }
        addListener(eventName, listenerFunc) {
          let firstListener = false;
          const listeners = this.listeners[eventName];
          if (!listeners) {
            this.listeners[eventName] = [];
            firstListener = true;
          }
          this.listeners[eventName].push(listenerFunc);
          const windowListener = this.windowListeners[eventName];
          if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
          }
          if (firstListener) {
            this.sendRetainedArgumentsForEvent(eventName);
          }
          const remove = async () => this.removeListener(eventName, listenerFunc);
          const p = Promise.resolve({ remove });
          return p;
        }
        async removeAllListeners() {
          this.listeners = {};
          for (const listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
          }
          this.windowListeners = {};
        }
        notifyListeners(eventName, data, retainUntilConsumed) {
          const listeners = this.listeners[eventName];
          if (!listeners) {
            if (retainUntilConsumed) {
              let args = this.retainedEventArguments[eventName];
              if (!args) {
                args = [];
              }
              args.push(data);
              this.retainedEventArguments[eventName] = args;
            }
            return;
          }
          listeners.forEach((listener) => listener(data));
        }
        hasListeners(eventName) {
          var _a;
          return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
        }
        registerWindowListener(windowEventName, pluginEventName) {
          this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName,
            pluginEventName,
            handler: (event) => {
              this.notifyListeners(pluginEventName, event);
            }
          };
        }
        unimplemented(msg = "not implemented") {
          return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
        }
        unavailable(msg = "not available") {
          return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
        }
        async removeListener(eventName, listenerFunc) {
          const listeners = this.listeners[eventName];
          if (!listeners) {
            return;
          }
          const index = listeners.indexOf(listenerFunc);
          this.listeners[eventName].splice(index, 1);
          if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
          }
        }
        addWindowListener(handle) {
          window.addEventListener(handle.windowEventName, handle.handler);
          handle.registered = true;
        }
        removeWindowListener(handle) {
          if (!handle) {
            return;
          }
          window.removeEventListener(handle.windowEventName, handle.handler);
          handle.registered = false;
        }
        sendRetainedArgumentsForEvent(eventName) {
          const args = this.retainedEventArguments[eventName];
          if (!args) {
            return;
          }
          delete this.retainedEventArguments[eventName];
          args.forEach((arg) => {
            this.notifyListeners(eventName, arg);
          });
        }
      };
      encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
      decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
      CapacitorCookiesPluginWeb = class extends WebPlugin {
        async getCookies() {
          const cookies = document.cookie;
          const cookieMap = {};
          cookies.split(";").forEach((cookie) => {
            if (cookie.length <= 0)
              return;
            let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
            key = decode(key).trim();
            value = decode(value).trim();
            cookieMap[key] = value;
          });
          return cookieMap;
        }
        async setCookie(options) {
          try {
            const encodedKey = encode(options.key);
            const encodedValue = encode(options.value);
            const expires = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
            const path = (options.path || "/").replace("path=", "");
            const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
            document.cookie = `${encodedKey}=${encodedValue || ""}${expires}; path=${path}; ${domain};`;
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async deleteCookie(options) {
          try {
            document.cookie = `${options.key}=; Max-Age=0`;
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async clearCookies() {
          try {
            const cookies = document.cookie.split(";") || [];
            for (const cookie of cookies) {
              document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
            }
          } catch (error) {
            return Promise.reject(error);
          }
        }
        async clearAllCookies() {
          try {
            await this.clearCookies();
          } catch (error) {
            return Promise.reject(error);
          }
        }
      };
      CapacitorCookies = registerPlugin("CapacitorCookies", {
        web: () => new CapacitorCookiesPluginWeb()
      });
      readBlobAsBase64 = async (blob) => new Promise((resolve2, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const base64String = reader.result;
          resolve2(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
      });
      normalizeHttpHeaders = (headers = {}) => {
        const originalKeys = Object.keys(headers);
        const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
        const normalized = loweredKeys.reduce((acc, key, index) => {
          acc[key] = headers[originalKeys[index]];
          return acc;
        }, {});
        return normalized;
      };
      buildUrlParams = (params, shouldEncode = true) => {
        if (!params)
          return null;
        const output = Object.entries(params).reduce((accumulator, entry) => {
          const [key, value] = entry;
          let encodedValue;
          let item;
          if (Array.isArray(value)) {
            item = "";
            value.forEach((str) => {
              encodedValue = shouldEncode ? encodeURIComponent(str) : str;
              item += `${key}=${encodedValue}&`;
            });
            item.slice(0, -1);
          } else {
            encodedValue = shouldEncode ? encodeURIComponent(value) : value;
            item = `${key}=${encodedValue}`;
          }
          return `${accumulator}&${item}`;
        }, "");
        return output.substr(1);
      };
      buildRequestInit = (options, extra = {}) => {
        const output = Object.assign({ method: options.method || "GET", headers: options.headers }, extra);
        const headers = normalizeHttpHeaders(options.headers);
        const type = headers["content-type"] || "";
        if (typeof options.data === "string") {
          output.body = options.data;
        } else if (type.includes("application/x-www-form-urlencoded")) {
          const params = new URLSearchParams();
          for (const [key, value] of Object.entries(options.data || {})) {
            params.set(key, value);
          }
          output.body = params.toString();
        } else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
          const form = new FormData();
          if (options.data instanceof FormData) {
            options.data.forEach((value, key) => {
              form.append(key, value);
            });
          } else {
            for (const key of Object.keys(options.data)) {
              form.append(key, options.data[key]);
            }
          }
          output.body = form;
          const headers2 = new Headers(output.headers);
          headers2.delete("content-type");
          output.headers = headers2;
        } else if (type.includes("application/json") || typeof options.data === "object") {
          output.body = JSON.stringify(options.data);
        }
        return output;
      };
      CapacitorHttpPluginWeb = class extends WebPlugin {
        /**
         * Perform an Http request given a set of options
         * @param options Options to build the HTTP request
         */
        async request(options) {
          const requestInit = buildRequestInit(options, options.webFetchExtra);
          const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
          const url = urlParams ? `${options.url}?${urlParams}` : options.url;
          const response = await fetch(url, requestInit);
          const contentType = response.headers.get("content-type") || "";
          let { responseType = "text" } = response.ok ? options : {};
          if (contentType.includes("application/json")) {
            responseType = "json";
          }
          let data;
          let blob;
          switch (responseType) {
            case "arraybuffer":
            case "blob":
              blob = await response.blob();
              data = await readBlobAsBase64(blob);
              break;
            case "json":
              data = await response.json();
              break;
            case "document":
            case "text":
            default:
              data = await response.text();
          }
          const headers = {};
          response.headers.forEach((value, key) => {
            headers[key] = value;
          });
          return {
            data,
            headers,
            status: response.status,
            url: response.url
          };
        }
        /**
         * Perform an Http GET request given a set of options
         * @param options Options to build the HTTP request
         */
        async get(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
        }
        /**
         * Perform an Http POST request given a set of options
         * @param options Options to build the HTTP request
         */
        async post(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
        }
        /**
         * Perform an Http PUT request given a set of options
         * @param options Options to build the HTTP request
         */
        async put(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
        }
        /**
         * Perform an Http PATCH request given a set of options
         * @param options Options to build the HTTP request
         */
        async patch(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
        }
        /**
         * Perform an Http DELETE request given a set of options
         * @param options Options to build the HTTP request
         */
        async delete(options) {
          return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
        }
      };
      CapacitorHttp = registerPlugin("CapacitorHttp", {
        web: () => new CapacitorHttpPluginWeb()
      });
      (function(SystemBarsStyle2) {
        SystemBarsStyle2["Dark"] = "DARK";
        SystemBarsStyle2["Light"] = "LIGHT";
        SystemBarsStyle2["Default"] = "DEFAULT";
      })(SystemBarsStyle || (SystemBarsStyle = {}));
      (function(SystemBarType2) {
        SystemBarType2["StatusBar"] = "StatusBar";
        SystemBarType2["NavigationBar"] = "NavigationBar";
      })(SystemBarType || (SystemBarType = {}));
      SystemBarsPluginWeb = class extends WebPlugin {
        async setStyle() {
          this.unavailable("not available for web");
        }
        async setAnimation() {
          this.unavailable("not available for web");
        }
        async show() {
          this.unavailable("not available for web");
        }
        async hide() {
          this.unavailable("not available for web");
        }
      };
      SystemBars = registerPlugin("SystemBars", {
        web: () => new SystemBarsPluginWeb()
      });
    }
  });

  // node_modules/@capacitor/share/dist/esm/definitions.js
  var init_definitions = __esm({
    "node_modules/@capacitor/share/dist/esm/definitions.js"() {
    }
  });

  // node_modules/@capacitor/share/dist/esm/web.js
  var web_exports = {};
  __export(web_exports, {
    ShareWeb: () => ShareWeb
  });
  var ShareWeb;
  var init_web = __esm({
    "node_modules/@capacitor/share/dist/esm/web.js"() {
      init_dist();
      ShareWeb = class extends WebPlugin {
        async canShare() {
          if (typeof navigator === "undefined" || !navigator.share) {
            return { value: false };
          } else {
            return { value: true };
          }
        }
        async share(options) {
          if (typeof navigator === "undefined" || !navigator.share) {
            throw this.unavailable("Share API not available in this browser");
          }
          await navigator.share({
            title: options.title,
            text: options.text,
            url: options.url
          });
          return {};
        }
      };
    }
  });

  // node_modules/@capacitor/share/dist/esm/index.js
  var Share;
  var init_esm = __esm({
    "node_modules/@capacitor/share/dist/esm/index.js"() {
      init_dist();
      init_definitions();
      Share = registerPlugin("Share", {
        web: () => Promise.resolve().then(() => (init_web(), web_exports)).then((m) => new m.ShareWeb())
      });
    }
  });

  // node_modules/@capacitor/synapse/dist/synapse.mjs
  function s(t) {
    t.CapacitorUtils.Synapse = new Proxy(
      {},
      {
        get(e, n) {
          return new Proxy({}, {
            get(w, o) {
              return (c, p, r) => {
                const i = t.Capacitor.Plugins[n];
                if (i === void 0) {
                  r(new Error(`Capacitor plugin ${n} not found`));
                  return;
                }
                if (typeof i[o] != "function") {
                  r(new Error(`Method ${o} not found in Capacitor plugin ${n}`));
                  return;
                }
                (async () => {
                  try {
                    const a = await i[o](c);
                    p(a);
                  } catch (a) {
                    r(a);
                  }
                })();
              };
            }
          });
        }
      }
    );
  }
  function u(t) {
    t.CapacitorUtils.Synapse = new Proxy(
      {},
      {
        get(e, n) {
          return t.cordova.plugins[n];
        }
      }
    );
  }
  function f(t = false) {
    typeof window > "u" || (window.CapacitorUtils = window.CapacitorUtils || {}, window.Capacitor !== void 0 && !t ? s(window) : window.cordova !== void 0 && u(window));
  }
  var init_synapse = __esm({
    "node_modules/@capacitor/synapse/dist/synapse.mjs"() {
    }
  });

  // node_modules/@capacitor/filesystem/dist/esm/definitions.js
  var Directory, Encoding;
  var init_definitions2 = __esm({
    "node_modules/@capacitor/filesystem/dist/esm/definitions.js"() {
      (function(Directory2) {
        Directory2["Documents"] = "DOCUMENTS";
        Directory2["Data"] = "DATA";
        Directory2["Library"] = "LIBRARY";
        Directory2["Cache"] = "CACHE";
        Directory2["External"] = "EXTERNAL";
        Directory2["ExternalStorage"] = "EXTERNAL_STORAGE";
        Directory2["ExternalCache"] = "EXTERNAL_CACHE";
        Directory2["LibraryNoCloud"] = "LIBRARY_NO_CLOUD";
        Directory2["Temporary"] = "TEMPORARY";
      })(Directory || (Directory = {}));
      (function(Encoding2) {
        Encoding2["UTF8"] = "utf8";
        Encoding2["ASCII"] = "ascii";
        Encoding2["UTF16"] = "utf16";
      })(Encoding || (Encoding = {}));
    }
  });

  // node_modules/@capacitor/filesystem/dist/esm/web.js
  var web_exports2 = {};
  __export(web_exports2, {
    FilesystemWeb: () => FilesystemWeb
  });
  function resolve(path) {
    const posix = path.split("/").filter((item) => item !== ".");
    const newPosix = [];
    posix.forEach((item) => {
      if (item === ".." && newPosix.length > 0 && newPosix[newPosix.length - 1] !== "..") {
        newPosix.pop();
      } else {
        newPosix.push(item);
      }
    });
    return newPosix.join("/");
  }
  function isPathParent(parent, children) {
    parent = resolve(parent);
    children = resolve(children);
    const pathsA = parent.split("/");
    const pathsB = children.split("/");
    return parent !== children && pathsA.every((value, index) => value === pathsB[index]);
  }
  var FilesystemWeb;
  var init_web2 = __esm({
    "node_modules/@capacitor/filesystem/dist/esm/web.js"() {
      init_dist();
      init_definitions2();
      FilesystemWeb = class _FilesystemWeb extends WebPlugin {
        constructor() {
          super(...arguments);
          this.DB_VERSION = 1;
          this.DB_NAME = "Disc";
          this._writeCmds = ["add", "put", "delete"];
          this.downloadFile = async (options) => {
            var _a, _b;
            const requestInit = buildRequestInit(options, options.webFetchExtra);
            const response = await fetch(options.url, requestInit);
            let blob;
            if (!options.progress)
              blob = await response.blob();
            else if (!(response === null || response === void 0 ? void 0 : response.body))
              blob = new Blob();
            else {
              const reader = response.body.getReader();
              let bytes = 0;
              const chunks = [];
              const contentType = response.headers.get("content-type");
              const contentLength = parseInt(response.headers.get("content-length") || "0", 10);
              while (true) {
                const { done, value } = await reader.read();
                if (done)
                  break;
                chunks.push(value);
                bytes += (value === null || value === void 0 ? void 0 : value.length) || 0;
                const status = {
                  url: options.url,
                  bytes,
                  contentLength
                };
                this.notifyListeners("progress", status);
              }
              const allChunks = new Uint8Array(bytes);
              let position = 0;
              for (const chunk of chunks) {
                if (typeof chunk === "undefined")
                  continue;
                allChunks.set(chunk, position);
                position += chunk.length;
              }
              blob = new Blob([allChunks.buffer], { type: contentType || void 0 });
            }
            const result = await this.writeFile({
              path: options.path,
              directory: (_a = options.directory) !== null && _a !== void 0 ? _a : void 0,
              recursive: (_b = options.recursive) !== null && _b !== void 0 ? _b : false,
              data: blob
            });
            return { path: result.uri, blob };
          };
        }
        readFileInChunks(_options, _callback) {
          throw this.unavailable("Method not implemented.");
        }
        async initDb() {
          if (this._db !== void 0) {
            return this._db;
          }
          if (!("indexedDB" in window)) {
            throw this.unavailable("This browser doesn't support IndexedDB");
          }
          return new Promise((resolve2, reject) => {
            const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
            request.onupgradeneeded = _FilesystemWeb.doUpgrade;
            request.onsuccess = () => {
              this._db = request.result;
              resolve2(request.result);
            };
            request.onerror = () => reject(request.error);
            request.onblocked = () => {
              console.warn("db blocked");
            };
          });
        }
        static doUpgrade(event) {
          const eventTarget = event.target;
          const db = eventTarget.result;
          switch (event.oldVersion) {
            case 0:
            case 1:
            default: {
              if (db.objectStoreNames.contains("FileStorage")) {
                db.deleteObjectStore("FileStorage");
              }
              const store = db.createObjectStore("FileStorage", { keyPath: "path" });
              store.createIndex("by_folder", "folder");
            }
          }
        }
        async dbRequest(cmd, args) {
          const readFlag = this._writeCmds.indexOf(cmd) !== -1 ? "readwrite" : "readonly";
          return this.initDb().then((conn) => {
            return new Promise((resolve2, reject) => {
              const tx = conn.transaction(["FileStorage"], readFlag);
              const store = tx.objectStore("FileStorage");
              const req = store[cmd](...args);
              req.onsuccess = () => resolve2(req.result);
              req.onerror = () => reject(req.error);
            });
          });
        }
        async dbIndexRequest(indexName, cmd, args) {
          const readFlag = this._writeCmds.indexOf(cmd) !== -1 ? "readwrite" : "readonly";
          return this.initDb().then((conn) => {
            return new Promise((resolve2, reject) => {
              const tx = conn.transaction(["FileStorage"], readFlag);
              const store = tx.objectStore("FileStorage");
              const index = store.index(indexName);
              const req = index[cmd](...args);
              req.onsuccess = () => resolve2(req.result);
              req.onerror = () => reject(req.error);
            });
          });
        }
        getPath(directory, uriPath) {
          const cleanedUriPath = uriPath !== void 0 ? uriPath.replace(/^[/]+|[/]+$/g, "") : "";
          let fsPath = "";
          if (directory !== void 0)
            fsPath += "/" + directory;
          if (uriPath !== "")
            fsPath += "/" + cleanedUriPath;
          return fsPath;
        }
        async clear() {
          const conn = await this.initDb();
          const tx = conn.transaction(["FileStorage"], "readwrite");
          const store = tx.objectStore("FileStorage");
          store.clear();
        }
        /**
         * Read a file from disk
         * @param options options for the file read
         * @return a promise that resolves with the read file data result
         */
        async readFile(options) {
          const path = this.getPath(options.directory, options.path);
          const entry = await this.dbRequest("get", [path]);
          if (entry === void 0)
            throw Error("File does not exist.");
          return { data: entry.content ? entry.content : "" };
        }
        /**
         * Write a file to disk in the specified location on device
         * @param options options for the file write
         * @return a promise that resolves with the file write result
         */
        async writeFile(options) {
          const path = this.getPath(options.directory, options.path);
          let data = options.data;
          const encoding = options.encoding;
          const doRecursive = options.recursive;
          const occupiedEntry = await this.dbRequest("get", [path]);
          if (occupiedEntry && occupiedEntry.type === "directory")
            throw Error("The supplied path is a directory.");
          const parentPath = path.substr(0, path.lastIndexOf("/"));
          const parentEntry = await this.dbRequest("get", [parentPath]);
          if (parentEntry === void 0) {
            const subDirIndex = parentPath.indexOf("/", 1);
            if (subDirIndex !== -1) {
              const parentArgPath = parentPath.substr(subDirIndex);
              await this.mkdir({
                path: parentArgPath,
                directory: options.directory,
                recursive: doRecursive
              });
            }
          }
          if (!encoding && !(data instanceof Blob)) {
            data = data.indexOf(",") >= 0 ? data.split(",")[1] : data;
            if (!this.isBase64String(data))
              throw Error("The supplied data is not valid base64 content.");
          }
          const now = Date.now();
          const pathObj = {
            path,
            folder: parentPath,
            type: "file",
            size: data instanceof Blob ? data.size : data.length,
            ctime: now,
            mtime: now,
            content: data
          };
          await this.dbRequest("put", [pathObj]);
          return {
            uri: pathObj.path
          };
        }
        /**
         * Append to a file on disk in the specified location on device
         * @param options options for the file append
         * @return a promise that resolves with the file write result
         */
        async appendFile(options) {
          const path = this.getPath(options.directory, options.path);
          let data = options.data;
          const encoding = options.encoding;
          const parentPath = path.substr(0, path.lastIndexOf("/"));
          const now = Date.now();
          let ctime = now;
          const occupiedEntry = await this.dbRequest("get", [path]);
          if (occupiedEntry && occupiedEntry.type === "directory")
            throw Error("The supplied path is a directory.");
          const parentEntry = await this.dbRequest("get", [parentPath]);
          if (parentEntry === void 0) {
            const subDirIndex = parentPath.indexOf("/", 1);
            if (subDirIndex !== -1) {
              const parentArgPath = parentPath.substr(subDirIndex);
              await this.mkdir({
                path: parentArgPath,
                directory: options.directory,
                recursive: true
              });
            }
          }
          if (!encoding && !this.isBase64String(data))
            throw Error("The supplied data is not valid base64 content.");
          if (occupiedEntry !== void 0) {
            if (occupiedEntry.content instanceof Blob) {
              throw Error("The occupied entry contains a Blob object which cannot be appended to.");
            }
            if (occupiedEntry.content !== void 0 && !encoding) {
              data = btoa(atob(occupiedEntry.content) + atob(data));
            } else {
              data = occupiedEntry.content + data;
            }
            ctime = occupiedEntry.ctime;
          }
          const pathObj = {
            path,
            folder: parentPath,
            type: "file",
            size: data.length,
            ctime,
            mtime: now,
            content: data
          };
          await this.dbRequest("put", [pathObj]);
        }
        /**
         * Delete a file from disk
         * @param options options for the file delete
         * @return a promise that resolves with the deleted file data result
         */
        async deleteFile(options) {
          const path = this.getPath(options.directory, options.path);
          const entry = await this.dbRequest("get", [path]);
          if (entry === void 0)
            throw Error("File does not exist.");
          const entries = await this.dbIndexRequest("by_folder", "getAllKeys", [IDBKeyRange.only(path)]);
          if (entries.length !== 0)
            throw Error("Folder is not empty.");
          await this.dbRequest("delete", [path]);
        }
        /**
         * Create a directory.
         * @param options options for the mkdir
         * @return a promise that resolves with the mkdir result
         */
        async mkdir(options) {
          const path = this.getPath(options.directory, options.path);
          const doRecursive = options.recursive;
          const parentPath = path.substr(0, path.lastIndexOf("/"));
          const depth = (path.match(/\//g) || []).length;
          const parentEntry = await this.dbRequest("get", [parentPath]);
          const occupiedEntry = await this.dbRequest("get", [path]);
          if (depth === 1)
            throw Error("Cannot create Root directory");
          if (occupiedEntry !== void 0)
            throw Error("Current directory does already exist.");
          if (!doRecursive && depth !== 2 && parentEntry === void 0)
            throw Error("Parent directory must exist");
          if (doRecursive && depth !== 2 && parentEntry === void 0) {
            const parentArgPath = parentPath.substr(parentPath.indexOf("/", 1));
            await this.mkdir({
              path: parentArgPath,
              directory: options.directory,
              recursive: doRecursive
            });
          }
          const now = Date.now();
          const pathObj = {
            path,
            folder: parentPath,
            type: "directory",
            size: 0,
            ctime: now,
            mtime: now
          };
          await this.dbRequest("put", [pathObj]);
        }
        /**
         * Remove a directory
         * @param options the options for the directory remove
         */
        async rmdir(options) {
          const { path, directory, recursive } = options;
          const fullPath = this.getPath(directory, path);
          const entry = await this.dbRequest("get", [fullPath]);
          if (entry === void 0)
            throw Error("Folder does not exist.");
          if (entry.type !== "directory")
            throw Error("Requested path is not a directory");
          const readDirResult = await this.readdir({ path, directory });
          if (readDirResult.files.length !== 0 && !recursive)
            throw Error("Folder is not empty");
          for (const entry2 of readDirResult.files) {
            const entryPath = `${path}/${entry2.name}`;
            const entryObj = await this.stat({ path: entryPath, directory });
            if (entryObj.type === "file") {
              await this.deleteFile({ path: entryPath, directory });
            } else {
              await this.rmdir({ path: entryPath, directory, recursive });
            }
          }
          await this.dbRequest("delete", [fullPath]);
        }
        /**
         * Return a list of files from the directory (not recursive)
         * @param options the options for the readdir operation
         * @return a promise that resolves with the readdir directory listing result
         */
        async readdir(options) {
          const path = this.getPath(options.directory, options.path);
          const entry = await this.dbRequest("get", [path]);
          if (options.path !== "" && entry === void 0)
            throw Error("Folder does not exist.");
          const entries = await this.dbIndexRequest("by_folder", "getAllKeys", [IDBKeyRange.only(path)]);
          const files = await Promise.all(entries.map(async (e) => {
            let subEntry = await this.dbRequest("get", [e]);
            if (subEntry === void 0) {
              subEntry = await this.dbRequest("get", [e + "/"]);
            }
            return {
              name: e.substring(path.length + 1),
              type: subEntry.type,
              size: subEntry.size,
              ctime: subEntry.ctime,
              mtime: subEntry.mtime,
              uri: subEntry.path
            };
          }));
          return { files };
        }
        /**
         * Return full File URI for a path and directory
         * @param options the options for the stat operation
         * @return a promise that resolves with the file stat result
         */
        async getUri(options) {
          const path = this.getPath(options.directory, options.path);
          let entry = await this.dbRequest("get", [path]);
          if (entry === void 0) {
            entry = await this.dbRequest("get", [path + "/"]);
          }
          return {
            uri: (entry === null || entry === void 0 ? void 0 : entry.path) || path
          };
        }
        /**
         * Return data about a file
         * @param options the options for the stat operation
         * @return a promise that resolves with the file stat result
         */
        async stat(options) {
          const path = this.getPath(options.directory, options.path);
          let entry = await this.dbRequest("get", [path]);
          if (entry === void 0) {
            entry = await this.dbRequest("get", [path + "/"]);
          }
          if (entry === void 0)
            throw Error("Entry does not exist.");
          return {
            name: entry.path.substring(path.length + 1),
            type: entry.type,
            size: entry.size,
            ctime: entry.ctime,
            mtime: entry.mtime,
            uri: entry.path
          };
        }
        /**
         * Rename a file or directory
         * @param options the options for the rename operation
         * @return a promise that resolves with the rename result
         */
        async rename(options) {
          await this._copy(options, true);
          return;
        }
        /**
         * Copy a file or directory
         * @param options the options for the copy operation
         * @return a promise that resolves with the copy result
         */
        async copy(options) {
          return this._copy(options, false);
        }
        async requestPermissions() {
          return { publicStorage: "granted" };
        }
        async checkPermissions() {
          return { publicStorage: "granted" };
        }
        /**
         * Function that can perform a copy or a rename
         * @param options the options for the rename operation
         * @param doRename whether to perform a rename or copy operation
         * @return a promise that resolves with the result
         */
        async _copy(options, doRename = false) {
          let { toDirectory } = options;
          const { to, from, directory: fromDirectory } = options;
          if (!to || !from) {
            throw Error("Both to and from must be provided");
          }
          if (!toDirectory) {
            toDirectory = fromDirectory;
          }
          const fromPath = this.getPath(fromDirectory, from);
          const toPath = this.getPath(toDirectory, to);
          if (fromPath === toPath) {
            return {
              uri: toPath
            };
          }
          if (isPathParent(fromPath, toPath)) {
            throw Error("To path cannot contain the from path");
          }
          let toObj;
          try {
            toObj = await this.stat({
              path: to,
              directory: toDirectory
            });
          } catch (e) {
            const toPathComponents = to.split("/");
            toPathComponents.pop();
            const toPath2 = toPathComponents.join("/");
            if (toPathComponents.length > 0) {
              const toParentDirectory = await this.stat({
                path: toPath2,
                directory: toDirectory
              });
              if (toParentDirectory.type !== "directory") {
                throw new Error("Parent directory of the to path is a file");
              }
            }
          }
          if (toObj && toObj.type === "directory") {
            throw new Error("Cannot overwrite a directory with a file");
          }
          const fromObj = await this.stat({
            path: from,
            directory: fromDirectory
          });
          const updateTime = async (path, ctime2, mtime) => {
            const fullPath = this.getPath(toDirectory, path);
            const entry = await this.dbRequest("get", [fullPath]);
            entry.ctime = ctime2;
            entry.mtime = mtime;
            await this.dbRequest("put", [entry]);
          };
          const ctime = fromObj.ctime ? fromObj.ctime : Date.now();
          switch (fromObj.type) {
            // The "from" object is a file
            case "file": {
              const file = await this.readFile({
                path: from,
                directory: fromDirectory
              });
              if (doRename) {
                await this.deleteFile({
                  path: from,
                  directory: fromDirectory
                });
              }
              let encoding;
              if (!(file.data instanceof Blob) && !this.isBase64String(file.data)) {
                encoding = Encoding.UTF8;
              }
              const writeResult = await this.writeFile({
                path: to,
                directory: toDirectory,
                data: file.data,
                encoding
              });
              if (doRename) {
                await updateTime(to, ctime, fromObj.mtime);
              }
              return writeResult;
            }
            case "directory": {
              if (toObj) {
                throw Error("Cannot move a directory over an existing object");
              }
              try {
                await this.mkdir({
                  path: to,
                  directory: toDirectory,
                  recursive: false
                });
                if (doRename) {
                  await updateTime(to, ctime, fromObj.mtime);
                }
              } catch (e) {
              }
              const contents = (await this.readdir({
                path: from,
                directory: fromDirectory
              })).files;
              for (const filename of contents) {
                await this._copy({
                  from: `${from}/${filename.name}`,
                  to: `${to}/${filename.name}`,
                  directory: fromDirectory,
                  toDirectory
                }, doRename);
              }
              if (doRename) {
                await this.rmdir({
                  path: from,
                  directory: fromDirectory
                });
              }
            }
          }
          return {
            uri: toPath
          };
        }
        isBase64String(str) {
          try {
            return btoa(atob(str)) == str;
          } catch (err) {
            return false;
          }
        }
      };
      FilesystemWeb._debug = true;
    }
  });

  // node_modules/@capacitor/filesystem/dist/esm/index.js
  var Filesystem;
  var init_esm2 = __esm({
    "node_modules/@capacitor/filesystem/dist/esm/index.js"() {
      init_dist();
      init_synapse();
      init_definitions2();
      Filesystem = registerPlugin("Filesystem", {
        web: () => Promise.resolve().then(() => (init_web2(), web_exports2)).then((m) => new m.FilesystemWeb())
      });
      f();
    }
  });

  // node_modules/@capacitor-firebase/authentication/dist/esm/definitions.js
  var Persistence, ProviderId;
  var init_definitions3 = __esm({
    "node_modules/@capacitor-firebase/authentication/dist/esm/definitions.js"() {
      (function(Persistence2) {
        Persistence2["IndexedDbLocal"] = "INDEXED_DB_LOCAL";
        Persistence2["InMemory"] = "IN_MEMORY";
        Persistence2["BrowserLocal"] = "BROWSER_LOCAL";
        Persistence2["BrowserSession"] = "BROWSER_SESSION";
      })(Persistence || (Persistence = {}));
      (function(ProviderId2) {
        ProviderId2["APPLE"] = "apple.com";
        ProviderId2["FACEBOOK"] = "facebook.com";
        ProviderId2["GAME_CENTER"] = "gc.apple.com";
        ProviderId2["GITHUB"] = "github.com";
        ProviderId2["GOOGLE"] = "google.com";
        ProviderId2["MICROSOFT"] = "microsoft.com";
        ProviderId2["PLAY_GAMES"] = "playgames.google.com";
        ProviderId2["TWITTER"] = "twitter.com";
        ProviderId2["YAHOO"] = "yahoo.com";
        ProviderId2["PASSWORD"] = "password";
        ProviderId2["PHONE"] = "phone";
      })(ProviderId || (ProviderId = {}));
    }
  });

  // node_modules/@capacitor-firebase/authentication/dist/esm/web.js
  var web_exports3 = {};
  __export(web_exports3, {
    FirebaseAuthenticationWeb: () => FirebaseAuthenticationWeb
  });
  var import_auth, FirebaseAuthenticationWeb;
  var init_web3 = __esm({
    "node_modules/@capacitor-firebase/authentication/dist/esm/web.js"() {
      init_dist();
      import_auth = __require("firebase/auth");
      init_definitions3();
      FirebaseAuthenticationWeb = class _FirebaseAuthenticationWeb extends WebPlugin {
        constructor() {
          super();
          this.lastConfirmationResult = /* @__PURE__ */ new Map();
          const auth = (0, import_auth.getAuth)();
          auth.onAuthStateChanged((user) => this.handleAuthStateChange(user));
          auth.onIdTokenChanged((user) => void this.handleIdTokenChange(user));
        }
        async applyActionCode(options) {
          const auth = (0, import_auth.getAuth)();
          return (0, import_auth.applyActionCode)(auth, options.oobCode);
        }
        async createUserWithEmailAndPassword(options) {
          const auth = (0, import_auth.getAuth)();
          const userCredential = await (0, import_auth.createUserWithEmailAndPassword)(auth, options.email, options.password);
          return this.createSignInResult(userCredential, null);
        }
        async confirmPasswordReset(options) {
          const auth = (0, import_auth.getAuth)();
          return (0, import_auth.confirmPasswordReset)(auth, options.oobCode, options.newPassword);
        }
        async confirmVerificationCode(options) {
          const { verificationCode, verificationId } = options;
          const confirmationResult = this.lastConfirmationResult.get(verificationId);
          if (!confirmationResult) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_CONFIRMATION_RESULT_MISSING);
          }
          const userCredential = await confirmationResult.confirm(verificationCode);
          return this.createSignInResult(userCredential, null);
        }
        async deleteUser() {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.deleteUser)(currentUser);
        }
        async fetchSignInMethodsForEmail(options) {
          const auth = (0, import_auth.getAuth)();
          const signInMethods = await (0, import_auth.fetchSignInMethodsForEmail)(auth, options.email);
          return {
            signInMethods
          };
        }
        async getPendingAuthResult() {
          throw this.unimplemented("Not implemented on web.");
        }
        async getCurrentUser() {
          const auth = (0, import_auth.getAuth)();
          const userResult = this.createUserResult(auth.currentUser);
          const result = {
            user: userResult
          };
          return result;
        }
        async getIdToken(options) {
          const auth = (0, import_auth.getAuth)();
          if (!auth.currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          const idToken = await auth.currentUser.getIdToken(options === null || options === void 0 ? void 0 : options.forceRefresh);
          const result = {
            token: idToken || ""
          };
          return result;
        }
        async getIdTokenResult(options) {
          const auth = (0, import_auth.getAuth)();
          if (!auth.currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          const idTokenResult = await auth.currentUser.getIdTokenResult(options === null || options === void 0 ? void 0 : options.forceRefresh);
          const result = Object.assign(Object.assign({}, idTokenResult), { authTime: Date.parse(idTokenResult.authTime), expirationTime: Date.parse(idTokenResult.expirationTime), issuedAtTime: Date.parse(idTokenResult.issuedAtTime) });
          return result;
        }
        async getRedirectResult() {
          const auth = (0, import_auth.getAuth)();
          const userCredential = await (0, import_auth.getRedirectResult)(auth);
          const authCredential = userCredential ? import_auth.OAuthProvider.credentialFromResult(userCredential) : null;
          return this.createSignInResult(userCredential, authCredential);
        }
        async getTenantId() {
          const auth = (0, import_auth.getAuth)();
          return {
            tenantId: auth.tenantId
          };
        }
        async isSignInWithEmailLink(options) {
          const auth = (0, import_auth.getAuth)();
          return {
            isSignInWithEmailLink: (0, import_auth.isSignInWithEmailLink)(auth, options.emailLink)
          };
        }
        async linkWithApple(options) {
          const provider = new import_auth.OAuthProvider(ProviderId.APPLE);
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithEmailAndPassword(options) {
          const authCredential = import_auth.EmailAuthProvider.credential(options.email, options.password);
          const userCredential = await this.linkCurrentUserWithCredential(authCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithEmailLink(options) {
          const authCredential = import_auth.EmailAuthProvider.credentialWithLink(options.email, options.emailLink);
          const userCredential = await this.linkCurrentUserWithCredential(authCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithFacebook(options) {
          const provider = new import_auth.FacebookAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.FacebookAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithGameCenter() {
          throw this.unimplemented("Not implemented on web.");
        }
        async linkWithGithub(options) {
          const provider = new import_auth.GithubAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.GithubAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithGoogle(options) {
          const provider = new import_auth.GoogleAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.GoogleAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithMicrosoft(options) {
          const provider = new import_auth.OAuthProvider(ProviderId.MICROSOFT);
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithOpenIdConnect(options) {
          const provider = new import_auth.OAuthProvider(options.providerId);
          this.applySignInOptions(options, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithPhoneNumber(options) {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          if (!options.phoneNumber) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_PHONE_NUMBER_MISSING);
          }
          if (!options.recaptchaVerifier || !(options.recaptchaVerifier instanceof import_auth.RecaptchaVerifier)) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_RECAPTCHA_VERIFIER_MISSING);
          }
          try {
            const confirmationResult = await (0, import_auth.linkWithPhoneNumber)(currentUser, options.phoneNumber, options.recaptchaVerifier);
            const { verificationId } = confirmationResult;
            this.lastConfirmationResult.set(verificationId, confirmationResult);
            const event = {
              verificationId
            };
            this.notifyListeners(_FirebaseAuthenticationWeb.PHONE_CODE_SENT_EVENT, event);
          } catch (error) {
            const event = {
              message: this.getErrorMessage(error)
            };
            this.notifyListeners(_FirebaseAuthenticationWeb.PHONE_VERIFICATION_FAILED_EVENT, event);
          }
        }
        async linkWithPlayGames() {
          throw this.unimplemented("Not implemented on web.");
        }
        async linkWithTwitter(options) {
          const provider = new import_auth.TwitterAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.TwitterAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async linkWithYahoo(options) {
          const provider = new import_auth.OAuthProvider(ProviderId.YAHOO);
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.linkCurrentUserWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async reload() {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.reload)(currentUser);
        }
        async revokeAccessToken(options) {
          const auth = (0, import_auth.getAuth)();
          return (0, import_auth.revokeAccessToken)(auth, options.token);
        }
        async sendEmailVerification(options) {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.sendEmailVerification)(currentUser, options === null || options === void 0 ? void 0 : options.actionCodeSettings);
        }
        async sendPasswordResetEmail(options) {
          const auth = (0, import_auth.getAuth)();
          return (0, import_auth.sendPasswordResetEmail)(auth, options.email, options.actionCodeSettings);
        }
        async sendSignInLinkToEmail(options) {
          const auth = (0, import_auth.getAuth)();
          return (0, import_auth.sendSignInLinkToEmail)(auth, options.email, options.actionCodeSettings);
        }
        async setLanguageCode(options) {
          const auth = (0, import_auth.getAuth)();
          auth.languageCode = options.languageCode;
        }
        async setPersistence(options) {
          const auth = (0, import_auth.getAuth)();
          switch (options.persistence) {
            case Persistence.BrowserLocal:
              await (0, import_auth.setPersistence)(auth, import_auth.browserLocalPersistence);
              break;
            case Persistence.BrowserSession:
              await (0, import_auth.setPersistence)(auth, import_auth.browserSessionPersistence);
              break;
            case Persistence.IndexedDbLocal:
              await (0, import_auth.setPersistence)(auth, import_auth.indexedDBLocalPersistence);
              break;
            case Persistence.InMemory:
              await (0, import_auth.setPersistence)(auth, import_auth.inMemoryPersistence);
              break;
          }
        }
        async setTenantId(options) {
          const auth = (0, import_auth.getAuth)();
          auth.tenantId = options.tenantId;
        }
        async signInAnonymously() {
          const auth = (0, import_auth.getAuth)();
          const userCredential = await (0, import_auth.signInAnonymously)(auth);
          return this.createSignInResult(userCredential, null);
        }
        async signInWithApple(options) {
          const provider = new import_auth.OAuthProvider(ProviderId.APPLE);
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithCustomToken(options) {
          const auth = (0, import_auth.getAuth)();
          const userCredential = await (0, import_auth.signInWithCustomToken)(auth, options.token);
          return this.createSignInResult(userCredential, null);
        }
        async signInWithEmailAndPassword(options) {
          const auth = (0, import_auth.getAuth)();
          const userCredential = await (0, import_auth.signInWithEmailAndPassword)(auth, options.email, options.password);
          return this.createSignInResult(userCredential, null);
        }
        async signInWithEmailLink(options) {
          const auth = (0, import_auth.getAuth)();
          const userCredential = await (0, import_auth.signInWithEmailLink)(auth, options.email, options.emailLink);
          return this.createSignInResult(userCredential, null);
        }
        async signInWithFacebook(options) {
          const provider = new import_auth.FacebookAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.FacebookAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithGithub(options) {
          const provider = new import_auth.GithubAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.GithubAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithGoogle(options) {
          const provider = new import_auth.GoogleAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.GoogleAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithMicrosoft(options) {
          const provider = new import_auth.OAuthProvider(ProviderId.MICROSOFT);
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithOpenIdConnect(options) {
          const provider = new import_auth.OAuthProvider(options.providerId);
          this.applySignInOptions(options, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithPhoneNumber(options) {
          if (!options.phoneNumber) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_PHONE_NUMBER_MISSING);
          }
          if (!options.recaptchaVerifier || !(options.recaptchaVerifier instanceof import_auth.RecaptchaVerifier)) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_RECAPTCHA_VERIFIER_MISSING);
          }
          const auth = (0, import_auth.getAuth)();
          try {
            const confirmationResult = await (0, import_auth.signInWithPhoneNumber)(auth, options.phoneNumber, options.recaptchaVerifier);
            const { verificationId } = confirmationResult;
            this.lastConfirmationResult.set(verificationId, confirmationResult);
            const event = {
              verificationId
            };
            this.notifyListeners(_FirebaseAuthenticationWeb.PHONE_CODE_SENT_EVENT, event);
          } catch (error) {
            const event = {
              message: this.getErrorMessage(error)
            };
            this.notifyListeners(_FirebaseAuthenticationWeb.PHONE_VERIFICATION_FAILED_EVENT, event);
          }
        }
        async signInWithPlayGames() {
          throw this.unimplemented("Not implemented on web.");
        }
        async signInWithGameCenter() {
          throw this.unimplemented("Not implemented on web.");
        }
        async signInWithTwitter(options) {
          const provider = new import_auth.TwitterAuthProvider();
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.TwitterAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signInWithYahoo(options) {
          const provider = new import_auth.OAuthProvider(ProviderId.YAHOO);
          this.applySignInOptions(options || {}, provider);
          const userCredential = await this.signInWithPopupOrRedirect(provider, options === null || options === void 0 ? void 0 : options.mode);
          const authCredential = import_auth.OAuthProvider.credentialFromResult(userCredential);
          return this.createSignInResult(userCredential, authCredential);
        }
        async signOut() {
          const auth = (0, import_auth.getAuth)();
          await auth.signOut();
        }
        async unlink(options) {
          const auth = (0, import_auth.getAuth)();
          if (!auth.currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          const user = await (0, import_auth.unlink)(auth.currentUser, options.providerId);
          const userResult = this.createUserResult(user);
          const result = {
            user: userResult
          };
          return result;
        }
        async updateEmail(options) {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.updateEmail)(currentUser, options.newEmail);
        }
        async updatePassword(options) {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.updatePassword)(currentUser, options.newPassword);
        }
        async updateProfile(options) {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.updateProfile)(currentUser, {
            displayName: options.displayName,
            photoURL: options.photoUrl
          });
        }
        async useAppLanguage() {
          const auth = (0, import_auth.getAuth)();
          auth.useDeviceLanguage();
        }
        async useEmulator(options) {
          const auth = (0, import_auth.getAuth)();
          const port = options.port || 9099;
          const scheme = options.scheme || "http";
          if (options.host.includes("://")) {
            (0, import_auth.connectAuthEmulator)(auth, `${options.host}:${port}`);
          } else {
            (0, import_auth.connectAuthEmulator)(auth, `${scheme}://${options.host}:${port}`);
          }
        }
        async verifyBeforeUpdateEmail(options) {
          const auth = (0, import_auth.getAuth)();
          const currentUser = auth.currentUser;
          if (!currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.verifyBeforeUpdateEmail)(currentUser, options === null || options === void 0 ? void 0 : options.newEmail, options === null || options === void 0 ? void 0 : options.actionCodeSettings);
        }
        handleAuthStateChange(user) {
          const userResult = this.createUserResult(user);
          const change = {
            user: userResult
          };
          this.notifyListeners(_FirebaseAuthenticationWeb.AUTH_STATE_CHANGE_EVENT, change, true);
        }
        async handleIdTokenChange(user) {
          if (!user) {
            return;
          }
          const idToken = await user.getIdToken(false);
          const result = {
            token: idToken
          };
          this.notifyListeners(_FirebaseAuthenticationWeb.ID_TOKEN_CHANGE_EVENT, result, true);
        }
        applySignInOptions(options, provider) {
          if (options.customParameters) {
            const customParameters = {};
            options.customParameters.map((parameter) => {
              customParameters[parameter.key] = parameter.value;
            });
            provider.setCustomParameters(customParameters);
          }
          if (options.scopes) {
            for (const scope of options.scopes) {
              provider.addScope(scope);
            }
          }
        }
        signInWithPopupOrRedirect(provider, mode) {
          const auth = (0, import_auth.getAuth)();
          if (mode === "redirect") {
            return (0, import_auth.signInWithRedirect)(auth, provider);
          } else {
            return (0, import_auth.signInWithPopup)(auth, provider);
          }
        }
        linkCurrentUserWithPopupOrRedirect(provider, mode) {
          const auth = (0, import_auth.getAuth)();
          if (!auth.currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          if (mode === "redirect") {
            return (0, import_auth.linkWithRedirect)(auth.currentUser, provider);
          } else {
            return (0, import_auth.linkWithPopup)(auth.currentUser, provider);
          }
        }
        linkCurrentUserWithCredential(credential) {
          const auth = (0, import_auth.getAuth)();
          if (!auth.currentUser) {
            throw new Error(_FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN);
          }
          return (0, import_auth.linkWithCredential)(auth.currentUser, credential);
        }
        requestAppTrackingTransparencyPermission() {
          throw this.unimplemented("Not implemented on web.");
        }
        checkAppTrackingTransparencyPermission() {
          throw this.unimplemented("Not implemented on web.");
        }
        createSignInResult(userCredential, authCredential) {
          const userResult = this.createUserResult((userCredential === null || userCredential === void 0 ? void 0 : userCredential.user) || null);
          const credentialResult = this.createCredentialResult(authCredential);
          const additionalUserInfoResult = this.createAdditionalUserInfoResult(userCredential);
          const result = {
            user: userResult,
            credential: credentialResult,
            additionalUserInfo: additionalUserInfoResult
          };
          return result;
        }
        createCredentialResult(credential) {
          if (!credential) {
            return null;
          }
          const result = {
            providerId: credential.providerId
          };
          if (credential instanceof import_auth.OAuthCredential) {
            result.accessToken = credential.accessToken;
            result.idToken = credential.idToken;
            result.secret = credential.secret;
          }
          return result;
        }
        createUserResult(user) {
          if (!user) {
            return null;
          }
          const result = {
            displayName: user.displayName,
            email: user.email,
            emailVerified: user.emailVerified,
            isAnonymous: user.isAnonymous,
            metadata: this.createUserMetadataResult(user.metadata),
            phoneNumber: user.phoneNumber,
            photoUrl: user.photoURL,
            providerData: this.createUserProviderDataResult(user.providerData),
            providerId: user.providerId,
            tenantId: user.tenantId,
            uid: user.uid
          };
          return result;
        }
        createUserMetadataResult(metadata) {
          const result = {};
          if (metadata.creationTime) {
            result.creationTime = Date.parse(metadata.creationTime);
          }
          if (metadata.lastSignInTime) {
            result.lastSignInTime = Date.parse(metadata.lastSignInTime);
          }
          return result;
        }
        createUserProviderDataResult(providerData) {
          return providerData.map((data) => ({
            displayName: data.displayName,
            email: data.email,
            phoneNumber: data.phoneNumber,
            photoUrl: data.photoURL,
            providerId: data.providerId,
            uid: data.uid
          }));
        }
        createAdditionalUserInfoResult(credential) {
          if (!credential) {
            return null;
          }
          const additionalUserInfo = (0, import_auth.getAdditionalUserInfo)(credential);
          if (!additionalUserInfo) {
            return null;
          }
          const { isNewUser, profile, providerId, username } = additionalUserInfo;
          const result = {
            isNewUser
          };
          if (providerId !== null) {
            result.providerId = providerId;
          }
          if (profile !== null) {
            result.profile = profile;
          }
          if (username !== null && username !== void 0) {
            result.username = username;
          }
          return result;
        }
        getErrorMessage(error) {
          if (error instanceof Object && "message" in error && typeof error["message"] === "string") {
            return error["message"];
          }
          return JSON.stringify(error);
        }
      };
      FirebaseAuthenticationWeb.AUTH_STATE_CHANGE_EVENT = "authStateChange";
      FirebaseAuthenticationWeb.ID_TOKEN_CHANGE_EVENT = "idTokenChange";
      FirebaseAuthenticationWeb.PHONE_CODE_SENT_EVENT = "phoneCodeSent";
      FirebaseAuthenticationWeb.PHONE_VERIFICATION_FAILED_EVENT = "phoneVerificationFailed";
      FirebaseAuthenticationWeb.ERROR_NO_USER_SIGNED_IN = "No user is signed in.";
      FirebaseAuthenticationWeb.ERROR_PHONE_NUMBER_MISSING = "phoneNumber must be provided.";
      FirebaseAuthenticationWeb.ERROR_RECAPTCHA_VERIFIER_MISSING = "recaptchaVerifier must be provided and must be an instance of RecaptchaVerifier.";
      FirebaseAuthenticationWeb.ERROR_CONFIRMATION_RESULT_MISSING = "No confirmation result with this verification id was found.";
    }
  });

  // node_modules/@capacitor-firebase/authentication/dist/esm/index.js
  var FirebaseAuthentication;
  var init_esm3 = __esm({
    "node_modules/@capacitor-firebase/authentication/dist/esm/index.js"() {
      init_dist();
      init_definitions3();
      FirebaseAuthentication = registerPlugin("FirebaseAuthentication", {
        web: () => Promise.resolve().then(() => (init_web3(), web_exports3)).then((m) => new m.FirebaseAuthenticationWeb())
      });
    }
  });

  // node_modules/@bcyesil/capacitor-plugin-printer/dist/esm/definitions.js
  var init_definitions4 = __esm({
    "node_modules/@bcyesil/capacitor-plugin-printer/dist/esm/definitions.js"() {
    }
  });

  // node_modules/@bcyesil/capacitor-plugin-printer/dist/esm/web.js
  var web_exports4 = {};
  __export(web_exports4, {
    PrinterWeb: () => PrinterWeb
  });
  var PrinterWeb;
  var init_web4 = __esm({
    "node_modules/@bcyesil/capacitor-plugin-printer/dist/esm/web.js"() {
      init_dist();
      PrinterWeb = class extends WebPlugin {
        async print() {
          console.log("Not supported web browsers!");
          return Promise.reject("Printer plugin is not supported on web.");
        }
      };
    }
  });

  // node_modules/@bcyesil/capacitor-plugin-printer/dist/esm/index.js
  var Printer;
  var init_esm4 = __esm({
    "node_modules/@bcyesil/capacitor-plugin-printer/dist/esm/index.js"() {
      init_dist();
      init_definitions4();
      Printer = registerPlugin("Printer", {
        web: () => Promise.resolve().then(() => (init_web4(), web_exports4)).then((m) => new m.PrinterWeb())
      });
    }
  });

  // capacitor-init.js
  var require_capacitor_init = __commonJS({
    "capacitor-init.js"() {
      init_dist();
      init_esm();
      init_esm2();
      init_esm3();
      init_esm4();
      window.Capacitor = Capacitor;
      window.CapacitorShare = Share;
      window.CapacitorFilesystem = Filesystem;
      window.CapacitorDirectory = Directory;
      window.CapacitorFirebaseAuthentication = FirebaseAuthentication;
      window.CapacitorPrinter = Printer;
    }
  });
  require_capacitor_init();
})();
/*! Bundled license information:

@capacitor/core/dist/index.js:
  (*! Capacitor: https://capacitorjs.com/ - MIT License *)
*/
