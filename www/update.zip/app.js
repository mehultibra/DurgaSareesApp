// ==========================================
// 🌸 DURGA SAREES - FIXED APP.JS v3 (RESTORED UI)
// ==========================================

const FIRESTORE_PRODUCTS_URL = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products?pageSize=1000";
const FIRESTORE_USERS_URL = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Users?pageSize=100";

history.replaceState({ modal: 'main' }, '');

// --- ADMIN MODE GLOBALS ---
window.isAdminMode = false;
window.adminTapCount = 0;
window.isSuperAdmin = localStorage.getItem('dsIsAdmin') === 'true';
window.DS_APP_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbx89H5yDUi-60Q2Rk12PH1TH34Nt-BncrMRhYSewu1LdLOj_GCWGKKz1Qmx2OmeGwlL/exec";

window.dsMissingImage = "data:image/svg+xml;utf8," + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800">
    <rect width="100%" height="100%" fill="#f5f5f6"/>
    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="24" font-weight="bold" fill="#bbbbbb">Loading...</text>
</svg>
`);

window.dsMasterCache = {};
try {
    var storedMaster = localStorage.getItem("dsMasterCache");
    if (storedMaster) window.dsMasterCache = JSON.parse(storedMaster);
} catch (e) { }

// --- ERROR LOGGING ---
window.globalErrorLog = JSON.parse(localStorage.getItem('dsGlobalErrors') || '[]');
window.logAppError = function (context, message) {
    window.globalErrorLog.push({ ts: new Date().getTime(), src: context, msg: message });
    if (window.globalErrorLog.length > 50) window.globalErrorLog.shift();
    setTimeout(() => localStorage.setItem('dsGlobalErrors', JSON.stringify(window.globalErrorLog)), 0);

    if (window.syncReportResults && window.syncReportResults.length > 0) {
        var parts = message.split(' | ');
        if (parts.length > 1) {
            var pName = parts[parts.length - 1].trim();
            var target = window.syncReportResults.find(r => r.name === pName);
            if (target) {
                target.status = 'error';
                target.error = (target.error ? target.error + ', ' : '') + context;
                if (typeof renderSyncReportPartial === 'function') {
                    renderSyncReportPartial();
                    var btnResync = document.getElementById('btnResyncErrors');
                    if (btnResync) btnResync.style.display = 'inline-block';
                }
            }
        }
    }
};

// Initialize Web Firebase Fallback Config
const firebaseConfig = {
    apiKey: "AIzaSyA3Za-dZ8OWWF7ZJdneKGd7A2t8xm_7IZQ",
    authDomain: window.location.hostname.includes("durga-sarees") ? window.location.hostname : "durga-sarees.firebaseapp.com",
    projectId: "durga-sarees"
};
var webConfirmationResult = null;

function initFirebaseGlobally() {
    if (typeof firebase !== 'undefined' && firebase.apps.length === 0) {
        firebase.initializeApp(firebaseConfig);
        try {
            window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
                'size': 'invisible'
            });
        } catch (e) { console.error("Recaptcha error:", e); }
    }
}

var allProducts = [];
var displayList = [];
var cart = {};
var favorites = {};
var activeUser = null;
window.livePresenceHistory = [];

function getActiveUserId() {
    if (activeUser && activeUser !== "null" && activeUser !== "undefined") return activeUser;
    let uid = localStorage.getItem('app_session_uid');
    if (!uid) {
        uid = 'guest_' + Math.random().toString(36).substring(2, 11);
        localStorage.setItem('app_session_uid', uid);
    }
    return uid;
}

let presenceTimeout = null;
let lastPresencePush = 0;
window.updateLivePresence = function (productId, force = false) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return;

    let now = Date.now();
    if (!force && now - lastPresencePush < 15000) return;
    lastPresencePush = now;

    try {
        if (typeof firebase === 'undefined' || !firebase.firestore) return;
        const uid = getActiveUserId();

        let totalQty = 0;
        let totalVal = 0;
        let cartSummary = [];
        for (let k in cart) {
            if (cart[k] && cart[k].qty > 0) {
                totalQty += Number(cart[k].qty);
                let rate = (cart[k].p && cart[k].p.price) ? Number(cart[k].p.price) : 0;
                totalVal += Number(cart[k].qty) * rate;
                cartSummary.push(`${cart[k].p ? cart[k].p.name : 'Saree'} (${cart[k].design}): ${cart[k].qty} pcs`);
            }
        }
        let cd = {};
        try { cd = JSON.parse(localStorage.getItem('dsCustomerDetails') || "{}"); } catch (e) { }
        let customerName = cd.name || cd.firm || "Guest";
        let customerStation = cd.station || "Unknown";

        let historyMap = {};
        try { historyMap = JSON.parse(localStorage.getItem('dsLiveHistory') || "{}"); } catch (e) { }

        const payload = {
            user: uid,
            currentProduct: productId || null,
            customerName: customerName,
            customerStation: customerStation,
            historyMap: historyMap,
            cartCount: totalQty,
            cartValue: totalVal,
            cartSummary: cartSummary,
            lastActive: firebase.firestore.FieldValue.serverTimestamp()
        };

        firebase.firestore().collection('LiveSessions').doc(uid).set(payload, { merge: true })
            .catch(err => console.warn("Live presence sync skipped:", err));
    } catch (e) { }
};
var activeCategories = [];
var activePriceFilters = [];
var currentSort = 'new';
var curProduct = null;
var cameFromDetail = false;
var searchingTransition = false;

// Escapes text safely
function esc(s) { return (!s) ? '' : String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

var coverExistsMap = {};
try {
    coverExistsMap = JSON.parse(localStorage.getItem("dsCoverExists")) || {};
} catch (e) {
    console.error("Error reading dsCoverExists", e);
}

function saveCoverExistsMap() {
    try {
        localStorage.setItem("dsCoverExists", JSON.stringify(coverExistsMap));
    } catch (e) {
        console.error("Error saving dsCoverExists", e);
    }
}

var dsFallbackMap = {};
try {
    dsFallbackMap = JSON.parse(localStorage.getItem("dsFallbackMap")) || {};
} catch (e) {
    console.error("Error reading dsFallbackMap", e);
}

function saveFallbackMap() {
    try {
        localStorage.setItem("dsFallbackMap", JSON.stringify(dsFallbackMap));
    } catch (e) {
        console.error("Error saving dsFallbackMap", e);
    }
}

window.sessionImageCache = new Map();
window.dsFolderCache = {};
try {
    var _cacheVer = localStorage.getItem("dsFolderCacheVer");
    if (_cacheVer === "v3") {
        window.dsFolderCache = JSON.parse(localStorage.getItem("dsFolderCache")) || {};
    } else {
        // Clear old cache - URL format changed (now uses Grid path + delimiter=/)
        localStorage.removeItem("dsFolderCache");
        localStorage.setItem("dsFolderCacheVer", "v3");
        console.log("Cleared stale folder cache (format upgrade to v3)");
    }
} catch (e) {
    console.error("Error reading dsFolderCache", e);
}

window.addEventListener('DOMContentLoaded', function () {



    // Header scroll effect
    var gridWrap = document.getElementById('gridWrapper');
    if (gridWrap) {
        gridWrap.addEventListener('scroll', function () {
            var hdr = document.querySelector('.hdr');
            var metaTheme = document.querySelector('meta[name="theme-color"]');
            if (!hdr) return;

            if (this.scrollTop > 20) {
                hdr.style.backgroundColor = '#ffffff';
                hdr.style.borderBottom = '1px solid #eee';
                if (metaTheme) metaTheme.setAttribute('content', '#ffffff');
            } else {
                hdr.style.backgroundColor = 'transparent';
                hdr.style.borderBottom = 'none';
                if (metaTheme) metaTheme.setAttribute('content', '#ffffff');
            }
        });
    }
    try { activeUser = localStorage.getItem("dsUserToken"); } catch (e) { }
    try { cart = JSON.parse(localStorage.getItem("dsCart")) || {}; } catch (e) { }
    try { favorites = JSON.parse(localStorage.getItem("dsFavs")) || {}; } catch (e) { }

    var loginScreen = document.getElementById('loginScreen');
    var appBody = document.getElementById('appBody');

    var logoImg = document.getElementById('appLogoImg');
    if (logoImg) {
        var tapTimeout = null;
        logoImg.addEventListener('click', function () {
            window.adminTapCount++;
            clearTimeout(tapTimeout);
            tapTimeout = setTimeout(() => { window.adminTapCount = 0; }, 1500);
            if (window.adminTapCount === 3) {
                window.adminTapCount = 0;
                if (window.isSuperAdmin) {
                    window.isAdminMode = !window.isAdminMode;
                    document.getElementById('appLogoImg').style.border = window.isAdminMode ? '2px solid red' : 'none';
                    document.getElementById('appLogoImg').style.borderRadius = '4px';
                    var fabAdd = document.getElementById('fabAddProduct');
                    if (fabAdd) fabAdd.style.display = window.isAdminMode ? 'flex' : 'none';
                    alert("Admin Mode: " + (window.isAdminMode ? "ON" : "OFF"));
                    if (typeof applyFilter === 'function') applyFilter();
                } else {
                    alert("Access Denied: Not an Administrator.");
                }
            }
        });
    }

    // ALWAYS initialize Firebase Web SDK for Firestore support on Native
    initFirebaseGlobally();

    var guestPid = new URLSearchParams(window.location.search).get('pid');

    if (activeUser && activeUser !== "null" && activeUser !== "undefined") {
        if (loginScreen && appBody) {
            loginScreen.style.display = 'none';
            appBody.style.display = 'flex';
            checkAdminStatus(activeUser);
            setTimeout(initApp, 100);
        }
    } else if (guestPid) {
        window.isGuestMode = true;
        if (loginScreen && appBody) {
            loginScreen.style.display = 'none';
            appBody.style.display = 'flex';
            setTimeout(initApp, 100);
        }
    } else {
        if (loginScreen && appBody) {
            loginScreen.style.display = 'flex';
            appBody.style.display = 'none';
        }
    }

    if (window.Capacitor && window.Capacitor.isNativePlatform()) {
        if (window.CapacitorFirebaseAuthentication) {
            window.CapacitorFirebaseAuthentication.addListener('authStateChange', (user) => {
                if (user && user.phoneNumber) {
                    try { localStorage.setItem("dsUserToken", user.phoneNumber); } catch (e) { }
                    activeUser = user.phoneNumber;
                    if (loginScreen && appBody && loginScreen.style.display !== 'none') {
                        loginScreen.style.display = 'none';
                        appBody.style.display = 'flex';
                        initApp();
                    }
                }
            });

            window.CapacitorFirebaseAuthentication.addListener('phoneCodeSent', (event) => {
                var btn = document.getElementById('btnSendOtp');
                if (btn) btn.innerText = "SEND OTP";
                dsVerificationId = event.verificationId;
                document.getElementById('loginBoxPhone').style.display = 'none';
                document.getElementById('loginBoxOtp').style.display = 'block';
            });

            window.CapacitorFirebaseAuthentication.addListener('phoneVerificationCompleted', (result) => {
                const user = result.user;
                if (user) {
                    var inputPhone = document.getElementById('lPhone').value.trim();
                    var countryCode = document.getElementById('lCountry') ? document.getElementById('lCountry').value.trim() : "+91";
                    var phoneStr = user.phoneNumber || (inputPhone.startsWith('+') ? inputPhone : countryCode + inputPhone);

                    checkUserInFirestore(phoneStr).then(function (exists) {
                        if (exists) {
                            completeLogin(phoneStr);
                        } else {
                            document.getElementById('loginBoxOtp').style.display = 'none';
                            document.getElementById('loginBoxRegister').style.display = 'block';
                            window.pendingUserPhone = phoneStr;
                        }
                    });
                }
            });

            window.CapacitorFirebaseAuthentication.addListener('phoneVerificationFailed', (event) => {
                var errEl = document.getElementById('lErr');
                if (errEl) errEl.innerText = "❌ Verification Failed: " + event.message;
                var errElOtp = document.getElementById('lErrOtp');
                if (errElOtp) errElOtp.innerText = "❌ " + event.message;
                var btn = document.getElementById('btnSendOtp');
                if (btn) btn.innerText = "SEND OTP";
            });
        }
    }

    setupEditableFields();
    setupFsGestures();

    // 🚀 Initialize Capgo OTA Updater
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater) {
        try { window.Capacitor.Plugins.CapacitorUpdater.notifyAppReady(); } catch (e) { }

        // Apply any pending update instantly on cold boot
        (async function () {
            try {
                let pending = localStorage.getItem("dsPendingOta");
                if (pending) {
                    let vData = JSON.parse(pending);
                    localStorage.removeItem("dsPendingOta");
                    await window.Capacitor.Plugins.CapacitorUpdater.set(vData);
                }
            } catch (e) { }
        })();

        // Apply updates silently when app goes into background
        if (window.Capacitor && window.Capacitor.Plugins.App) {
            window.Capacitor.Plugins.App.addListener('appStateChange', async ({ isActive }) => {
                if (!isActive) {
                    var loginScreen = document.getElementById('loginScreen');
                    if (loginScreen && loginScreen.style.display !== 'none') {
                        return; // Do not interrupt login/OTP flow
                    }
                    var pending = localStorage.getItem("dsPendingOta");
                    if (pending && window.Capacitor.Plugins.CapacitorUpdater) {
                        try {
                            let vData = JSON.parse(pending);
                            localStorage.removeItem("dsPendingOta");
                            window.Capacitor.Plugins.CapacitorUpdater.set(vData).catch(() => { });
                        } catch (e) { }
                    }
                }
            });
        }
    }

    // Check for updates on ALL platforms (Native & Web)
    setTimeout(checkForOTAUpdates, 2000);
});

async function checkForOTAUpdates() {
    try {
        var response = await fetch("https://durga-sarees.web.app/version.json?t=" + new Date().getTime());
        if (!response.ok) return;
        var data = await response.json();
        var latestVersion = data.version;
        var updateUrl = data.url;

        var currentVersion = localStorage.getItem("dsOtaVersion") || "builtin";

        if (latestVersion && latestVersion !== currentVersion) {
            console.log("OTA update available:", latestVersion);
            if (window.Capacitor && window.Capacitor.Plugins.CapacitorUpdater && updateUrl) {
                var versionData = await window.Capacitor.Plugins.CapacitorUpdater.download({
                    url: updateUrl,
                    version: latestVersion
                });
                localStorage.setItem("dsOtaVersion", latestVersion);
                localStorage.setItem("dsPendingOta", JSON.stringify(versionData));
                console.log("Update downloaded. Will apply silently on background or next restart.");
            } else {
                localStorage.setItem("dsOtaVersion", latestVersion);
                console.log("Web update available. Will apply on next page refresh.");
            }
        }
    } catch (e) {
        console.log("OTA check skipped:", e.message);
    }
}

var dsVerificationId = null;

async function sendOtp() {
    var phoneEl = document.getElementById('lPhone');
    var errEl = document.getElementById('lErr');
    if (!phoneEl) return;

    var phone = phoneEl.value.trim();
    var countryCode = document.getElementById('lCountry') ? document.getElementById('lCountry').value.trim() : "+91";
    if (!phone) { if (errEl) errEl.innerText = "Enter phone number"; return; }

    if (!phone.startsWith('+')) {
        phone = countryCode + phone;
    }

    var btn = document.getElementById('btnSendOtp');
    if (btn) btn.innerText = "Sending...";
    if (errEl) errEl.innerText = "";

    try {
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            if (!window.CapacitorFirebaseAuthentication) throw new Error("Firebase Auth Plugin missing");
            await window.CapacitorFirebaseAuthentication.signInWithPhoneNumber({
                phoneNumber: phone
            });
            // Note: The UI will transition to the OTP screen when the 'phoneCodeSent' event fires
        } else {
            // Web fallback
            if (typeof firebase === 'undefined') throw new Error("Firebase Web SDK missing");
            webConfirmationResult = await firebase.auth().signInWithPhoneNumber(phone, window.recaptchaVerifier);
            document.getElementById('loginBoxPhone').style.display = 'none';
            document.getElementById('loginBoxOtp').style.display = 'block';
            if (btn) btn.innerText = "SEND OTP";
        }
    } catch (err) {
        if (errEl) errEl.innerText = "❌ " + (err.message || "Failed to send OTP");
        if (btn) btn.innerText = "SEND OTP";
    }
}

async function verifyOtp() {
    var otpEl = document.getElementById('lOtp');
    var errEl = document.getElementById('lErrOtp');
    if (!otpEl) return;

    var code = otpEl.value.trim();
    if (!code) { if (errEl) errEl.innerText = "Enter OTP code"; return; }

    var btn = document.getElementById('btnVerifyOtp');
    if (btn) btn.innerText = "Verifying...";
    if (errEl) errEl.innerText = "";

    try {
        let phoneStr = "";
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            await window.CapacitorFirebaseAuthentication.confirmVerificationCode({
                verificationId: dsVerificationId,
                verificationCode: code
            });
        } else {
            // Web fallback
            if (!webConfirmationResult) throw new Error("No OTP requested");
            await webConfirmationResult.confirm(code);
        }

        var inputPhone = document.getElementById('lPhone').value.trim();
        var countryCode = document.getElementById('lCountry') ? document.getElementById('lCountry').value.trim() : "+91";
        phoneStr = inputPhone.startsWith('+') ? inputPhone : countryCode + inputPhone;

        checkUserInFirestore(phoneStr).then(function (exists) {
            if (exists) {
                completeLogin(phoneStr);
            } else {
                document.getElementById('loginBoxOtp').style.display = 'none';
                document.getElementById('loginBoxRegister').style.display = 'block';
                window.pendingUserPhone = phoneStr;
            }
        });
    } catch (err) {
        if (errEl) errEl.innerText = "❌ Invalid OTP or Error: " + (err.message || "");
        if (btn) btn.innerText = "VERIFY";
    }
}

async function checkUserInFirestore(phone) {
    try {
        var token = "";
        if (window.CapacitorFirebaseAuthentication) {
            var tRes = await window.CapacitorFirebaseAuthentication.getIdToken();
            if (tRes && tRes.token) token = tRes.token;
        } else if (typeof firebase !== 'undefined' && firebase.auth && firebase.auth().currentUser) {
            token = await firebase.auth().currentUser.getIdToken();
        }
        var headers = {};
        if (token) headers['Authorization'] = 'Bearer ' + token;

        async function doQuery(p) {
            var query = {
                structuredQuery: {
                    from: [{ collectionId: "Users" }],
                    where: {
                        fieldFilter: { field: { fieldPath: "phone" }, op: "EQUAL", value: { stringValue: p } }
                    },
                    limit: 1
                }
            };
            var res = await fetch("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents:runQuery", {
                method: "POST", headers: headers, body: JSON.stringify(query)
            });
            var data = await res.json();
            if (data && data.length > 0 && data[0].document) return true;
            return false;
        }

        var found = await doQuery(phone);
        if (found) return true;

        var altPhone = phone.replace(/^\+91/, '');
        if (phone !== altPhone) {
            found = await doQuery(altPhone);
            if (found) return true;
        }
        return false;
    } catch (e) {
        console.error(e);
        return false;
    }
}

async function saveProfile() {
    var nameEl = document.getElementById('rName');
    var stationEl = document.getElementById('rStation');
    var stateEl = document.getElementById('rState');
    var firm = document.getElementById('rFirm').value.trim();
    var err = document.getElementById('rErr');

    var name = nameEl.value.trim();
    var station = stationEl.value.trim();
    var state = stateEl.value.trim();

    var hasErr = false;

    if (!name) {
        nameEl.classList.add("error");
        nameEl.placeholder = "Name is Required *";
        hasErr = true;
    } else {
        nameEl.classList.remove("error");
        nameEl.placeholder = "Name *";
    }

    if (!station) {
        stationEl.classList.add("error");
        stationEl.placeholder = "Station is Required *";
        hasErr = true;
    } else {
        stationEl.classList.remove("error");
        stationEl.placeholder = "Station *";
    }

    if (!state) {
        stateEl.classList.add("error");
        stateEl.placeholder = "State is Required *";
        hasErr = true;
    } else {
        stateEl.classList.remove("error");
        stateEl.placeholder = "State *";
    }

    if (hasErr) {
        if (err) err.innerText = "";
        return;
    }

    var phone = window.pendingUserPhone;
    if (!phone) {
        if (typeof firebase !== 'undefined' && firebase.auth().currentUser) {
            phone = firebase.auth().currentUser.phoneNumber;
        } else if (window.dsCustomerDetails && window.dsCustomerDetails.phone) {
            phone = window.dsCustomerDetails.phone;
        } else {
            // Very last resort: pull from localstorage if strictly available
            phone = localStorage.getItem("dsUserPhone") || "";
        }
    }
    
    // Ensure we don't send undefined, otherwise Firestore Rules fail
    if (!phone) {
        err.innerText = "Error: Phone number is missing. Please login again.";
        return;
    }

    var doc = {
        fields: {
            name: { stringValue: name },
            firm: { stringValue: firm },
            station: { stringValue: station },
            state: { stringValue: state },
            phone: { stringValue: phone },
            createdAt: { timestampValue: new Date().toISOString() }
        }
    };

    document.getElementById('btnSaveProfile').innerText = "Saving...";
    try {
        var res = await window.fetchWithRetry("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Users", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(doc)
        });
        if (res.ok) {
            completeLogin(phone);
        } else {
            var errData = await res.json();
            console.error("Profile Save Error:", errData);
            err.innerText = "Error saving profile: " + (errData.error ? errData.error.message : "");
            document.getElementById('btnSaveProfile').innerText = "SAVE & CONTINUE";
        }
    } catch (e) {
        err.innerText = "Network error: " + e.message;
        document.getElementById('btnSaveProfile').innerText = "SAVE & CONTINUE";
    }
}

async function checkAdminStatus(phone) {
    try {
        var query = {
            structuredQuery: {
                from: [{ collectionId: "Users" }],
                where: { fieldFilter: { field: { fieldPath: "phone" }, op: "EQUAL", value: { stringValue: phone } } },
                limit: 1
            }
        };
        // Securely route through fetchWithRetry to append authorization context
        var res = await window.fetchWithRetry("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents:runQuery", {
            method: "POST",
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(query)
        });
        var data = await res.json();
        if (data && data.length > 0 && data[0].document) {
            var f = data[0].document.fields;

            // Cache identity so it is immediately available for the Live Analytics engine
            let userProfile = {
                name: f.name ? f.name.stringValue : "",
                firm: f.firm ? f.firm.stringValue : "",
                station: f.station ? f.station.stringValue : "",
                state: f.state ? f.state.stringValue : "",
                phone: phone
            };
            localStorage.setItem("dsCustomerDetails", JSON.stringify(userProfile));

            if (f.isAdmin && f.isAdmin.booleanValue === true) {
                localStorage.setItem('dsIsAdmin', 'true');
                window.isSuperAdmin = true;
                if (document.getElementById('menuLiveAdmin')) document.getElementById('menuLiveAdmin').style.display = 'flex';
                var fabAdd = document.getElementById('fabAddProduct');
                if (fabAdd) fabAdd.style.display = window.isAdminMode ? 'flex' : 'none';
            } else {
                localStorage.setItem('dsIsAdmin', 'false');
                window.isSuperAdmin = false;
                if (document.getElementById('menuLiveAdmin')) document.getElementById('menuLiveAdmin').style.display = 'none';
            }
        }
    } catch (e) {
        if (typeof window.logAppError === 'function') window.logAppError("checkAdminStatus", e.message);
    }
}

function completeLogin(phoneStr) {
    try { localStorage.setItem("dsUserToken", phoneStr); } catch (e) { }
    activeUser = phoneStr;
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('appBody').style.display = 'flex';
    checkAdminStatus(phoneStr);
    initApp();
}

function backToPhone() {
    document.getElementById('loginBoxOtp').style.display = 'none';
    document.getElementById('loginBoxPhone').style.display = 'block';
    document.getElementById('lErr').innerText = "";
    document.getElementById('lErrOtp').innerText = "";
    document.getElementById('lOtp').value = "";
    var btn = document.getElementById('btnSendOtp');
    if (btn) btn.innerText = "SEND OTP";
}

function initApp() {
    var bootScreen = document.getElementById('boot');
    if (typeof window.processCameraOutbox === 'function') window.processCameraOutbox();

    function processProducts(docs) {
        var validCounter = 0;
        allProducts = [];

        docs.forEach(d => {
            var f = d.fields || {};
            var name = f.name ? f.name.stringValue : "";
            var isWix = JSON.stringify(f).toLowerCase().includes("wix import");

            if (name && name.toLowerCase() !== "temp" && name.toLowerCase() !== "unnamed" && !isWix) {
                var finalPrice = f.price ? (f.price.doubleValue || f.price.integerValue || 0) : 0;
                var finalPacking = f.packing ? (f.packing.stringValue || (f.packing.integerValue !== undefined ? String(f.packing.integerValue) : "") || (f.packing.doubleValue !== undefined ? String(f.packing.doubleValue) : "") || "1") : "1";

                // --- ADMIN & INVENTORY PARSING ---
                var actualDocId = d.name ? d.name.split('/').pop() : "";
                var stockMap = {};
                if (f.stock && f.stock.mapValue && f.stock.mapValue.fields) {
                    for (var k in f.stock.mapValue.fields) {
                        var vObj = f.stock.mapValue.fields[k];
                        stockMap[k] = parseInt(vObj.integerValue || vObj.doubleValue || vObj.stringValue || 0);
                    }
                }
                var tStock = 999;
                if (f.stock) {
                    if (stockMap['FULLY_PACKED'] === 1) {
                        tStock = 0;
                    } else {
                        var allDesignKeys = Object.keys(stockMap).filter(k => k !== 'FULLY_PACKED');
                        if (allDesignKeys.length > 0) {
                            var designSum = allDesignKeys.reduce((a, k) => a + stockMap[k], 0);
                            tStock = designSum > 0 ? designSum : 0;
                        } else {
                            tStock = 999;
                        }
                    }
                }

                allProducts.push({
                    docId: actualDocId,
                    stock: stockMap,
                    totalStock: tStock,
                    id: "p_" + validCounter,
                    name: name,
                    sku: f.sku ? f.sku.stringValue : "",
                    price: finalPrice,
                    cat: f.cat ? f.cat.stringValue : "Uncategorized",
                    gridUrl: f.gridUrl ? f.gridUrl.stringValue : "",
                    zoomUrl: f.zoomUrl ? f.zoomUrl.stringValue : "",
                    coverDesignId: f.coverDesignId ? f.coverDesignId.stringValue : "",
                    mrp: f.mrp ? (f.mrp.doubleValue || f.mrp.integerValue || 0) : 0,
                    fabric: f.fabric ? f.fabric.stringValue : "",
                    packing: finalPacking,
                    mult: f.mult ? (f.mult.integerValue || 8) : 8,
                    ready: f.ready ? f.ready.stringValue : "",
                    jari: f.jari ? f.jari.stringValue : "",
                    border: f.border ? f.border.stringValue : "",
                    cut: f.cut ? f.cut.stringValue : "",
                    pallu: f.pallu ? f.pallu.stringValue : "",
                    blouse: f.blouse ? f.blouse.stringValue : "",
                    work: f.work ? f.work.stringValue : "",
                    updateTime: f.latestImageAddedAt ? (f.latestImageAddedAt.timestampValue || f.latestImageAddedAt.stringValue) : (d.createTime || d.updateTime || "")
                });
                validCounter++;
            }
        });

        displayList = [...allProducts];

        try {
            var updatedCart = {};
            for (var k in cart) {
                var c = cart[k];
                if (c && c.p) {
                    var match = allProducts.find(x => (c.p.sku && x.sku === c.p.sku) || (x.name === c.p.name));
                    if (match) {
                        c.p = match;
                        var newKey = match.id + '_' + c.design;
                        updatedCart[newKey] = c;
                    } else {
                        updatedCart[k] = c;
                    }
                }
            }
            cart = updatedCart;
            localStorage.setItem("dsCart", JSON.stringify(cart));
        } catch (e) { console.error("Cart sync error:", e); }

        if (typeof populateCategories === "function") populateCategories();
        if (typeof renderHorizontalCategories === "function") renderHorizontalCategories();
        renderProductGrid(displayList);
        updateCartHeader();

        let pidParam = new URLSearchParams(window.location.search).get('pid') || (typeof window.pendingDeepLinkPid !== 'undefined' ? window.pendingDeepLinkPid : null);
        if (pidParam) {
            window.pendingDeepLinkPid = null;
            if (!window.isGuestMode) {
                history.replaceState(null, '', window.location.pathname);
            }
            setTimeout(() => { if (typeof openDetail === 'function') openDetail(pidParam); }, 500);
        }
    }

    // ── STEP 1: Instantly render from cache (zero wait time) ──────────────
    var loadedFromCache = false;
    try {
        var cachedDocs = JSON.parse(localStorage.getItem("dsOfflineProducts"));
        if (cachedDocs && cachedDocs.length > 0) {
            if (bootScreen) bootScreen.style.display = 'none';
            processProducts(cachedDocs);
            loadedFromCache = true;
        }
    } catch (e) { }

    // Show boot screen only if we have nothing cached
    if (!loadedFromCache && bootScreen) bootScreen.style.display = 'flex';

    // ── STEP 2: Fetch fresh data in background with 10s timeout ────────────
    fetch("https://us-central1-durga-sarees.cloudfunctions.net/getMasterCache")
        .then(res => res.json())
        .then(data => {
            if (data && data.success && data.cache) {
                try {
                    localStorage.setItem("dsMasterCache", JSON.stringify(data.cache));
                    window.dsMasterCache = data.cache;
                } catch (e) { }
            }
        }).catch(e => console.log("Master cache fetch failed:", e));

    var fetchPromise = window.fetchWithRetry(FIRESTORE_PRODUCTS_URL, {}, 2);
    var timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("Boot timeout")), 10000));

    Promise.race([fetchPromise, timeoutPromise])
        .then(res => res.json())
        .then(data => {
            var docs = data.documents || [];
            if (docs.length > 0) {
                // Only save to cache and re-render if data actually changed
                var newDataStr = JSON.stringify(docs);
                var oldDataStr = "";
                try { oldDataStr = localStorage.getItem("dsOfflineProducts") || ""; } catch (e) { }

                if (newDataStr !== oldDataStr) {
                    try { localStorage.setItem("dsOfflineProducts", newDataStr); } catch (e) { }

                    if (loadedFromCache) {
                        // Force UI update to show the new data fetched from Firebase
                        processProducts(docs);
                    }
                }
            }
            if (bootScreen) bootScreen.style.display = 'none';
            // If we didn't have cache initially, render now
            if (!loadedFromCache) {
                processProducts(docs);
            }
            setTimeout(() => syncImages(true), 2000);
        })
        .catch(err => {
            console.log("Offline or fetch failed:", err);
            if (bootScreen) bootScreen.style.display = 'none';
            // If we already rendered from cache, do nothing - grid is already showing
            if (!loadedFromCache) {
                try {
                    var cachedDocs2 = JSON.parse(localStorage.getItem("dsOfflineProducts"));
                    if (cachedDocs2 && cachedDocs2.length > 0) {
                        processProducts(cachedDocs2);
                        return;
                    }
                } catch (e) { }
                processProducts([]);
            }
        });
}

// ==========================================
// 🚀 FAST PROGRESSIVE IMAGE LOADER (GRID -> ZOOM)
// ==========================================
// 🛡️ THE FIX: Loads the low-res Grid image instantly, then quietly upgrades to Zoom!
// ==========================================
// 📦 INDEXEDDB CACHE DATABASE FOR IMAGES
// ==========================================
var dbName = "DurgaSareesCache";
var storeName = "images";
var cachedDB = null;

function getDB() {
    if (cachedDB) {
        return Promise.resolve(cachedDB);
    }
    return new Promise((resolve, reject) => {
        var request = indexedDB.open(dbName, 2);
        request.onupgradeneeded = function (e) {
            var db = e.target.result;
            if (!db.objectStoreNames.contains(storeName)) {
                db.createObjectStore(storeName);
            }
            if (!db.objectStoreNames.contains("outbox")) {
                db.createObjectStore("outbox", { keyPath: "id", autoIncrement: true });
            }
        };
        request.onsuccess = function (e) {
            cachedDB = e.target.result;
            resolve(cachedDB);
        };
        request.onerror = function (e) {
            reject(e.target.error);
        };
    });
}

function saveImageToDB(key, blob) {
    window.sessionImageCache.set(key, blob);
    if (window.sessionImageCache.size > 300) {
        window.sessionImageCache.delete(window.sessionImageCache.keys().next().value);
    }

    if (window.designKeyPrefixCache && typeof key === 'string' && key.includes('%2F')) {
        var prefix = key.substring(0, key.lastIndexOf('%2F') + 3);
        if (window.designKeyPrefixCache[prefix]) delete window.designKeyPrefixCache[prefix];
    }
    return getDB().then(db => {
        return new Promise((resolve, reject) => {
            var tx = db.transaction(storeName, "readwrite");
            var store = tx.objectStore(storeName);
            var req = store.put(blob, key);
            req.onsuccess = () => resolve(true);
            req.onerror = () => reject(req.error);
        });
    }).catch(e => {
        console.error("IndexedDB write failed", e);
        return false;
    });
}

function deleteImageFromDB(key) {
    window.sessionImageCache.delete(key);

    if (window.designKeyPrefixCache && typeof key === 'string' && key.includes('%2F')) {
        var prefix = key.substring(0, key.lastIndexOf('%2F') + 3);
        if (window.designKeyPrefixCache[prefix]) delete window.designKeyPrefixCache[prefix];
    }
    return getDB().then(db => {
        return new Promise((resolve) => {
            var tx = db.transaction(storeName, "readwrite");
            var store = tx.objectStore(storeName);
            var req = store.delete(key);
            req.onsuccess = () => resolve(true);
            req.onerror = () => resolve(false);
        });
    }).catch(() => false);
}

// List all IndexedDB keys that start with a given prefix string
function listDBKeysForPrefix(prefix) {
    return getDB().then(db => {
        return new Promise((resolve) => {
            var tx = db.transaction(storeName, "readonly");
            var store = tx.objectStore(storeName);
            var keys = [];
            // OPTIMIZATION: Use IDBKeyRange to instantly jump to prefix, preventing full DB scan
            var range = IDBKeyRange.bound(prefix, prefix + '\uffff');
            var req = store.openKeyCursor(range);
            req.onsuccess = function (e) {
                var cursor = e.target.result;
                if (cursor) {
                    keys.push(cursor.key);
                    cursor.continue();
                } else {
                    resolve(keys);
                }
            };
            req.onerror = () => resolve([]);
        });
    }).catch(() => []);
}

async function manageProductHDCache(product, action) {
    if (!product) return;
    var zoomUrl = (product.zoomUrl && product.zoomUrl.toLowerCase() !== "none") ? product.zoomUrl : product.gridUrl;

    if (action === 'CACHE') {
        try {
            var bucket = "durga-sarees.firebasestorage.app";
            var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
            var encPath = decodeURIComponent(zoomUrl).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('/');
            var listUrl = fbBase + "?prefix=" + encPath + "/&delimiter=/";

            window.fetchWithRetry(listUrl).then(res => res.json()).then(data => {
                if (data && data.items) {
                    async function processCache() {
                        for (const item of data.items) {
                            var fullUrl = fbBase + encodeURIComponent(item.name) + "?alt=media";
                            var blob = await getImageFromDB(fullUrl);
                            if (!blob) {
                                try {
                                    var r = await fetch(fullUrl);
                                    if (r.ok) {
                                        var newBlob = await r.blob();
                                        await saveImageToDB(fullUrl, newBlob);

                                        // 🟢 LIVE UI INJECTION: Update swipe deck instantly
                                        var liveImgs = document.querySelectorAll('img[data-zoom-url="' + fullUrl + '"]');
                                        if (liveImgs.length > 0) {
                                            var objUrl = URL.createObjectURL(newBlob);
                                            liveImgs.forEach(img => {
                                                if (img.dataset.tempBlobUrl) URL.revokeObjectURL(img.dataset.tempBlobUrl);
                                                img.dataset.tempBlobUrl = objUrl;
                                                img.src = objUrl;
                                                img.dataset.loadedZoom = 'true';
                                            });
                                        }

                                        // 🟢 LIVE FULLSCREEN INJECTION: Update if user is currently zoomed in
                                        var fsImg = document.getElementById('fsImg');
                                        var fsModal = document.getElementById('fsModal');
                                        if (fsImg && fsModal && fsModal.style.display === 'flex') {
                                            var filename = decodeURIComponent(fullUrl.split('%2F').pop().split('?')[0]);
                                            var dName = filename.substring(0, filename.lastIndexOf('.'));
                                            if (typeof fsDesignId !== 'undefined') {
                                                var isCoverMatch = (fsDesignId === 'DIRECT' || fsDesignId === 'Cover') && /^(01|1|cover)$/i.test(dName);
                                                if (fsDesignId === dName || isCoverMatch) {
                                                    fsImg.src = URL.createObjectURL(newBlob);
                                                }
                                            }
                                        }
                                    }
                                } catch (e) { console.warn("Background fetch skipped:", e); }
                            }
                        }
                    }
                    processCache();
                }
            }).catch(e => { console.warn("HD Cache Fetch aborted (Offline/Network Error):", e); return; });
        } catch (e) { console.warn("HD Cache Fetch aborted (Offline/Network Error):", e); return; }
    } else if (action === 'DELETE') {
        if (favorites[product.id] === true) return;
        var totalQty = 0;
        for (var k in cart) {
            if (k.startsWith(product.id + '_')) totalQty += cart[k].qty;
        }
        if (totalQty > 0) return;

        if (!product.zoomUrl || product.zoomUrl === product.gridUrl || product.zoomUrl.toLowerCase() === "none") return;

        var cleanZoom = decodeURIComponent(zoomUrl).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
        var encZoomPath = cleanZoom.split('/').map(s => encodeURIComponent(s)).join('%2F');
        var bucket = "durga-sarees.firebasestorage.app";
        var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
        var prefix = fbBase + encZoomPath + "%2F";

        var keys = await listDBKeysForPrefix(prefix);
        for (var i = 0; i < keys.length; i++) {
            await deleteImageFromDB(keys[i]);
        }
    }
}

// 🧠 CORE FIX: Resolves the exact IndexedDB cache key for a given design label
// It ignores file extensions (.jpg vs .webp) and padding (2 vs 02) to guarantee a match
window.findDesignKeyInCache = async function (gridUrl, designLabel) {
    if (!gridUrl || gridUrl.startsWith('http')) return null;

    var cleanGrid = gridUrl.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
    var encGridPath = cleanGrid.split('/').map(s => encodeURIComponent(s)).join('%2F');
    var bucket = "durga-sarees.firebasestorage.app";
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
    var prefix = fbBase + encGridPath + "%2F";

    if (!window.designKeyPrefixCache) window.designKeyPrefixCache = {};
    if (!window.designKeyPrefixCache[prefix]) {
        window.designKeyPrefixCache[prefix] = await listDBKeysForPrefix(prefix);
    }
    var keys = window.designKeyPrefixCache[prefix];
    if (!keys || keys.length === 0) return null;

    var targetNum = parseInt(String(designLabel).replace(/\D/g, ''));
    var bestKey = null;

    for (var k of keys) {
        var filenameEnc = k.replace(prefix, '').split('?')[0];
        var filename = decodeURIComponent(filenameEnc).toLowerCase();
        var nameWithoutExt = filename.substring(0, filename.lastIndexOf('.'));
        if (!nameWithoutExt) nameWithoutExt = filename;

        // 1. Exact Name Match (e.g. "Red")
        if (nameWithoutExt === String(designLabel).toLowerCase()) return k;

        // 2. Numeric Match (e.g. "2" == "02")
        if (!isNaN(targetNum)) {
            var fileNum = parseInt(nameWithoutExt.replace(/\D/g, ''));
            if (fileNum === targetNum) {
                bestKey = k; // Store it, but keep searching just in case there's an exact match
            }
        }
    }

    return bestKey;
};

function getImageFromDB(key) {
    if (window.sessionImageCache.has(key)) return Promise.resolve(window.sessionImageCache.get(key));
    return getDB().then(db => {
        return new Promise((resolve, reject) => {
            var tx = db.transaction(storeName, "readonly");
            var store = tx.objectStore(storeName);
            var req = store.get(key);
            req.onsuccess = () => {
                var blob = req.result;
                if (blob) {
                    if (blob.size === 0) {
                        resolve(null);
                        return;
                    }
                    window.sessionImageCache.set(key, blob);
                    if (window.sessionImageCache.size > 300) {
                        window.sessionImageCache.delete(window.sessionImageCache.keys().next().value);
                    }
                }
                resolve(blob || null);
            };
            req.onerror = () => reject(req.error);
        });
    }).catch(e => {
        console.error("IndexedDB read failed", e);
        return null;
    });
}

function checkImageInDB(key) {
    if (window.sessionImageCache.has(key)) return Promise.resolve(true);
    return getDB().then(db => {
        return new Promise((resolve) => {
            var tx = db.transaction(storeName, "readonly");
            var store = tx.objectStore(storeName);
            var req = store.get(key);
            req.onsuccess = () => {
                var blob = req.result;
                if (blob && blob.size > 0) {
                    resolve(true);
                } else {
                    resolve(false);
                }
            };
            req.onerror = () => resolve(false);
        });
    }).catch(e => {
        return false;
    });
}

function getCachedImageBlob(url) {
    return getImageFromDB(url).then(blob => {
        if (blob) return blob;
        if (url.includes('%2F0')) {
            var fallbackUrl = url.replace('%2F0', '%2F');
            return getImageFromDB(fallbackUrl);
        }
        return null;
    });
}



// 🚀 FAST PROGRESSIVE IMAGE LOADER (GRID -> ZOOM)
// ==========================================
// 🛡️ THE FIX: Loads the low-res Grid image instantly, then quietly upgrades to Zoom!
window.renderWebpFromFolder = function (imgElement, gridPath, zoomPath, targetFile) {
    if (!gridPath || gridPath.trim() === "" || gridPath.toLowerCase() === "none") {
        imgElement.src = window.dsMissingImage;
        return;
    }

    var bucket = "durga-sarees.firebasestorage.app";
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
    var encGridPath = gridPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
    var encZoomPath = (zoomPath && zoomPath !== "None") ? decodeURIComponent(String(zoomPath)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F') : encGridPath;

    var fileToFetch = targetFile ? targetFile : "cover.webp"; // Main grid: always try cover.webp first

    // If cache confirms cover is missing, jump straight to fallback map
    if ((fileToFetch === "cover.webp" || fileToFetch === "cover1.webp") && window.coverExistsMap && window.coverExistsMap[gridPath] === false) {
        if (window.dsFallbackMap && window.dsFallbackMap[gridPath]) {
            fileToFetch = window.dsFallbackMap[gridPath];
        } else {
            tryFolderListFallback();
            return;
        }
    }

    var actualUrl = fbBase + encGridPath + "%2F" + encodeURIComponent(fileToFetch) + "?alt=media";
    var lowResUrl = actualUrl;

    var isNativeLoading = (imgElement.getAttribute('src') === actualUrl || imgElement.src === actualUrl);

    // ALWAYS check IndexedDB to support Offline Mode.
    // The previous bypass completely skipped IDB which broke offline caching.
    getImageFromDB(actualUrl).then(function (blob) {
        if (blob) {
            var objectUrl = URL.createObjectURL(blob);
            // Only inject the IDB blob if the native URL hasn't already finished loading.
            // This prevents flicker for online users, but instantly loads for offline users!
            if (!isNativeLoading || !imgElement.complete || imgElement.naturalWidth === 0) {
                imgElement.src = objectUrl;
            }
            imgElement.dataset.tempBlobUrl = objectUrl;
            if (window.coverExistsMap) window.coverExistsMap[gridPath] = true;
            if (window.saveCoverExistsMap) window.saveCoverExistsMap();
        } else {
            // Not in IDB cache. Wait for the native network load to fail before trying fallbacks.
            if (isNativeLoading) {
                if (imgElement.complete && imgElement.naturalWidth === 0) {
                    loadFromNetwork();
                } else {
                    imgElement.onerror = function () {
                        imgElement.onerror = null;
                        loadFromNetwork();
                    };
                }
            } else {
                loadFromNetwork();
            }
        }
    });

    function showPlaceholder(err) {
        imgElement.src = window.dsMissingImage;
        imgElement.onerror = null;
        window.brokenImagesMap = window.brokenImagesMap || {};
        window.brokenImagesMap[gridPath] = true;
        var reason = (err && err.message) ? err.message : 'Unknown HTTP/Network Error';
        if (typeof window.logAppError === 'function') {
            window.logAppError('Image Load Failed', 'Grid: ' + gridPath + ' | Reason: ' + reason);
        }
    }

    // Strip Excel 'ready' logic - always discover files from Firebase folder listing
    function tryToLoadLatestReadyDesign() {
        tryFolderListFallback();
    }

    // 🔄 LAST RESORT: Call Firebase list API to discover actual filenames
    function tryFolderListFallback() {
        // Check if we already cached the fallback filename — try IDB first
        if (window.dsFallbackMap[gridPath]) {
            var cachedFile = window.dsFallbackMap[gridPath];
            var cachedUrl = fbBase + encGridPath + "%2F" + encodeURIComponent(cachedFile) + "?alt=media";
            getImageFromDB(cachedUrl).then(function (blob) {
                if (blob) {
                    var objUrl = URL.createObjectURL(blob);
                    imgElement.src = objUrl;
                    imgElement.dataset.tempBlobUrl = objUrl;
                } else {
                    imgElement.src = cachedUrl;
                    imgElement.onerror = function () {
                        // The cached fallback file is dead (e.g. admin deleted it). Clear it and try listing folder again.
                        imgElement.onerror = null;
                        delete window.dsFallbackMap[gridPath];
                        saveFallbackMap();
                        tryFolderListFallback();
                    };
                }
            });
            return;
        }

        var listPrefix = gridPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('/') + '/';
        var listUrl = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o?prefix=" + listPrefix + "&delimiter=/";

        window.fetchWithRetry(listUrl)
            .then(function (res) { return res.json(); })
            .then(function (data) {
                var files = (data.items || [])
                    .map(function (item) { return item.name.substring(item.name.lastIndexOf('/') + 1); })
                    .filter(function (f) { return /\.(webp|jpg|jpeg|png)$/i.test(f); });

                if (files.length > 0) {
                    files.sort(function (a, b) {
                        if (a === "cover.webp") return -1;
                        if (b === "cover.webp") return 1;
                        if (a === "cover1.webp") return -1;
                        if (b === "cover1.webp") return 1;
                        if (a.toLowerCase() === "cover.webp" && b.toLowerCase() !== "cover.webp") return -1;
                        if (b.toLowerCase() === "cover.webp" && a.toLowerCase() !== "cover.webp") return 1;
                        return (parseInt(a.replace(/\D/g, '')) || 999) - (parseInt(b.replace(/\D/g, '')) || 999);
                    });
                    var firstFile = files[0];
                    dsFallbackMap[gridPath] = firstFile;
                    saveFallbackMap();
                    var firstUrl = fbBase + encGridPath + "%2F" + encodeURIComponent(firstFile) + "?alt=media";
                    // Try IDB first, then network
                    getImageFromDB(firstUrl).then(function (blob) {
                        if (blob) {
                            var objUrl = URL.createObjectURL(blob);
                            imgElement.src = objUrl;
                            imgElement.dataset.tempBlobUrl = objUrl;
                        } else {
                            imgElement.src = firstUrl;
                            imgElement.onerror = function () { showPlaceholder(new Error("Image element onload onerror triggered")); };
                        }
                    });
                } else {
                    showPlaceholder(new Error("Folder list empty"));
                }
            })
            .catch(function (err) { showPlaceholder(err); });
    }


    function loadFromNetwork() {
        // Priority queue: try cover.webp first, then cover1.webp, then fall back to folder listing
        var fallbackQueue = [];
        if (targetFile && targetFile !== "cover.webp" && targetFile !== "cover1.webp") fallbackQueue.push(targetFile);
        if (!fallbackQueue.includes("cover.webp")) fallbackQueue.push("cover.webp");
        if (!fallbackQueue.includes("cover1.webp")) fallbackQueue.push("cover1.webp");

        var queueIndex = fallbackQueue.indexOf(fileToFetch) !== -1 ? fallbackQueue.indexOf(fileToFetch) : 0;

        async function fetchImageSecurely(targetUrl) {
            try {
                var cacheBuster = (targetUrl.includes("cover.webp") || targetUrl.includes("cover1.webp")) ? "&_cb=" + Date.now() : "";
                var res = await window.fetchWithRetry(targetUrl + cacheBuster);
                if (res.ok) {
                    var blob = await res.blob();
                    await saveImageToDB(cacheKey, blob);
                    if (imgElement.dataset.tempBlobUrl) URL.revokeObjectURL(imgElement.dataset.tempBlobUrl);
                    var objUrl = URL.createObjectURL(blob);
                    imgElement.dataset.tempBlobUrl = objUrl;
                    imgElement.src = objUrl;

                } else {
                    throw new Error("HTTP Status " + res.status);
                }
            } catch (err) {
                queueIndex++;
                if (queueIndex < fallbackQueue.length) {
                    var nextUrl = fbBase + encGridPath + "%2F" + fallbackQueue[queueIndex] + "?alt=media";
                    fetchImageSecurely(nextUrl);
                } else {
                    // Final fallback sequence using token validation
                    var finalZoomUrl = fbBase + encZoomPath + "%2Fcover.webp?alt=media&_cb=" + Date.now();
                    try {
                        var zRes = await window.fetchWithRetry(finalZoomUrl);
                        if (zRes.ok) {
                            var zBlob = await zRes.blob();
                            if (zBlob.size === 0) throw new Error("Zero byte cover");
                            if (imgElement.dataset.tempBlobUrl) URL.revokeObjectURL(imgElement.dataset.tempBlobUrl);
                            var zObj = URL.createObjectURL(zBlob);
                            imgElement.dataset.tempBlobUrl = zObj;
                            imgElement.src = zObj;
                        } else {
                            if (zRes.status === 404) {
                                coverExistsMap[gridPath] = false;
                                saveCoverExistsMap();
                            }
                            tryToLoadLatestReadyDesign();
                        }
                    } catch (e) {
                        if (e && e.message && e.message.includes("HTTP 404")) {
                            coverExistsMap[gridPath] = false;
                            saveCoverExistsMap();
                        }
                        tryToLoadLatestReadyDesign();
                    }
                }
            }
        }
        fetchImageSecurely(lowResUrl);
    }

    var cacheKey = (fileToFetch === "cover.webp" || fileToFetch === "cover1.webp") ? gridPath : lowResUrl;

    // ALWAYS check IndexedDB cache first for ALL images (Cover, Fallback, and Specific Cart Designs)
    getImageFromDB(cacheKey).then(function (blob) {
        if (blob) {
            var objectUrl = URL.createObjectURL(blob);
            imgElement.src = objectUrl;
            imgElement.onerror = function () {
                loadFromNetwork();
            };
        } else {
            loadFromNetwork();
        }
    }).catch(function (err) {
        loadFromNetwork();
    });

    // 2. Background Load High-Res Zoom Image (if applicable) — saved to IndexedDB for PDF speed
    if (zoomPath && zoomPath.trim() !== "" && zoomPath.toLowerCase() !== "none") {
        var encZoomPath = decodeURIComponent(String(zoomPath)).trim().replace(/\\/g, '/').split('/').map(encodeURIComponent).join('%2F');
        var highResUrl = fbBase + encZoomPath + "%2F" + encodeURIComponent(fileToFetch) + "?alt=media";

        // Check if already in IndexedDB before fetching
        getImageFromDB(highResUrl).then(function (existingBlob) {
            if (!existingBlob) {
                fetch(highResUrl)
                    .then(function (res) { return res.ok ? res.blob() : null; })
                    .then(function (blob) {
                        if (blob && blob.size > 0) {
                            if (imgElement.dataset.tempBlobUrl) {
                                URL.revokeObjectURL(imgElement.dataset.tempBlobUrl);
                            }
                            var objUrl = URL.createObjectURL(blob);
                            imgElement.dataset.tempBlobUrl = objUrl;
                            imgElement.src = objUrl;
                        }
                    })
                    .catch(function () { });
            } else {
                if (imgElement.dataset.tempBlobUrl) {
                    URL.revokeObjectURL(imgElement.dataset.tempBlobUrl);
                }
                var objUrl = URL.createObjectURL(existingBlob);
                imgElement.dataset.tempBlobUrl = objUrl;
                imgElement.src = objUrl;
            }
        }).catch(function () {
            var hdImage = new Image();
            hdImage.onload = function () { imgElement.src = highResUrl; };
            hdImage.src = highResUrl;
        });
    }
};

// ====================================
// EXACT UI RESTORATION (MRP, PACKING, ADD BTN)
// ====================================
function buildCardDetails(p) {
    var totalQty = 0;
    for (var k in cart) { if (cart[k].p.id === p.id) totalQty += parseInt(cart[k].qty) || 0; }

    var coverKey = p.id + '_DIRECT';
    var coverQty = cart[coverKey] ? parseInt(cart[coverKey].qty) || 0 : 0;

    var parsedPrice = parseInt(p.price) || 0;
    var displayMrp = parseInt(p.mrp) || Math.round(parsedPrice / 0.70);
    var offPercent = displayMrp > parsedPrice ? Math.round(((displayMrp - parsedPrice) / displayMrp) * 100) : 30;
    var favClass = favorites[p.id] ? "fas fa-heart fav-active" : "far fa-heart fav-inactive";

    var h = [];
    h.push('<div style="display:flex; align-items:center; width:100%; gap:4px; overflow:hidden;">');
    h.push('<div class="ci-brand" onclick="window.openProductDetailsModal(\'' + p.id + '\', event)" style="flex:1 1 0; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:clip; margin:0; cursor:pointer;">' + esc(p.name) + '</div>');

    var packLen = String(p.packing || "1").length;
    var displayLen = Math.min(packLen, 8);
    h.push('<input type="text" class="pack-input-inline" value="' + esc(p.packing) + '" readonly onclick="event.stopPropagation()" style="flex-shrink:0; text-align:right; width:' + (displayLen + 0.5) + 'ch !important; min-width:1ch !important; max-width:7.5ch !important; font-size:11px !important; padding:0; margin:0;">');
    h.push('<div class="fav-btn-inline" style="flex-shrink:0; padding-left:0;" onclick="toggleFav(\'' + p.id + '\', event)"><i class="' + favClass + '"></i></div>');
    h.push('</div>');

    h.push('<div class="ci-fabric" style="margin-top:0;">' + esc(p.fabric) + '</div>');
    h.push('<div style="display:flex; justify-content:space-between; align-items:center; margin-top:0; width:100%; gap:2px;">');

    // Left side: Price, MRP, OFF
    h.push('<div style="display:flex; align-items:center; gap:4px; flex:1; min-width:0; overflow:hidden; white-space:nowrap;">');
    h.push('<span style="font-weight:700; font-size:14px; color:#282c3f;">₹' + parsedPrice + '</span>');
    if (displayMrp > 0) h.push('<span style="font-size:10px; color:#94969f; text-decoration:line-through; flex-shrink:1; text-overflow:ellipsis; overflow:hidden;">₹' + displayMrp + '</span>');
    if (offPercent > 0) h.push('<span style="font-size:10px; color:#ff905a; font-weight:700; flex-shrink:0;">' + offPercent + '% OFF</span>');
    h.push('</div>');

    // Right side: ADD / QTY
    h.push('<div style="flex-shrink:0;">');
    if (!window.isAdminMode && p.totalStock === 0) {
        h.push('<div style="background: red; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 11px;">PACKED</div>');
    } else if (coverQty === 0 || isNaN(coverQty)) {
        h.push('<div class="add-btn-clean" onclick="chgMainRow(\'' + p.id + '\', 1); event.stopPropagation();">ADD</div>');
    } else {
        h.push('<div class="qty-clean" onclick="event.stopPropagation()">');
        h.push('<button onclick="chgMainRow(\'' + p.id + '\', -1)">−</button>');
        h.push('<input type="number" id="mqty-' + p.id + '" value="' + coverQty + '" readonly>');
        h.push('<button onclick="chgMainRow(\'' + p.id + '\', 1)">+</button>');
        h.push('</div>');
    }
    h.push('</div>');
    h.push('</div>');
    return h.join('');
}

function refreshCardUI(pid) {
    var p = allProducts.find(x => x.id === pid);
    if (!p) return;
    var wrap = document.getElementById('detail-wrap-' + pid);
    if (wrap) wrap.innerHTML = buildCardDetails(p);

    var totalQty = 0;
    for (var k in cart) { if (cart[k].p.id === pid) totalQty += parseInt(cart[k].qty) || 0; }
    var badge = document.getElementById('badge-' + pid);
    if (badge) {
        if (totalQty > 0) { badge.innerText = totalQty + ' in cart'; badge.style.display = 'block'; }
        else { badge.style.display = 'none'; }
    }
    updateCartHeader();
}

window.resolveImageUrlSync = function (p) {
    var gridPath = p.gridUrl;
    if (!gridPath || gridPath.trim() === "" || gridPath.toLowerCase() === "none") {
        return window.dsMissingImage || "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
    }
    var bucket = "durga-sarees.firebasestorage.app";
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
    var encGridPath = gridPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
    var fileToFetch = p.coverDesignId ? p.coverDesignId.replace(/\.(webp|jpg|jpeg|png)$/i, '') + '.webp' : "cover.webp";
    if ((fileToFetch === "cover.webp" || fileToFetch === "cover1.webp") && window.coverExistsMap && window.coverExistsMap[gridPath] === false) {
        if (window.dsFallbackMap && window.dsFallbackMap[gridPath]) {
            fileToFetch = window.dsFallbackMap[gridPath];
        } else {
            return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
        }
    }
    return fbBase + encGridPath + "%2F" + encodeURIComponent(fileToFetch) + "?alt=media";
};

function renderProductGrid(products) {
    const gridEl = document.getElementById("grid");
    if (!gridEl) return;

    if (!products || products.length === 0) {
        gridEl.innerHTML = '<div style="grid-column: 1/-1; padding: 40px; text-align:center; width:100%;">No items available.</div>';
        return;
    }

    // Sort products primarily by category (alphabetically), and secondarily by the active sort rule
    var sorted = [...products].sort((a, b) => {
        // --- ADMIN & INVENTORY: OUT OF STOCK TO BOTTOM ---
        if (a.totalStock === 0 && b.totalStock > 0) return 1;
        if (b.totalStock === 0 && a.totalStock > 0) return -1;

        // --- BROKEN IMAGES: JUST ABOVE OUT OF STOCK ---
        window.brokenImagesMap = window.brokenImagesMap || {};
        var aNoImg = (!a.gridUrl || String(a.gridUrl).trim() === "" || String(a.gridUrl).toLowerCase() === "none");
        var bNoImg = (!b.gridUrl || String(b.gridUrl).trim() === "" || String(b.gridUrl).toLowerCase() === "none");
        var aBroken = window.brokenImagesMap[a.gridUrl] === true || aNoImg;
        var bBroken = window.brokenImagesMap[b.gridUrl] === true || bNoImg;
        if (aBroken && !bBroken) return 1;
        if (!aBroken && bBroken) return -1;

        // Secondary sort: Selected sorting rule
        if (currentSort === 'priceAsc') {
            return a.price - b.price;
        } else if (currentSort === 'priceDesc') {
            return b.price - a.price;
        } else if (currentSort === 'new') {
            var timeA = new Date(a.updateTime || 0).getTime();
            var timeB = new Date(b.updateTime || 0).getTime();
            return timeB - timeA;
        } else {
            return 0;
        }
    });

    let htmlBuffer = [];
    sorted.forEach((p) => {
        let imgElementId = "img_" + p.id;
        var totalQty = 0;
        for (var k in cart) { if (cart[k].p.id === p.id) totalQty += parseInt(cart[k].qty) || 0; }
        var bHtml = totalQty > 0 ? `<div class="item-qty-badge" id="badge-${p.id}">${totalQty} in cart</div>` : `<div class="item-qty-badge" id="badge-${p.id}" style="display:none;"></div>`;

        // Advanced Auto-Cropper: Scans image pixels to dynamically remove white borders and text overlay
        window.autoCropImage = function (img) {
            if (img.dataset.cropped === "true") return;
            if (!img.complete || img.naturalWidth === 0) return;
            if (img.src.includes('data:image')) return;

            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;

            try {
                ctx.drawImage(img, 0, 0);
                var imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
            } catch (e) { return; } // Silently fail on CORS

            var w = canvas.width, h = canvas.height;
            var top = 0, bottom = h;

            // Scan for top content (ignore rows that are >60% white)
            for (var y = 0; y < h; y += 2) {
                var bg = 0, chk = 0;
                for (var x = 0; x < w; x += 5) {
                    var i = (y * w + x) * 4;
                    if (imgData[i] > 230 && imgData[i + 1] > 230 && imgData[i + 2] > 230) bg++;
                    chk++;
                }
                if (bg / chk < 0.6) { top = y; break; }
            }
            // Scan for bottom content
            for (var y = h - 1; y >= 0; y -= 2) {
                var bg = 0, chk = 0;
                for (var x = 0; x < w; x += 5) {
                    var i = (y * w + x) * 4;
                    if (imgData[i] > 230 && imgData[i + 1] > 230 && imgData[i + 2] > 230) bg++;
                    chk++;
                }
                if (bg / chk < 0.6) { bottom = y; break; }
            }

            var contentH = bottom - top;
            if (contentH > 0 && contentH < h) {
                var scale = Math.min(h / contentH, 1.35); // Max 35% zoom
                if (scale > 1.02) {
                    var contentCenterY = top + (contentH / 2);
                    var imgCenterY = h / 2;
                    var yOffset = ((imgCenterY - contentCenterY) / h) * 100;
                    img.style.transform = 'scale(' + scale + ') translateY(' + yOffset + '%)';
                    img.style.transformOrigin = 'center center';
                }
            }
            img.dataset.cropped = "true";
        };

        var initialImgSrc = window.resolveImageUrlSync(p);
        var base64Fallback = window.dsMissingImage || "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

        htmlBuffer.push(`
        <div class="card" id="card-${p.id}">
            <div class="thumb" onclick="openDetail('${p.id}')">
                ${bHtml}
                <img id="${imgElementId}" crossorigin="anonymous" onload="if(window.autoCropImage) window.autoCropImage(this)" onerror="this.onerror=null; this.src='${base64Fallback}';" src="${initialImgSrc}" alt="${esc(p.name)}">
            </div>
            <div class="ci" id="detail-wrap-${p.id}">
                ${buildCardDetails(p)}
            </div>
        </div>
        `);

        setTimeout(() => {
            let imgEl = document.getElementById(imgElementId);
            if (imgEl) window.renderWebpFromFolder(imgEl, p.gridUrl, null, p.coverDesignId ? p.coverDesignId.replace(/\.(webp|jpg|jpeg|png)$/i, '') + '.webp' : null);
        }, 0);
    });

    gridEl.innerHTML = htmlBuffer.join('');
}

// ====================================
// CORE FUNCTIONS
// ====================================
function chgMainRow(pid, dir) {
    var p = allProducts.find(x => x.id === pid); if (!p) return;
    if (!window.isAdminMode && p.totalStock === 0) return; // Cart Protection
    var key = p.id + '_DIRECT';
    var curQ = cart[key] ? cart[key].qty : 0;
    var newQ = Math.max(0, curQ + (dir * (p.mult || 1)));

    if (newQ === 0 || isNaN(newQ)) delete cart[key];
    else cart[key] = { p: p, design: 'DIRECT', qty: newQ };

    try { localStorage.setItem("dsCart", JSON.stringify(cart)); } catch (e) { }
    refreshCardUI(pid);

    var totalQty = 0;
    for (var k in cart) { if (k.startsWith(pid + '_')) totalQty += cart[k].qty; }
    manageProductHDCache(p, totalQty > 0 ? 'CACHE' : 'DELETE');
}

function toggleFav(pid, event) {
    if (event) event.stopPropagation();
    if (favorites[pid]) delete favorites[pid]; else favorites[pid] = true;
    try { localStorage.setItem("dsFavs", JSON.stringify(favorites)); } catch (err) { }
    refreshCardUI(pid);

    var p = allProducts.find(x => x.id === pid);
    if (p) manageProductHDCache(p, favorites[pid] ? 'CACHE' : 'DELETE');
}

function updateCartHeader() {
    var count = 0;
    for (var k in cart) {
        if (cart[k] && cart[k].qty) {
            count += parseInt(cart[k].qty) || 0;
        }
    }
    var els = document.querySelectorAll('.cart-badge-top, #cartCountHeader, #floatCartCount');
    els.forEach(e => e.innerText = count);
    var floatBtn = document.getElementById('placeOrderFloat');
    if (floatBtn) {
        if (typeof showOnlyFavs !== 'undefined' && showOnlyFavs) {
            floatBtn.style.display = 'flex';
            floatBtn.innerHTML = '<i class="fas fa-heart-broken"></i> <span>Clear Fav</span>';
            floatBtn.onclick = function () { window.clearFavorites(); };
        } else {
            floatBtn.style.display = count > 0 ? 'flex' : 'none';
            floatBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> <span>Place Order</span>';
            floatBtn.onclick = function () { openCart(); };
        }
    }
}

window.clearFavorites = function () {
    if (confirm("Are you sure you want to clear all favorites?")) {
        favorites = {};
        try { localStorage.setItem("dsFavs", JSON.stringify(favorites)); } catch (e) { }
        if (typeof applyFilter === 'function') applyFilter();
    }
};


// ====================================
// 4. PRODUCT DETAIL (SWIPE DECK)
// ====================================
var missingDesignSvg = "data:image/svg+xml;utf8," + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800">
    <rect width="100%" height="100%" fill="#f5f5f6"/>
    <text x="50%" y="45%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="24" font-weight="bold" fill="#6c757d">Design Image</text>
    <text x="50%" y="52%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="20" fill="#adb5bd">Not Found on Server</text>
</svg>
`);

function loadAndCacheDesignImage(imgEl, url, designGridUrl, productId, fileName, folderPath, isCover, zoomFolderPath, isInStock) {
    if (imgEl.getAttribute('data-loaded-zoom') === 'true') return;
    setTimeout(async function () {
        try {
            // STEP 1: IDB direct hit for zoom (Fastest)
            var zoomBlob = await getImageFromDB(url);
            if (zoomBlob) {
                console.log('[ZOOM] IDB HIT:', fileName);
                // RAM FIX: Revoke old grid placeholder and assign new temp URL
                if (imgEl.dataset.tempBlobUrl) URL.revokeObjectURL(imgEl.dataset.tempBlobUrl);
                var objUrl = URL.createObjectURL(zoomBlob);
                imgEl.dataset.tempBlobUrl = objUrl;
                imgEl.src = objUrl;
                imgEl.dataset.loadedZoom = 'true';
                return;
            }

            // STEP 2: Show grid placeholder from IDB instantly
            var gridBlob = null;
            if (designGridUrl) gridBlob = await getImageFromDB(designGridUrl);
            if (!gridBlob && folderPath) gridBlob = await getImageFromDB(folderPath);
            if (gridBlob && imgEl.dataset.loadedZoom !== 'true') {
                if (imgEl.dataset.tempBlobUrl) URL.revokeObjectURL(imgEl.dataset.tempBlobUrl);
                var gridObjUrl = URL.createObjectURL(gridBlob);
                imgEl.dataset.tempBlobUrl = gridObjUrl;
                imgEl.src = gridObjUrl;
            }

            // STEP 3: No distinct zoom? Mark done.
            if (!url || url === designGridUrl) {
                imgEl.dataset.loadedZoom = 'true';
                return;
            }

            // STEP 4: Fetch zoom from network (RAM ONLY - NO permanent storage bloat)
            console.log('[ZOOM] Network fetch:', fileName);
            var r = await window.fetchWithRetry(url);
            if (r.ok) {
                var blob = await r.blob();
                if (blob.size === 0) throw new Error("Zero byte blob");
                if (isInStock) {
                    saveImageToDB(url, blob);
                    console.log('[ZOOM] Persisted to IDB Storage:', fileName);
                } else {
                    console.log('[ZOOM] Retained in transient RAM Only (PACKED Item):', fileName);
                }
                if (imgEl.dataset.loadedZoom !== 'true') {
                    if (imgEl.dataset.tempBlobUrl) URL.revokeObjectURL(imgEl.dataset.tempBlobUrl);
                    var oUrl = URL.createObjectURL(blob);
                    imgEl.dataset.tempBlobUrl = oUrl;
                    imgEl.src = oUrl;
                    imgEl.dataset.loadedZoom = 'true';
                }
                console.log('[ZOOM] Loaded into RAM:', fileName);
            } else if (r.status === 404 || r.status === 403) {
                // STEP 5: Extension fallback (.webp <-> .jpg)
                var fbUrl = null, lu = url.toLowerCase();
                if (lu.includes('.webp?alt=media')) fbUrl = url.replace(/\.webp\?alt=media/i, '.jpg?alt=media');
                else if (lu.includes('.jpg?alt=media')) fbUrl = url.replace(/\.jpg\?alt=media/i, '.webp?alt=media');
                else if (lu.includes('.jpeg?alt=media')) fbUrl = url.replace(/\.jpeg\?alt=media/i, '.jpg?alt=media');
                else if (lu.includes('.png?alt=media')) fbUrl = url.replace(/\.png\?alt=media/i, '.webp?alt=media');
                if (fbUrl) {
                    if (typeof window.logAppError === 'function') {
                        window.logAppError('AUDITOR: Fallback Swap', `Swapped ${url} to ${fbUrl} for ${fileName} | HTTP ${r.status}`);
                    }
                    var r2 = await window.fetchWithRetry(fbUrl);
                    if (r2.ok) {
                        var b2 = await r2.blob();
                        if (isInStock) {
                            saveImageToDB(fbUrl, b2);
                            console.log('[ZOOM] Persisted to IDB Storage (Fallback):', fileName);
                        } else {
                            console.log('[ZOOM] Retained in transient RAM Only (Fallback):', fileName);
                        }
                        if (imgEl.dataset.loadedZoom !== 'true') {
                            if (imgEl.dataset.tempBlobUrl) URL.revokeObjectURL(imgEl.dataset.tempBlobUrl);
                            var u2 = URL.createObjectURL(b2);
                            imgEl.dataset.tempBlobUrl = u2;
                            imgEl.src = u2;
                            imgEl.dataset.loadedZoom = 'true';
                        }
                    } else {
                        var errText = await r2.text().catch(() => "No text");
                        if (typeof window.logAppError === 'function') {
                            window.logAppError('AUDITOR: Fallback Failed', `HTTP ${r2.status} on fallback | ${errText.substring(0, 100)}`);
                        }
                        imgEl.dataset.loadedZoom = 'true'; // Stop trying, leave grid image
                    }
                }
            } else {
                var errTextOrig = await r.text().catch(() => "No text");
                if (typeof window.logAppError === 'function') {
                    window.logAppError('AUDITOR: Zoom Fetch Error', `HTTP ${r.status} | ${errTextOrig.substring(0, 100)}`);
                }
                imgEl.dataset.loadedZoom = 'true';
            }
        } catch (e) {
            console.error('[ZOOM] Error for', fileName, ':', e.message);
            var prod = window.allProducts && window.allProducts.find(x => x.id === productId);
            var pName = prod ? prod.name : productId;
            if (typeof window.logAppError === 'function') {
                window.logAppError('Zoom Image Error', e.message + " | " + pName);
            }
        }
    }, 0);
}

function fetchZoomNatively(zoomUrl, imgEl) {
    if (!zoomUrl) return;
    var tempImg = new Image();
    tempImg.onload = function () {
        if (imgEl.dataset.loadedZoom !== 'true') {
            if (imgEl.dataset.tempBlobUrl) {
                URL.revokeObjectURL(imgEl.dataset.tempBlobUrl);
                imgEl.removeAttribute('data-temp-blob-url');
            }
            imgEl.src = zoomUrl;
            imgEl.dataset.loadedZoom = "true";
        }
    };
    tempImg.onerror = function () {
        if (imgEl.dataset.loadedZoom === "true") return;
        var newZoomUrl = null;
        var lowerUrl = zoomUrl.toLowerCase();
        var extMatch = zoomUrl.match(/\/([^/?]+)\?alt=media/i);
        var filename = extMatch ? extMatch[1] : zoomUrl;
        var extChangeMsg = "";

        if (lowerUrl.includes('.webp?alt=media')) { newZoomUrl = zoomUrl.replace(/\.webp\?alt=media/i, '.jpg?alt=media'); extChangeMsg = ".webp -> .jpg"; }
        else if (lowerUrl.includes('.jpg?alt=media')) { newZoomUrl = zoomUrl.replace(/\.jpg\?alt=media/i, '.webp?alt=media'); extChangeMsg = ".jpg -> .webp"; }
        else if (lowerUrl.includes('.jpeg?alt=media')) { newZoomUrl = zoomUrl.replace(/\.jpeg\?alt=media/i, '.jpg?alt=media'); extChangeMsg = ".jpeg -> .jpg"; }
        else if (lowerUrl.includes('.png?alt=media')) { newZoomUrl = zoomUrl.replace(/\.png\?alt=media/i, '.webp?alt=media'); extChangeMsg = ".png -> .webp"; }

        if (typeof window.logAppError === 'function') {
            window.logAppError('AUDITOR: Image Fallback Triggered', `Failed to load ${filename}. Trying ${extChangeMsg}`);
        }

        if (newZoomUrl) {
            var fallbackImg = new Image();
            fallbackImg.onload = function () {
                if (imgEl.dataset.loadedZoom !== 'true') {
                    if (imgEl.dataset.tempBlobUrl) {
                        URL.revokeObjectURL(imgEl.dataset.tempBlobUrl);
                        imgEl.removeAttribute('data-temp-blob-url');
                    }
                    imgEl.src = newZoomUrl;
                    imgEl.dataset.loadedZoom = "true";
                }
            };
            fallbackImg.onerror = function () {
                if (typeof window.logAppError === 'function') {
                    var newFilename = newZoomUrl.match(/\/([^/?]+)\?alt=media/i);
                    newFilename = newFilename ? newFilename[1] : newZoomUrl;
                    window.logAppError('AUDITOR: Image Fallback Failed (404)', `Both original and fallback missing. Failed on ${newFilename}`);
                }
            };
            fallbackImg.src = newZoomUrl;
        }
    };
    tempImg.src = zoomUrl;
}

window.recordTimeSpent = function () {
    if (window.viewStartTime && typeof curProduct !== 'undefined' && curProduct) {
        let spentMins = (Date.now() - window.viewStartTime) / 60000;
        let today = new Date().toISOString().split('T')[0];
        let historyMap = {};
        try {
            let parsed = JSON.parse(localStorage.getItem('dsLiveHistory'));
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) historyMap = parsed;
        } catch (e) { }

        if (!historyMap[today]) historyMap[today] = {};
        historyMap[today][curProduct.name] = (historyMap[today][curProduct.name] || 0) + spentMins;

        let cutoff = Date.now() - (7 * 24 * 60 * 60 * 1000); // 7 days
        for (let dateKey in historyMap) {
            if (new Date(dateKey).getTime() < cutoff) {
                delete historyMap[dateKey];
            }
        }

        localStorage.setItem('dsLiveHistory', JSON.stringify(historyMap));
        window.viewStartTime = null;
    }
};

function openDetail(productId, skipShow, keepSearchShown, onRenderComplete) {
    if (document.activeElement) document.activeElement.blur(); // Hide keyboard when opening a product

    if (!skipShow) {
        cameFromDetail = false;

        // Always reset the product page's internal search UI when a new product is opened
        var dtInput = document.getElementById('dtSearchInput');
        var dtTitle = document.getElementById('dtNameTop');
        if (dtInput) {
            dtInput.style.display = 'none';
            dtInput.value = '';
        }
        if (dtTitle) dtTitle.style.display = 'block';

        var gridWrapper = document.getElementById('gridWrapper');
        if (gridWrapper && gridWrapper.parentNode !== document.getElementById('appBody')) {
            document.getElementById('appBody').appendChild(gridWrapper);
            gridWrapper.style.flex = "";
            gridWrapper.style.overflowY = "";
            gridWrapper.style.paddingBottom = "";
        }
        var detailPanel = document.getElementById('detailPanel');
        var slBody = detailPanel ? detailPanel.querySelector('.sl-body') : null;
        if (slBody) slBody.style.display = 'block';

        if (window.isGuestMode) {
            // Hide all unnecessary app UI for guests
            var hdr = document.querySelector('.hdr');
            if (hdr) hdr.style.display = 'none';
            var bNav = document.querySelector('.myntra-bottom-nav');
            if (bNav) bNav.style.display = 'none';
            var detailBottom = document.getElementById('detailBottomRow');
            if (detailBottom) detailBottom.style.display = 'none';

            // Hide back buttons in the detail panel header
            var slHdr = detailPanel ? detailPanel.querySelector('.sl-hdr') : null;
            if (slHdr) slHdr.style.display = 'none';

            // Add the sticky "Download App" button
            var existingBtn = document.getElementById('guestDownloadBtn');
            if (!existingBtn && detailPanel) {
                var btn = document.createElement('a');
                btn.id = 'guestDownloadBtn';
                btn.href = 'https://play.google.com/store/apps/details?id=com.durgasarees.catalog';
                btn.innerHTML = '<b>Download Durga Sarees App</b><br>To view Wholesale Prices & Order';
                btn.style.position = 'absolute';
                btn.style.bottom = '0';
                btn.style.left = '0';
                btn.style.width = '100%';
                btn.style.padding = '18px';
                btn.style.backgroundColor = '#ff3f6c';
                btn.style.color = '#fff';
                btn.style.textAlign = 'center';
                btn.style.textDecoration = 'none';
                btn.style.fontSize = '16px';
                btn.style.zIndex = '999999';
                btn.style.boxShadow = '0 -4px 15px rgba(0,0,0,0.3)';
                btn.style.boxSizing = 'border-box';
                detailPanel.appendChild(btn);
            }
        }

        if (!keepSearchShown) {
            var input = document.getElementById('srchMainInput');
            var logo = document.getElementById('appLogoImg');
            if (input && input.style.display !== 'none') {
                input.style.display = 'none';
                if (logo) logo.style.display = 'block';
            }
        }
    }

    if (window.viewStartTime && typeof curProduct !== 'undefined' && curProduct) {
        window.recordTimeSpent();
    }

    window.updateLivePresence(productId);

    var p = allProducts.find(x => x.id === productId || x.docId === productId);
    if (!p) return;
    curProduct = p;
    window.viewStartTime = Date.now();

    if (p && p.name) {
        if (!window.livePresenceHistory) window.livePresenceHistory = [];
        if (!window.livePresenceHistory.includes(p.name)) {
            window.livePresenceHistory.push(p.name);
            if (window.livePresenceHistory.length > 10) window.livePresenceHistory.shift();
        }
    }

    document.getElementById('dtNameTop').innerText = p.name;
    document.getElementById('dtPriceBot').innerText = p.price || '0';
    document.getElementById('dtPackBot').innerText = (p.packing && p.packing !== "") ? p.packing : "-";

    // 🚀 NEW: LIVE SYNC FETCH WHEN OPENING PRODUCT PAGE
    if (p.docId) {
        var docUrl = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + p.docId;
        window.fetchWithRetry(docUrl, { method: 'GET' }, 1)
            .then(r => r.ok ? r.json() : null)
            .then(data => {
                if (data && data.fields) {
                    var f = data.fields;
                    var livePrice = f.price ? (f.price.doubleValue || f.price.integerValue || 0) : 0;
                    var livePacking = f.packing ? (f.packing.stringValue || (f.packing.integerValue !== undefined ? String(f.packing.integerValue) : "") || (f.packing.doubleValue !== undefined ? String(f.packing.doubleValue) : "") || "1") : "1";

                    p.price = livePrice;
                    p.packing = livePacking;

                    if (curProduct && curProduct.id === p.id) {
                        document.getElementById('dtPriceBot').innerText = p.price || '0';
                        document.getElementById('dtPackBot').innerText = (p.packing && p.packing !== "") ? p.packing : "-";
                    }
                    refreshCardUI(p.id);
                }
            }).catch(e => { });
    }

    var deck = document.getElementById('dtDesigns');
    if (deck) deck.innerHTML = '';

    if (!skipShow) {
        var detailPanel = document.getElementById('detailPanel');
        var wasOpen = detailPanel && detailPanel.classList.contains('open');
        if (detailPanel) detailPanel.classList.add('open');

        if (!wasOpen && !window.isGuestMode) {
            pushHistoryState('detail');
        } else {
            // Already open, no need to push another identical state!
        }
    }

    var gridPath = p.gridUrl;
    var zoomPath = (p.zoomUrl && p.zoomUrl !== "None") ? p.zoomUrl : p.gridUrl;

    if (window.brokenImagesMap) {
        delete window.brokenImagesMap[gridPath];
        delete window.brokenImagesMap[zoomPath];
    }

    var cleanGridPath = gridPath ? String(gridPath).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/') : "";
    var cleanZoomPath = zoomPath && zoomPath !== "None" ? String(zoomPath).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/') : cleanGridPath;

    var bucket = "durga-sarees.firebasestorage.app";
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";

    if (!cleanGridPath || cleanGridPath === "" || cleanGridPath.toLowerCase() === "none") {
        window.lastRenderedDesignNames = "";
        processFolderItems([]);
        return;
    }
    // List files from Grid path (always has source images), then build Zoom URLs from filenames
    var prefix = cleanGridPath.split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('/') + '/';
    // delimiter=/ means only DIRECT children are returned, not recursive subfolders
    var listUrl = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o?prefix=" + prefix + "&delimiter=/";

    var renderedFilesJson = "";

    // 1. Render immediately if cached, otherwise wait for network
    window.lastRenderedDesignNames = "";

    // 2. Fetch actual folder files in background to update/upgrade the swipe deck
    function processFolderItems(items) {
        // Sync cover exists state from the actual directory items
        var coverFound = false;
        // Update main grid image using first discovered file from folder listing
        var mainGridImg = document.getElementById("img_" + p.id);
        if (mainGridImg && items.length > 0) {
            delete window.brokenImagesMap[gridPath];
            window.renderWebpFromFolder(mainGridImg, p.gridUrl, null, p.coverDesignId ? p.coverDesignId.replace(/\.(webp|jpg|jpeg|png)$/i, '') + '.webp' : null);
        }

        var validFiles = [];
        var designMap = {};

        items.forEach(item => {
            var fullPath = item.name; // item.name is from Grid bucket
            var filename = fullPath.substring(fullPath.lastIndexOf('/') + 1);
            var lowerName = filename.toLowerCase();

            // Define isCoverImg (we will filter them out later if there are other designs)
            var isCoverImg = /^(cover|cover1)\.(webp|jpg|jpeg|png)$/i.test(lowerName);

            var ext = lowerName.substring(lowerName.lastIndexOf('.'));
            var isVideo = [".mp4", ".mov", ".webm", ".avi", ".mkv", ".3gp", ".ogg"].includes(ext);
            var isImage = [".webp", ".jpg", ".jpeg", ".png", ".gif"].includes(ext);

            if (isVideo || isImage) {
                // Grid path: item.name already IS the Grid path
                var gridEncName = fullPath.split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
                // Zoom path: replace Grid folder prefix with Zoom folder prefix
                // Strictly append the filename to the zoom folder path, bypassing case-sensitive .replace() errors
                var zoomEncName = cleanZoomPath.split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F') + '%2F' + encodeURIComponent(filename);

                var gridUrl = fbBase + gridEncName + "?alt=media";
                var zoomUrl = fbBase + zoomEncName + "?alt=media";
                var designName = filename.substring(0, filename.lastIndexOf('.'));

                // DEDUPLICATION: If we have multiple extensions for the same design, prefer .webp
                if (designMap[designName]) {
                    var existingExt = designMap[designName].ext;
                    if (existingExt === '.webp' && ext !== '.webp') {
                        return; // Keep existing webp, skip this jpg/png
                    }
                }

                designMap[designName] = {
                    name: designName,
                    gridUrl: gridUrl,
                    url: zoomUrl,
                    isVideo: isVideo,
                    isImage: isImage,
                    isCoverImg: isCoverImg,
                    timeCreated: item.timeCreated,
                    ext: ext
                };
            }
        });

        validFiles = Object.values(designMap);

        // Hide cover/cover1 images from product page — they are only used for the main grid thumbnail
        var hasOtherDesigns = validFiles.some(f => !f.isCoverImg);
        if (hasOtherDesigns) {
            validFiles = validFiles.filter(f => !f.isCoverImg);
        }

        // 🛡️ SORT LATEST DESIGNS FIRST WITH HIGHEST STOCK FIRST
        validFiles.sort((a, b) => {
            var stockA = p.stock && p.stock[a.name] !== undefined ? p.stock[a.name] : 999;
            var stockB = p.stock && p.stock[b.name] !== undefined ? p.stock[b.name] : 999;
            if (stockA !== stockB) {
                return stockB - stockA; // Highest stock first
            }

            // Sort by newly added images first
            var timeA = a.timeCreated ? new Date(a.timeCreated).getTime() : 0;
            var timeB = b.timeCreated ? new Date(b.timeCreated).getTime() : 0;

            if (timeA !== timeB) {
                return timeB - timeA; // Newest first
            }

            var numA = parseInt(a.name.replace(/\D/g, ''));
            var numB = parseInt(b.name.replace(/\D/g, ''));
            if (isNaN(numA)) numA = 0;
            if (isNaN(numB)) numB = 0;
            return numB - numA;
        });

        if (validFiles.length > 0) {
            renderSwipeDeck(validFiles).then(() => {
                if (typeof onRenderComplete === 'function') {
                    onRenderComplete();
                    onRenderComplete = null;
                }
            });

        } else {
            // Firebase Storage folder is empty: Clear fallback cards and show only the cover image
            window.lastRenderedDesignNames = "";
            var gridImgEl = document.getElementById("img_" + p.id);
            var coverSrc = (gridImgEl && gridImgEl.src && !gridImgEl.src.startsWith("data:")) ? gridImgEl.src : "";
            var fallbackGridUrl = "";
            var fallbackZoomUrl = "";
            if (p.gridUrl && p.gridUrl !== "None") {
                var encGridPath = cleanGridPath.split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
                fallbackGridUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + encGridPath + "%2F01.webp?alt=media";
                if (!coverSrc) coverSrc = fallbackGridUrl;
            }
            if (p.zoomUrl && p.zoomUrl !== "None") {
                var encZoomPath = cleanZoomPath.split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
                fallbackZoomUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + encZoomPath + "%2F01.webp?alt=media";
            } else {
                fallbackZoomUrl = fallbackGridUrl;
            }
            var curStock = p.stock && p.stock['DIRECT'] !== undefined ? p.stock['DIRECT'] : 999;
            var adminCheckboxHtml = '';
            var qtyHtml = '';
            if (window.isAdminMode) {
                adminCheckboxHtml = `<input type="checkbox" class="admin-bulk-check" data-did="DIRECT" data-docid="${p.docId}" data-pid="${p.id}" onclick="event.stopPropagation()" style="position:absolute; top:8px; left:8px; z-index:10; transform:scale(1.5); box-shadow: 0 0 5px rgba(255,255,255,0.8);">`;
                qtyHtml = `
                    <div style="display:flex; align-items:center; justify-content:flex-end; gap:6px;">
                        <span style="font-size:11px; font-weight:bold; color:var(--text-main);">Stock:</span>
                        <input type="number" class="admin-stock-input" value="${curStock}" onblur="window.updateAdminStock(this, '${p.docId}', '${p.id}', 'DIRECT')" onkeyup="if(event.key === 'Enter') this.blur();" style="width: 60px; text-align: center; border: 1px solid #ccc; border-radius: 4px;">
                    </div>
                `;
            } else if (curStock === 0) {
                qtyHtml = '<div style="color:white; background:red; padding:4px 12px; font-weight:bold; border-radius:4px; margin-top:4px;">PACKED</div>';
            } else {
                qtyHtml = `
                    <div class="qty-clean">
                        <button onclick="changeQty('${p.id}', 'DIRECT', -1)">−</button>
                        <input type="number" id="qty_${p.id}_DIRECT" value="${cart[p.id + '_DIRECT'] ? cart[p.id + '_DIRECT'].qty : 0}" onchange="setExactQty('${p.id}', 'DIRECT', this.value)">
                        <button onclick="changeQty('${p.id}', 'DIRECT', 1)">+</button>
                    </div>
                `;
            }
            deck.innerHTML = `
            <div class="swipe-card" data-design="DIRECT" onclick="openFs('${p.id}', 0, 'Cover')" style="position:relative;">
                ${adminCheckboxHtml}
                <img id="design_img_${p.id}_DIRECT" src="${coverSrc || ''}" data-loaded-zoom="false" style="width: 100%; object-fit: cover;" onerror="if(typeof window.logAppError === 'function') window.logAppError('Image Load Error', 'Fallback Cover Image Missing (404) | ${p.name}'); this.onerror=null; this.src=window.dsMissingImage;">
                <div class="swipe-card-bot" onclick="event.stopPropagation()">
                    <div style="font-weight:bold; font-size:12px; color:var(--text-main);">Cover</div>
                    ${qtyHtml}
                </div>
            </div>`;
            setTimeout(updateBottomQtyFromActiveDesign, 50);
            updateLiveDetailHeader();
            var imgEl = document.getElementById("design_img_" + p.id + "_DIRECT");
            if (imgEl && fallbackZoomUrl) {
                var curStockCover = p.stock && p.stock['Cover'] !== undefined ? p.stock['Cover'] : 999;
                loadAndCacheDesignImage(imgEl, fallbackZoomUrl, fallbackGridUrl, p.id, 'Cover', p.gridUrl, true, cleanZoomPath, curStockCover > 0);
            }
            if (typeof onRenderComplete === 'function') {
                onRenderComplete();
                onRenderComplete = null;
            }
        }
    }

    var cachedItems = null;
    if (window.dsFolderCache && window.dsFolderCache[listUrl]) {
        cachedItems = window.dsFolderCache[listUrl];
    } else {
        // FAST RENDER: Generate pseudo-items from offline sources for instant offline rendering!
        cachedItems = [];
        var added = {};

        function pushItem(k) {
            if (k === "DIRECT" || k === "FULLY_PACKED" || k.toLowerCase().startsWith('cover')) return;
            var fileName = k.includes('.') ? k : k + ".webp";
            if (!added[fileName]) {
                cachedItems.push({ name: prefix + fileName });
                added[fileName] = true;
            }
        }

        function pushItemsFromString(str) {
            String(str).split(',').map(d => d.trim()).filter(d => d).forEach(pushItem);
        }

        var masterCacheString = window.dsMasterCache ? window.dsMasterCache[cleanGridPath] : null;

        if (masterCacheString) {
            pushItemsFromString(masterCacheString);
        } else if (p.stock && Object.keys(p.stock).filter(k => k !== 'DIRECT' && k !== 'FULLY_PACKED' && !k.toLowerCase().startsWith('cover')).length > 0) {
            Object.keys(p.stock).forEach(pushItem);
        } else if (p.ready) {
            pushItemsFromString(p.ready);
        }
    }

    if (cachedItems && cachedItems.length > 0) {
        // Instantly process and render cards from local memory!
        processFolderItems(cachedItems);
    } else {
        if (deck) deck.innerHTML = '<div style="width:100%; text-align:center; padding: 60px 20px; color: var(--text-muted, #888); font-size: 14px;"><i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i> Loading designs...</div>';
    }

    // ALWAYS fetch from network to sync any newly uploaded admin images
    fetch(listUrl + "&_t=" + new Date().getTime(), { cache: 'no-store' })
        .then(res => {
            if (!res.ok) throw new Error("HTTP error " + res.status);
            return res.json();
        })
        .then(data => {
            var items = data.items || [];
            if (!window.dsFolderCache) window.dsFolderCache = {};

            window.dsFolderCache[listUrl] = items;
            try { localStorage.setItem("dsFolderCache", JSON.stringify(window.dsFolderCache)); } catch (e) { }

            var oldNames = cachedItems ? cachedItems.map(x => x.name).join(',') : "";
            var newNames = items.map(x => x.name).join(',');

            var needsRender = (oldNames !== newNames);
            if (!cachedItems || cachedItems.length === 0) needsRender = true; // Always render if we were stuck on 'Loading designs...'

            if (needsRender) {
                processFolderItems(items);
            }

            // 🚀 JIT PRIORITY SYNC & CLEANUP (Runs asynchronously in background)
            (async function () {
                var folderFiles = items.map(item => item.name.substring(item.name.lastIndexOf('/') + 1))
                    .filter(f => /\.(webp|jpg|jpeg|png)$/i.test(f));
                if (folderFiles.length === 0) return;

                var bucket = "durga-sarees.firebasestorage.app";
                var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
                var cleanGrid = decodeURIComponent(String(p.gridUrl)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
                var encGridPath = cleanGrid.split('/').map(s => encodeURIComponent(s)).join('%2F');

                var encZoomPath = "";
                if (p.zoomUrl && String(p.zoomUrl).toLowerCase() !== "none" && p.zoomUrl !== p.gridUrl) {
                    var cleanZoom = decodeURIComponent(String(p.zoomUrl)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
                    encZoomPath = cleanZoom.split('/').map(s => encodeURIComponent(s)).join('%2F');
                }

                // 1. Stale Cleanup
                var designKeys = {};
                folderFiles.forEach(f => {
                    var gridKey = fbBase + encGridPath + "%2F" + encodeURIComponent(f) + "?alt=media";
                    designKeys[gridKey] = gridKey;
                    if (encZoomPath) {
                        var zoomKey = fbBase + encZoomPath + "%2F" + encodeURIComponent(f) + "?alt=media";
                        designKeys[zoomKey] = zoomKey;
                    }
                });

                var prefixesToClean = [fbBase + encGridPath + "%2F"];
                if (encZoomPath) prefixesToClean.push(fbBase + encZoomPath + "%2F");
                for (var prefix of prefixesToClean) {
                    var cachedKeys = await listDBKeysForPrefix(prefix);
                    for (var ck of cachedKeys) {
                        if (!designKeys[ck]) {
                            await deleteImageFromDB(ck);
                            console.log("[JIT] Deleted stale cache:", ck);
                        }
                    }
                }

                // 2. Zoom Stock Enforcer
                if (encZoomPath) {
                    for (var fname of folderFiles) {
                        var coverFile;
                        if (p.coverDesignId) {
                            var cleanCoverId = String(p.coverDesignId).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                            var exact = folderFiles.find(f => f.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase() === cleanCoverId);
                            if (exact) {
                                coverFile = exact;
                            } else {
                                // AUTO-HEALING GHOST METADATA
                                var patchUrl = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + p.docId + "?updateMask.fieldPaths=coverDesignId";
                                fetch(patchUrl, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { coverDesignId: { stringValue: "" } } }) }).catch(e => { });
                                p.coverDesignId = ""; // Clear locally
                            }
                        }
                        if (!coverFile) {
                            var possibleCovers = ["cover", "cover1"];
                            var foundCover = folderFiles.find(f => possibleCovers.includes(f.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase()));
                            coverFile = foundCover || folderFiles[0];
                        }

                        var isCover = (fname === coverFile);
                        var stockKey = isCover ? 'Cover' : fname;
                        var curStock = p.stock && p.stock[stockKey] !== undefined ? p.stock[stockKey] : 999;
                        var zoomImgUrl = fbBase + encZoomPath + "%2F" + encodeURIComponent(fname) + "?alt=media";
                        var existing = await checkImageInDB(zoomImgUrl);

                        if (curStock > 0) {
                            if (!existing) {
                                try {
                                    var zRes = await window.fetchWithRetry(zoomImgUrl, {}, 2);
                                    if (zRes.ok) {
                                        var zBlob = await zRes.blob();
                                        if (zBlob.size > 0) await saveImageToDB(zoomImgUrl, zBlob);
                                    }
                                } catch (e) { }
                            }
                        } else {
                            if (existing) {
                                await deleteImageFromDB(zoomImgUrl);
                                console.log("[JIT] Deleted out-of-stock zoom cache:", fname);
                            }
                        }
                    }
                }
            })();
        })
        .catch(err => {
            console.warn("Background folder list load failed", err);
            if (!window.dsFolderCache || !window.dsFolderCache[listUrl]) {
                var fallbackItems = [];
                for (var i = 1; i <= 5; i++) {
                    var n = String(i).padStart(2, '0');
                    fallbackItems.push({ name: cleanGridPath + '/' + n + ".webp" });
                }
                processFolderItems(fallbackItems);
            } else {
                if (typeof onRenderComplete === 'function') {
                    onRenderComplete();
                    onRenderComplete = null;
                }
            }
        });

    async function renderSwipeDeck(files) {
        renderedFilesJson = JSON.stringify(files);
        window.lastRenderedDesignNames = files.map(f => String(f.name).toLowerCase()).join(',');

        var placeholderSVG = window.dsMissingImage;

        // 🚀 HTML IS BUILT IMMEDIATELY WITH NO AWAIT FOR LIGHTNING FAST PANEL OPEN
        var html = '';
        files.forEach((file, idx) => {
            var dKey = p.id + '_' + file.name;
            var curStock = p.stock && p.stock[file.name] !== undefined ? p.stock[file.name] : 999;

            var qtyHtml = '';
            if (window.isAdminMode) {
                qtyHtml = `<input type="number" class="admin-stock-input" value="${curStock}" onblur="window.updateAdminStock(this, '${p.docId}', '${p.id}', '${file.name}')" onkeyup="if(event.key === 'Enter') this.blur();" style="width: 60px; text-align: center; border: 1px solid #ccc; border-radius: 4px;">`;
            } else if (curStock === 0) {
                qtyHtml = `<div style="background: red; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 11px;">PACKED</div>`;
            } else {
                qtyHtml = `
                    <div class="qty-clean">
                        <button onclick="changeQty('${p.id}', '${file.name}', -1)">−</button>
                        <input type="number" id="qty_${p.id}_${file.name}" value="${cart[dKey] ? cart[dKey].qty : 0}" onchange="setExactQty('${p.id}', '${file.name}', this.value)">
                        <button onclick="changeQty('${p.id}', '${file.name}', 1)">+</button>
                    </div>`;
            }

            var adminCheckboxHtml = '';
            if (window.isAdminMode) {
                adminCheckboxHtml = `<input type="checkbox" class="admin-bulk-check" data-did="${file.name}" data-docid="${p.docId}" data-pid="${p.id}" onclick="event.stopPropagation()" style="position:absolute; top:8px; left:8px; z-index:10; transform:scale(1.5); box-shadow: 0 0 5px rgba(255,255,255,0.8);">`;
            }

            if (file.isVideo) {
                var cleanCoverId = p.coverDesignId ? String(p.coverDesignId).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase() : '';
                var cleanFileName = String(file.name).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                var isCover = (cleanCoverId !== '' && cleanCoverId === cleanFileName);
                html += `
                <div class="swipe-card" data-design="${file.name}" onclick="openFs('${p.id}', ${idx}, '${file.name}')" style="position:relative;">
                    ${adminCheckboxHtml}
                    ${window.isAdminMode ? `<i class="${isCover ? 'fas' : 'far'} fa-star" style="position:absolute; top:8px; right:8px; color:gold; font-size:18px; cursor:pointer; background:rgba(0,0,0,0.5); padding:6px; border-radius:50%; z-index:10;" onclick="event.stopPropagation(); window.promptSetAsCover('${p.docId}', '${p.id}', '${file.name}')" title="Set as Cover"></i>` : ''}
                    <video src="${file.url}" controls playsinline style="width: 100%; object-fit: cover;" onclick="event.stopPropagation()"></video>
                    <div class="swipe-card-bot" onclick="event.stopPropagation()">
                        <div style="font-weight:bold; font-size:12px; color:var(--text-main); display:flex; align-items:center; gap:6px;">
                            ${file.name}
                            ${window.isAdminMode ? `<i class="fas fa-edit" style="color:var(--myntra-pink); font-size:14px; cursor:pointer;" onclick="window.promptRenameDesign('${p.docId}', '${p.id}', '${file.name}', '${file.url}')" title="Rename Design"></i>` : ''}
                        </div>
                        ${qtyHtml}
                    </div>
                </div>`;
            } else {
                var imgId = "design_img_" + p.id + "_" + idx;
                var cleanCoverId = p.coverDesignId ? String(p.coverDesignId).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase() : '';
                var cleanFileName = String(file.name).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                var isCover = (cleanCoverId !== '' && cleanCoverId === cleanFileName);
                html += `
                <div class="swipe-card" data-design="${file.name}" onclick="openFs('${p.id}', ${idx}, '${file.name}')" style="position:relative;">
                    ${adminCheckboxHtml}
                    ${window.isAdminMode ? `<i class="${isCover ? 'fas' : 'far'} fa-star" style="position:absolute; top:8px; right:8px; color:gold; font-size:18px; cursor:pointer; background:rgba(0,0,0,0.5); padding:6px; border-radius:50%; z-index:10;" onclick="event.stopPropagation(); window.promptSetAsCover('${p.docId}', '${p.id}', '${file.name}')" title="Set as Cover"></i>` : ''}
                    <img id="${imgId}" src="${file.gridUrl || placeholderSVG}" data-loaded-zoom="false" data-zoom-url="${file.url}">
                    <div class="swipe-card-bot" onclick="event.stopPropagation()">
                        <div style="font-weight:bold; font-size:12px; color:var(--text-main); display:flex; align-items:center; gap:6px;">
                            ${file.name}
                            ${window.isAdminMode ? `<i class="fas fa-edit" style="color:var(--myntra-pink); font-size:14px; cursor:pointer;" onclick="window.promptRenameDesign('${p.docId}', '${p.id}', '${file.name}', '${file.gridUrl || file.url}')" title="Rename Design"></i>` : ''}
                        </div>
                        ${qtyHtml}
                    </div>
                </div>`;
            }
        });
        deck.innerHTML = html;

        // Trigger background load of blobs so UI renders instantly
        files.forEach((file, idx) => {
            if (!file.isVideo) {
                var imgId = "design_img_" + p.id + "_" + idx;
                var imgEl = document.getElementById(imgId);
                if (imgEl) {
                    var currentStock = p.stock && p.stock[file.name] !== undefined ? p.stock[file.name] : 999;
                    loadAndCacheDesignImage(imgEl, file.url, file.gridUrl, p.id, file.name, p.gridUrl, /^(cover|cover1)$/i.test(file.name), cleanZoomPath, currentStock > 0);
                }
            }
        });

        setTimeout(updateBottomQtyFromActiveDesign, 50);
        updateLiveDetailHeader();
    }

}

window.changeQty = function (pid, designId, amount) {
    var p = allProducts.find(x => x.id === pid); if (!p) return;
    if (!window.isAdminMode && p.stock && p.stock[designId] === 0) return; // Cart Protection
    if (typeof window.updateLivePresence === 'function') window.updateLivePresence(typeof curProduct !== 'undefined' && curProduct ? curProduct.id : null);
    var key = pid + '_' + designId;
    var curQ = cart[key] ? cart[key].qty : 0;
    var newQ = Math.max(0, curQ + (amount * (p.mult || 1)));

    if (newQ === 0 || isNaN(newQ)) delete cart[key];
    else cart[key] = { p: p, design: designId, qty: newQ };

    // 1. Update Swipe Card Input
    var input = document.getElementById('qty_' + pid + '_' + designId);
    if (input) input.value = newQ;

    // 2. 🛡️ THE FIX: Update Full Screen Bottom Row instantly if it's open
    if (typeof fsDesignId !== 'undefined' && fsDesignId === designId) {
        var fsInp = document.getElementById('fsQty');
        if (fsInp) fsInp.innerText = newQ;
    }

    try { localStorage.setItem("dsCart", JSON.stringify(cart)); } catch (e) { }
    refreshCardUI(pid);
    updateLiveDetailHeader(); // Updates the total Master Qty at bottom!
    updateBottomQtyFromActiveDesign(); // 🛡️ Keep bottom row selection updated

    var totalQty = 0;
    for (var k in cart) { if (k.startsWith(pid + '_')) totalQty += cart[k].qty; }
    manageProductHDCache(p, totalQty > 0 ? 'CACHE' : 'DELETE');

    // 3. 🚀 Update Cart Live WITHOUT re-rendering everything!
    var cartText = document.getElementById('cart_qty_text_' + pid + '_' + designId);
    if (cartText) cartText.innerText = newQ + ' pcs';
    var cartInp = document.getElementById('ie_qty_' + pid + '_' + designId);
    if (cartInp) cartInp.value = newQ;

    // Update global cart headers/badges
    if (typeof updateCartHeader === 'function') updateCartHeader();

    // Update Cart Panel Total Bottom Bar if cart is open
    var cartPanel = document.getElementById('cartPanel');
    if (cartPanel && cartPanel.classList.contains('open')) {
        var count = 0;
        for (var k in cart) { if (cart[k] && cart[k].qty) count += parseInt(cart[k].qty) || 0; }
        var footerQty = document.getElementById('cartTotalQty');
        if (footerQty) footerQty.innerText = count + " pcs";
    }
};

window.setExactQty = function (pid, designId, value) {
    var p = allProducts.find(x => x.id === pid); if (!p) return;
    var key = pid + '_' + designId;
    if (typeof window.updateLivePresence === 'function') window.updateLivePresence(typeof curProduct !== 'undefined' && curProduct ? curProduct.id : null);
    var newQ = parseInt(value) || 0;
    if (newQ < 0) newQ = 0;

    var mult = p.mult || 1;
    if (newQ % mult !== 0) {
        newQ = Math.round(newQ / mult) * mult;
    }

    if (newQ === 0) delete cart[key];
    else cart[key] = { p: p, design: designId, qty: newQ };

    var input = document.getElementById('qty_' + pid + '_' + designId);
    if (input) input.value = newQ;

    if (designId === 'DIRECT') {
        var topInput = document.getElementById('dtQtyDirect');
        if (topInput) topInput.value = newQ;
    }

    if (typeof fsDesignId !== 'undefined' && fsDesignId === designId) {
        var fsInp = document.getElementById('fsQty');
        if (fsInp) fsInp.innerText = newQ;
    }

    try { localStorage.setItem("dsCart", JSON.stringify(cart)); } catch (e) { }
    refreshCardUI(pid);
    updateLiveDetailHeader();
    updateBottomQtyFromActiveDesign();

    var totalQty = 0;
    for (var k in cart) { if (k.startsWith(pid + '_')) totalQty += cart[k].qty; }
    manageProductHDCache(p, totalQty > 0 ? 'CACHE' : 'DELETE');

    // 3. 🚀 Update Cart Live WITHOUT re-rendering everything!
    var cartText = document.getElementById('cart_qty_text_' + pid + '_' + designId);
    if (cartText) cartText.innerText = newQ + ' pcs';
    var cartInp = document.getElementById('ie_qty_' + pid + '_' + designId);
    if (cartInp) cartInp.value = newQ;

    // Update global cart headers/badges
    if (typeof updateCartHeader === 'function') updateCartHeader();

    // Update Cart Panel Total Bottom Bar if cart is open
    var cartPanel = document.getElementById('cartPanel');
    if (cartPanel && cartPanel.classList.contains('open')) {
        var count = 0;
        for (var k in cart) { if (cart[k] && cart[k].qty) count += parseInt(cart[k].qty) || 0; }
        var footerQty = document.getElementById('cartTotalQty');
        if (footerQty) footerQty.innerText = count + " pcs";
    }
};

function updateLiveDetailHeader() {
    if (!curProduct) return;
    var totalQty = 0;
    for (var k in cart) { if (cart[k].p && cart[k].p.id === curProduct.id) totalQty += cart[k].qty; }

    // Top Header Badge
    var dtTotTop = document.getElementById('dtTotalQtyTop');
    if (dtTotTop) dtTotTop.innerText = totalQty > 0 ? totalQty : "0";

    // Display live total quantity next to product name
    var dtNameTop = document.getElementById('dtNameTop');
    if (dtNameTop) {
        dtNameTop.innerHTML = esc(curProduct.name) + ' <span style="color: var(--myntra-pink); font-weight: bold; font-size: 14px;">(' + totalQty + ' pcs)</span>';
    }

    // Admin Bulk Actions Bar Toggle
    var adminBar = document.getElementById('adminBulkBar');
    if (adminBar) {
        adminBar.style.display = window.isAdminMode ? 'flex' : 'none';
        var checkAll = document.getElementById('adminBulkCheckAll');
        if (checkAll) checkAll.checked = false; // reset state
    }

    // Update design quantities summary in bottom row
    var summaryEl = document.getElementById('dtDesignsSummary');
    if (summaryEl) {
        var parts = [];
        for (var k in cart) {
            var c = cart[k];
            if (c && c.p && c.p.id === curProduct.id && c.qty > 0) {
                var dName = c.design || 'DIRECT';
                if (dName !== 'DIRECT') {
                    parts.push({ name: dName, qty: c.qty });
                }
            }
        }
        // Sort by design name naturally (e.g., D2, D3, D10)
        parts.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
        var displayParts = parts.map(p => p.name + '*' + p.qty);
        summaryEl.innerText = displayParts.length > 0 ? displayParts.join(' + ') : '';
    }

    var oldFab = document.getElementById('adminCamFab');
    if (oldFab) oldFab.remove();

    if (window.isAdminMode) {
        var panel = document.getElementById('detailPanel');
        panel.insertAdjacentHTML('beforeend', `<div id="adminCamFab" onclick="window.triggerAdminCamera('${curProduct.docId}', '${curProduct.id}')" style="position:fixed; bottom:95px; right:20px; background:var(--myntra-pink); color:white; width:55px; height:55px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:22px; box-shadow:0 4px 12px rgba(0,0,0,0.3); z-index:2500; cursor:pointer;"><i class="fas fa-camera"></i></div>`);
    }
}

function closeDetail(fromHistory) {
    if (document.activeElement) document.activeElement.blur(); // Hide keyboard when returning to home

    var fab = document.getElementById('adminCamFab'); if (fab) fab.remove();
    var panel = document.getElementById('detailPanel');
    if (panel) {
        panel.classList.remove('open');
        var videos = panel.querySelectorAll('video');
        videos.forEach(function (v) {
            v.pause();
        });
        var imgs = panel.querySelectorAll('img');
        imgs.forEach(function (img) {
            if (img.dataset.tempBlobUrl) {
                URL.revokeObjectURL(img.dataset.tempBlobUrl);
                img.removeAttribute('data-temp-blob-url');
            }
        });
    }

    var dtTitle = document.getElementById('dtNameTop');
    var dtInput = document.getElementById('dtSearchInput');
    if (dtInput) {
        dtInput.style.display = 'none';
        dtInput.value = ''; // Just clear the local input box visuals, don't clear global doSearch so they can see results
    }
    if (dtTitle) dtTitle.style.display = 'block';

    var gridWrapper = document.getElementById('gridWrapper');
    if (gridWrapper && gridWrapper.parentNode !== document.getElementById('appBody')) {
        document.getElementById('appBody').appendChild(gridWrapper);
        gridWrapper.style.flex = "";
        gridWrapper.style.overflowY = "";
        gridWrapper.style.paddingBottom = "";
    }
    var slBody = panel ? panel.querySelector('.sl-body') : null;
    if (slBody) slBody.style.display = 'block';

    window.recordTimeSpent();

    if (typeof window.updateLivePresence === 'function') {
        window.updateLivePresence(null, true);
    }

    if (!fromHistory) {
        history.back(); // Standard browser back to trigger popstate
    }
}

// ====================================
// 🧠 5. FULL SCREEN MODAL & LIVE BOTTOM ROW
// ====================================
var fsIndex = 0;
var fsDesignId = '';
var fsScale = 1;
var fsTranslateX = 0;
var fsTranslateY = 0;

function setupFsGestures() {
    var fsModal = document.getElementById('fsModal');
    var fsImg = document.getElementById('fsImg');
    if (!fsModal || !fsImg) return;

    var startTouchX = 0;
    var startTouchY = 0;
    var startTouchTime = 0;

    // Pinch variables
    var initialPinchDistance = 0;
    var initialScale = 1;
    var isPinching = false;

    // Pan variables
    var startPanX = 0;
    var startPanY = 0;
    var isPanning = false;
    var isSwipeDragging = false;

    // Double tap variable
    var lastTapTime = 0;

    // Helper: calculate distance between two fingers
    function getDistance(t1, t2) {
        var dx = t1.clientX - t2.clientX;
        var dy = t1.clientY - t2.clientY;
        return Math.sqrt(dx * dx + dy * dy);
    }

    function getAdjacentSrc(offset) {
        var deck = document.getElementById('dtDesigns');
        if (!deck) return '';
        var cards = Array.from(deck.querySelectorAll('.swipe-card')).filter(c => c.style.display !== 'none');
        if (cards.length === 0) return '';

        var targetIdx = fsIndex + offset;
        if (targetIdx < 0) targetIdx = cards.length - 1;
        if (targetIdx >= cards.length) targetIdx = 0;

        var card = cards[targetIdx];
        if (!card) return '';
        var img = card.querySelector('img');
        if (!img) return '';
        var chosenSrc = img.src;
        if (chosenSrc.includes("data:image/svg+xml")) {
            var dId = card.getAttribute('data-design');
            var pId = window.curProduct ? window.curProduct.id : '';
            var cartImgSrc = window.getCartImgSrc ? window.getCartImgSrc(pId, dId) : '';
            if (cartImgSrc) chosenSrc = cartImgSrc;
        }
        return chosenSrc;
    }

    // Swipe navigation logic
    function handleSwipe(diffX) {
        if (window.fsIsStandalone) return;
        var threshold = 50;
        if (Math.abs(diffX) > threshold) {
            // Find current index based on fsDesignId to ensure sync when swiping from Cart!
            var deck = document.getElementById('dtDesigns');
            if (deck && typeof fsDesignId !== 'undefined') {
                var cards = Array.from(deck.querySelectorAll('.swipe-card')).filter(c => c.style.display !== 'none');
                var foundIdx = cards.findIndex(card => {
                    var cardDId = card.getAttribute('data-design') || 'DIRECT';
                    return cardDId === fsDesignId;
                });
                if (foundIdx !== -1) fsIndex = foundIdx;
            }

            if (diffX > 0) {
                // Swipe Right (Go to previous image)
                openFs(fsIndex - 1);
            } else {
                // Swipe Left (Go to next image)
                openFs(fsIndex + 1);
            }
        }
    }

    // Touch Start
    fsImg.addEventListener('touchstart', function (e) {
        if (e.touches.length === 1) {
            // Potential pan, swipe, or double-tap
            isPanning = false;
            isPinching = false;

            startTouchX = e.touches[0].clientX;
            startTouchY = e.touches[0].clientY;
            startTouchTime = new Date().getTime();

            if (fsScale > 1) {
                isPanning = true;
                startPanX = e.touches[0].clientX - fsTranslateX;
                startPanY = e.touches[0].clientY - fsTranslateY;
            } else {
                isSwipeDragging = false;
            }
        } else if (e.touches.length === 2) {
            // Pinch to zoom
            isPinching = true;
            isPanning = false;
            initialPinchDistance = getDistance(e.touches[0], e.touches[1]);
            initialScale = fsScale;
        }
    }, { passive: true });

    // Touch Move
    fsImg.addEventListener('touchmove', function (e) {
        if (isPinching && e.touches.length === 2) {
            var newDistance = getDistance(e.touches[0], e.touches[1]);
            if (initialPinchDistance > 0) {
                var factor = newDistance / initialPinchDistance;
                fsScale = Math.max(1, Math.min(4, initialScale * factor));

                // If we zoom out to 1, reset offsets
                if (fsScale === 1) {
                    fsTranslateX = 0;
                    fsTranslateY = 0;
                }
                fsImg.style.transform = `translate3d(${fsTranslateX}px, ${fsTranslateY}px, 0) scale(${fsScale})`;
            }
        } else if (isPanning && e.touches.length === 1 && fsScale > 1) {
            // Drag panning when zoomed
            fsTranslateX = e.touches[0].clientX - startPanX;
            fsTranslateY = e.touches[0].clientY - startPanY;

            // Constrain translation bounds based on scale
            var maxTranslateX = (fsScale - 1) * (fsImg.clientWidth / 2);
            var maxTranslateY = (fsScale - 1) * (fsImg.clientHeight / 2);
            fsTranslateX = Math.max(-maxTranslateX, Math.min(maxTranslateX, fsTranslateX));
            fsTranslateY = Math.max(-maxTranslateY, Math.min(maxTranslateY, fsTranslateY));

            fsImg.style.transform = `translate3d(${fsTranslateX}px, ${fsTranslateY}px, 0) scale(${fsScale})`;
        } else if (e.touches.length === 1 && fsScale === 1) {
            // Smooth gallery swipe dragging
            var diffX = e.touches[0].clientX - startTouchX;
            var diffY = e.touches[0].clientY - startTouchY;

            // Start horizontal swipe smoothly
            if (isSwipeDragging || (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 5)) {
                isSwipeDragging = true;
                var wrapper = document.getElementById('fsSliderWrapper');
                if (wrapper) {
                    wrapper.style.transition = 'none';
                    wrapper.style.transform = `translate3d(${diffX}px, 0, 0)`;
                }

                var prevImg = document.getElementById('fsImgPrev');
                var nextImg = document.getElementById('fsImgNext');
                if (diffX > 0 && prevImg && prevImg.style.display === 'none') {
                    var src = getAdjacentSrc(-1);
                    if (src) { prevImg.src = src; prevImg.style.display = 'block'; }
                } else if (diffX < 0 && nextImg && nextImg.style.display === 'none') {
                    var src = getAdjacentSrc(1);
                    if (src) { nextImg.src = src; nextImg.style.display = 'block'; }
                }
            }
        }
    }, { passive: true });

    // Touch End
    fsImg.addEventListener('touchend', function (e) {
        if (isPinching) {
            isPinching = false;
        }
        if (isPanning) {
            isPanning = false;
        }

        // If it was a single finger and scale === 1, detect horizontal swipe
        if (e.changedTouches && e.changedTouches.length === 1 && fsScale === 1) {
            var endX = e.changedTouches[0].clientX;
            var endY = e.changedTouches[0].clientY;
            var diffX = endX - startTouchX;
            var diffY = endY - startTouchY;
            var diffTime = new Date().getTime() - startTouchTime;
            var velocity = Math.abs(diffX) / diffTime;

            if (isSwipeDragging) {
                isSwipeDragging = false;
                if (Math.abs(diffX) > window.innerWidth / 4 || velocity > 0.4) {
                    var dir = diffX > 0 ? 1 : -1;
                    window.fsSwipeDirection = dir; // Tell openFs which way to slide in from
                    window.fsSwipeCurrentX = diffX;
                    handleSwipe(diffX);
                } else {
                    // Snap back to center if swipe threshold not met
                    var wrapper = document.getElementById('fsSliderWrapper');
                    if (wrapper) {
                        wrapper.style.transition = 'transform 0.15s ease-out';
                        wrapper.style.transform = `translate3d(0, 0, 0)`;
                        setTimeout(() => {
                            wrapper.style.transition = 'none';
                            var pImg = document.getElementById('fsImgPrev');
                            var nImg = document.getElementById('fsImgNext');
                            if (pImg) pImg.style.display = 'none';
                            if (nImg) nImg.style.display = 'none';
                        }, 150);
                    } else {
                        fsImg.style.transition = 'transform 0.15s ease-out';
                        fsImg.style.transform = `translate3d(0, 0, 0)`;
                        setTimeout(() => { fsImg.style.transition = ''; }, 150);
                    }
                }
            } else if ((Math.abs(diffX) > 30 || velocity > 0.4) && Math.abs(diffX) > Math.abs(diffY)) {
                // Fallback for very fast swipe flick
                window.fsSwipeDirection = diffX > 0 ? 1 : -1;
                window.fsSwipeCurrentX = diffX;
                handleSwipe(diffX);
            }
        }
    }, { passive: true });

    // Double Tap detection
    fsImg.addEventListener('click', function (e) {
        var now = new Date().getTime();
        var timespan = now - lastTapTime;
        if (timespan < 300 && timespan > 0) {
            // Double Tap!
            if (fsScale > 1) {
                // Reset zoom
                fsScale = 1;
                fsTranslateX = 0;
                fsTranslateY = 0;
            } else {
                // Zoom in to 2.5
                fsScale = 2.5;
                fsTranslateX = 0;
                fsTranslateY = 0;
            }
            fsImg.style.transition = 'transform 0.2s ease-out';
            fsImg.style.transform = `translate3d(${fsTranslateX}px, ${fsTranslateY}px, 0) scale(${fsScale})`;
            setTimeout(() => {
                fsImg.style.transition = '';
            }, 200);
            e.preventDefault();
        }
        lastTapTime = now;
    });
}

function openFs(arg1, arg2, arg3, arg4) {
    var pId, index, dId, cartImgSrc;
    if (arguments.length === 1 && typeof arg1 === 'number') {
        if (!curProduct) return;
        pId = curProduct.id; index = arg1;
    } else if (arguments.length === 4) {
        pId = arg1; index = arg2; dId = arg3; cartImgSrc = arg4;
    } else {
        pId = arg1; index = arg2; dId = arg3;
    }

    window.fsIsStandalone = false;
    document.querySelectorAll('.fs-nav').forEach(n => n.style.display = 'block');

    var deck = document.getElementById('dtDesigns');
    if (!deck) return;

    // 📱 Filter to only visible cards (images/videos that successfully loaded and aren't hidden)
    var cards = Array.from(deck.querySelectorAll('.swipe-card')).filter(card => card.style.display !== 'none');

    if (dId) {
        var foundIdx = cards.findIndex(card => {
            var cardDId = card.getAttribute('data-design') || 'DIRECT';
            return cardDId === dId;
        });
        if (foundIdx !== -1) {
            index = foundIdx;
        }
    }

    if (cards.length === 0) return;
    if (index < 0) index = cards.length - 1;
    if (index >= cards.length) index = 0;

    var targetCard = cards[index];
    if (!targetCard) return;

    // Keep detail panel swipe deck scrolled to align with full screen active card
    targetCard.scrollIntoView({ behavior: 'auto', block: 'nearest', inline: 'center' });

    dId = targetCard.getAttribute('data-design') || 'DIRECT';

    // Auto-detect direction if arrows were clicked instead of swiped
    if (typeof window.fsSwipeDirection === 'undefined' || window.fsSwipeDirection === 0) {
        if (typeof fsIndex !== 'undefined' && index !== fsIndex) {
            window.fsSwipeDirection = index < fsIndex ? 1 : -1;
            window.fsSwipeCurrentX = 0;
            // Check for wrapping
            if (fsIndex === 0 && index === cards.length - 1) window.fsSwipeDirection = 1;
            if (fsIndex === cards.length - 1 && index === 0) window.fsSwipeDirection = -1;
        }
    }

    fsIndex = index;
    fsDesignId = dId;

    var dName = dId === 'DIRECT' ? "Cover" : dId;
    document.getElementById('fsTitle').innerText = curProduct.name + " - " + dName + " (" + (fsIndex + 1) + "/" + cards.length + ")";

    var videoEl = targetCard.querySelector('video');
    var imgEl = targetCard.querySelector('img');
    var fsImg = document.getElementById('fsImg');
    var fsVideo = document.getElementById('fsVideo');

    if (!fsVideo && fsImg) {
        fsVideo = document.createElement('video');
        fsVideo.id = 'fsVideo';
        fsVideo.style.maxWidth = '100%';
        fsVideo.style.maxHeight = '100%';
        fsVideo.style.objectFit = 'contain';
        fsVideo.controls = true;
        fsVideo.playsInline = true;
        fsImg.parentNode.appendChild(fsVideo);
    }

    if (videoEl) {
        if (fsImg) fsImg.style.display = 'none';
        if (fsVideo) {
            fsVideo.style.display = 'block';
            fsVideo.src = videoEl.src;
        }
    } else {
        if (fsVideo) {
            fsVideo.style.display = 'none';
            fsVideo.src = '';
        }
        if (fsImg) {
            fsImg.style.display = 'block';

            var chosenSrc = imgEl ? imgEl.src : '';
            // If the swipe card is still showing the missing SVG placeholder, use the cart image
            if (chosenSrc.includes("data:image/svg+xml") && cartImgSrc) {
                chosenSrc = cartImgSrc;
            }

            if (window.fsSwipeDirection) {
                var dir = window.fsSwipeDirection;
                var currentX = window.fsSwipeCurrentX || 0;
                var wrapper = document.getElementById('fsSliderWrapper');

                if (wrapper) {
                    var sideImg = dir > 0 ? document.getElementById('fsImgPrev') : document.getElementById('fsImgNext');
                    if (sideImg) {
                        sideImg.src = chosenSrc;
                        sideImg.style.display = 'block';
                    }

                    var duration = '0.15s';
                    var targetX = dir * window.innerWidth;

                    wrapper.style.transition = 'none';
                    wrapper.style.transform = `translate3d(${currentX}px, 0, 0)`;
                    void wrapper.offsetWidth;

                    wrapper.style.transition = `transform ${duration} ease-out`;
                    wrapper.style.transform = `translate3d(${targetX}px, 0, 0)`;

                    setTimeout(() => {
                        wrapper.style.transition = 'none';
                        wrapper.style.transform = 'translate3d(0, 0, 0)';
                        fsImg.src = chosenSrc;
                        var pImg = document.getElementById('fsImgPrev');
                        var nImg = document.getElementById('fsImgNext');
                        if (pImg) pImg.style.display = 'none';
                        if (nImg) nImg.style.display = 'none';
                    }, 160);
                } else {
                    fsImg.src = chosenSrc;
                }

                window.fsSwipeDirection = 0;
                window.fsSwipeCurrentX = 0;
            } else {
                fsScale = 1;
                fsTranslateX = 0;
                fsTranslateY = 0;
                fsImg.style.transition = '';
                fsImg.style.transform = 'translate3d(0px, 0px, 0px) scale(1)';
                fsImg.src = chosenSrc;

                var wrapper = document.getElementById('fsSliderWrapper');
                if (wrapper) {
                    wrapper.style.transition = 'none';
                    wrapper.style.transform = 'translate3d(0, 0, 0)';
                    var pImg = document.getElementById('fsImgPrev');
                    var nImg = document.getElementById('fsImgNext');
                    if (pImg) pImg.style.display = 'none';
                    if (nImg) nImg.style.display = 'none';
                }
            }
        }
    }

    var key = pId + '_' + fsDesignId;

    var curStock = window.curProduct && window.curProduct.stock && window.curProduct.stock[fsDesignId] !== undefined ? window.curProduct.stock[fsDesignId] : 999;
    var fsControls = document.querySelector('.fs-controls');
    if (fsControls) {
        if (window.isGuestMode) {
            fsControls.style.display = 'none';
        } else if (!window.isAdminMode && curStock === 0) {
            fsControls.innerHTML = '<span style="background: red; color: white; padding: 6px 16px; border-radius: 4px; font-weight: bold; font-size: 16px;">PACKED</span>';
        } else {
            fsControls.innerHTML = '<button onpointerdown="event.preventDefault(); fsChg(-1)">−</button><span id="fsQty" style="font-size:36px; color:#fff; min-width:50px; text-align:center;">' + (cart[key] ? cart[key].qty : 0) + '</span><button onpointerdown="event.preventDefault(); fsChg(1)">+</button>';
        }
    }

    var fsModal = document.getElementById('fsModal');
    if (fsModal.style.display !== 'flex') {
        fsModal.style.display = 'flex';
        pushHistoryState('fs'); // 🛡️ TRAPS BACK BUTTON
    }
}

function closeFs() {
    document.getElementById('fsModal').style.display = 'none';
    var fsVideo = document.getElementById('fsVideo');
    if (fsVideo) {
        fsVideo.pause();
        fsVideo.src = '';
    }

    // Refresh Cart Live with scroll preservation
    var cartPanel = document.getElementById('cartPanel');
    if (cartPanel && cartPanel.classList.contains('open')) {
        var isEditingAny = false;
        if (window.cartEditingMap) {
            for (var ed in window.cartEditingMap) {
                if (window.cartEditingMap[ed]) isEditingAny = true;
            }
        }
        if (!isEditingAny && typeof openCart === 'function') openCart(true);
    }

    history.back();
}

function fsChg(amt) {
    if (!curProduct) return;
    changeQty(curProduct.id, fsDesignId, amt);
}

// ====================================
// 🛒 CART MODAL
// ====================================

window.openCartFsFromCache = function (pId, dId, gridUrl) {
    var pItem = allProducts.find(x => x.id === pId);
    if (!pItem) return;

    var cartImgId = "cart_img_" + pId + "_" + (dId === 'DIRECT' ? 'DIRECT' : dId.replace(/[^a-zA-Z0-9]/g, ''));
    var cartImgEl = document.getElementById(cartImgId);
    var cartImgSrc = cartImgEl ? cartImgEl.src : null;

    // 1. Instantly show full screen modal with the cached cart image
    var fsModal = document.getElementById('fsModal');
    var fsImg = document.getElementById('fsImg');
    var fsTitle = document.getElementById('fsTitle');
    var fsVideo = document.getElementById('fsVideo');

    if (fsVideo) fsVideo.style.display = 'none';
    if (fsImg) {
        fsImg.style.display = 'block';
        fsImg.src = cartImgSrc || window.dsMissingImage;
        fsImg.style.transform = 'translate3d(0px, 0px, 0px) scale(1)';
    }

    curProduct = pItem;
    fsDesignId = dId;

    if (fsTitle) {
        var dName = dId === 'DIRECT' ? "Cover" : dId;
        fsTitle.innerText = pItem.name + " - " + dName + " (Loading...)";
    }

    if (fsModal && fsModal.style.display !== 'flex') {
        fsModal.style.display = 'flex';
        pushHistoryState('fs'); // 🛡️ TRAPS BACK BUTTON
    }

    // 2. Populate detail panel silently to generate the swipe-cards
    openDetail(pId, true, false, function () {
        // 3. Once fully rendered, call openFs to hook up swipe functionality and HD images
        openFs(pId, 0, dId, cartImgSrc);
    });
};

function openCart(preserveScroll) {
    cameFromDetail = false;
    try {
        var cb = document.getElementById('cartBody');
        if (!cb) return;
        var oldScroll = cb.scrollTop || 0;
        cb.innerHTML = '';
        var count = 0;
        var grouped = {};

        function safeText(str) { return str ? String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;') : ''; }

        // 🛡️ INTERNAL CACHE LOADING
        for (var k in cart) {
            var c = cart[k];
            if (!c || !c.p || !c.p.id) { delete cart[k]; continue; }
            var safeDesign = c.design || 'DIRECT';
            count += (parseInt(c.qty) || 0);
            if (!grouped[c.p.id]) grouped[c.p.id] = { p: c.p, items: [] };
            grouped[c.p.id].items.push(c);
        }

        var cHtml = [];

        var customerHTML = `
            <div style="margin-bottom: 20px; border: 1px solid var(--border); border-radius: 8px; overflow:hidden; background:#fff; display:flex; justify-content:space-between; align-items:center; padding:10px;">
                <div style="display:flex; flex-direction:column; gap:4px; max-width:85%;">
                    <div id="cartCustomerDetailsBody" style="font-size:14px; color:var(--text-main); font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                        Loading...
                    </div>
                </div>
                <i class="fas fa-edit" onclick="openCustomerDetailsModal()" style="cursor:pointer; color:var(--myntra-pink); font-size:16px; padding:10px;"></i>
            </div>
        `;
        cHtml.push(customerHTML);

        window.cartEditingMap = window.cartEditingMap || {};
        for (var r in grouped) {
            var g = grouped[r];
            var pTot = 0;
            g.items.forEach(function (i) { pTot += (parseInt(i.qty) || 0); });
            var isEditing = window.cartEditingMap[g.p.id];

            cHtml.push('<div style="margin-bottom: 20px; border: 1px solid var(--border); border-radius: 8px; overflow:hidden;">');
            cHtml.push('<div style="background:#f5f5f6; padding:10px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">');
            cHtml.push('<div style="' + (!isEditing ? 'cursor:pointer;' : '') + ' flex:1;" ' + (!isEditing ? 'onclick="closeCart(true); openDetail(\'' + g.p.id + '\');"' : '') + '>');
            cHtml.push('<div style="font-weight:bold; font-size:15px; color:var(--myntra-pink); text-decoration:underline;">' + safeText(g.p.name) + ' <i class="fas fa-external-link-alt" style="font-size:12px;"></i></div>');

            if (isEditing) {
                cHtml.push('<div style="font-size:12px; color:var(--text-light); margin-top:4px;">SKU: ' + safeText(g.p.sku) +
                    ' | Rate: ₹<input type="number" id="ie_rate_' + g.p.id + '" value="' + g.p.price + '" onchange="saveCartInlineEdit(\'' + g.p.id + '\', false)" style="width:60px; padding:2px 4px; border:1px solid #ccc; border-radius:4px; margin-right:4px;">' +
                    ' | Packing: <input type="text" id="ie_pack_' + g.p.id + '" value="' + safeText(g.p.packing || 1) + '" onchange="saveCartInlineEdit(\'' + g.p.id + '\', false)" style="width:40px; padding:2px 4px; border:1px solid #ccc; border-radius:4px;"></div>');
                cHtml.push('</div>');
                cHtml.push('<div style="display:flex; gap:8px; padding:10px; align-items:center;">');
                cHtml.push('<i class="fas fa-trash" onclick="deleteCartProduct(\'' + g.p.id + '\')" style="cursor:pointer; color:red; font-size:18px;" title="Delete Product"></i>');
                cHtml.push('<i class="fas fa-check-circle" onclick="saveCartInlineEdit(\'' + g.p.id + '\', true)" style="cursor:pointer; color:green; font-size:22px;" title="Done"></i>');
                cHtml.push('</div>');
            } else {
                cHtml.push('<div style="font-size:12px; color:var(--text-light); margin-top:4px;">SKU: ' + safeText(g.p.sku) + ' | Rate: ₹' + g.p.price + ' | Packing: ' + safeText(g.p.packing) + ' | Total Qty: ' + pTot + ' pcs</div>');
                cHtml.push('</div>');
                cHtml.push('<i class="fas fa-edit" onclick="toggleCartInlineEdit(\'' + g.p.id + '\')" style="cursor:pointer; color:var(--myntra-pink); font-size:18px; padding: 10px;"></i>');
            }

            cHtml.push('</div><div style="display:flex; flex-wrap:wrap; gap:10px; padding:10px;">');

            g.items.forEach(function (item) {
                var safeDesignLabel = item.design || 'DIRECT';
                var dLabel = safeDesignLabel === 'DIRECT' ? 'Cover' : safeDesignLabel;
                var imgId = "cart_img_" + g.p.id + "_" + safeDesignLabel.replace(/[^a-zA-Z0-9]/g, '');

                var onClickAction = safeDesignLabel === 'DIRECT' ?
                    "closeCart(true); openDetail('" + g.p.id + "');" :
                    "openCartFsFromCache('" + g.p.id + "', '" + safeDesignLabel + "', '" + g.p.gridUrl + "');";

                cHtml.push('<div style="width: 80px; text-align: center;" ' + (!isEditing ? 'onclick="' + onClickAction + '"' : '') + '>');
                cHtml.push('<img id="' + imgId + '" src="' + window.dsMissingImage + '" style="width: 80px; height: 80px; object-fit: cover; object-position: top center; border: 1px solid var(--border); ' + (!isEditing ? 'cursor: pointer;' : '') + '">');
                cHtml.push('<div style="font-size: 11px; margin-top: 4px; color:var(--text-light);">' + dLabel + '</div>');

                if (isEditing) {
                    cHtml.push('<input type="number" id="ie_qty_' + g.p.id + '_' + safeDesignLabel + '" value="' + (item.qty || 0) + '" onchange="saveCartInlineEdit(\'' + g.p.id + '\', false)" style="width:60px; padding:4px; border:1px solid #myntra-pink; border-radius:4px; text-align:center; font-size:12px; font-weight:bold; color:var(--text-main); margin-top:2px;">');
                } else {
                    cHtml.push('<div id="cart_qty_text_' + g.p.id + '_' + safeDesignLabel + '" style="font-size: 12px; font-weight: bold; color: var(--myntra-pink);">' + (item.qty || 0) + ' pcs</div>');
                }
                cHtml.push('</div>');
            });
            cHtml.push('</div></div>');
        }

        if (count === 0) {
            cb.innerHTML = '<div style="text-align:center; padding:40px 20px; color:var(--text-light); font-weight:bold;">Your Cart is empty.</div>';
        } else {
            cb.innerHTML = cHtml.join('');
            loadCartCustomerDetails();

            // Load Grid Images for Cart Items from IndexedDB cache directly
            setTimeout(() => {
                var bucket = "durga-sarees.firebasestorage.app";
                var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";
                for (var r in grouped) {
                    (function (group) {
                        group.items.forEach(function (item) {
                            var safeDesignLabel = item.design || 'DIRECT';
                            var imgId = "cart_img_" + group.p.id + "_" + safeDesignLabel.replace(/[^a-zA-Z0-9]/g, '');
                            var imgEl = document.getElementById(imgId);
                            if (!imgEl) return;
                            var fallbackSVG = "data:image/svg+xml;base64," + btoa('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="100%" height="100%" fill="#eee"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="20" fill="#999">Design Not Found</text></svg>');

                            if (safeDesignLabel === 'DIRECT') {
                                if (window.renderWebpFromFolder) {
                                    window.renderWebpFromFolder(imgEl, group.p.gridUrl, group.p.zoomUrl, null);
                                } else {
                                    imgEl.src = fallbackSVG;
                                }
                                return;
                            }

                            if (!group.p.gridUrl) return;

                            var cleanGrid = decodeURIComponent(String(group.p.gridUrl)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
                            var encGridPath = cleanGrid.split('/').map(s => encodeURIComponent(s)).join('%2F');

                            window.findDesignKeyInCache(group.p.gridUrl, safeDesignLabel).then(function (cacheKey) {
                                if (!cacheKey) {
                                    // Not found in cache. Use Firebase List API to dynamically find the correct filename!
                                    var listPrefix = encGridPath + "%2F";
                                    var listUrl = fbBase + "?prefix=" + listPrefix + "&delimiter=/";

                                    if (!window.folderListCache) window.folderListCache = {};

                                    var fetchPromise;
                                    if (window.folderListCache[listUrl]) {
                                        fetchPromise = Promise.resolve(window.folderListCache[listUrl]);
                                    } else {
                                        fetchPromise = fetch(listUrl).then(function (res) {
                                            if (res.ok) return res.json();
                                            throw new Error("List HTTP " + res.status);
                                        }).then(function (data) {
                                            var files = (data.items || []).map(function (item) {
                                                return item.name.substring(item.name.lastIndexOf('/') + 1);
                                            }).filter(function (f) { return /\.(webp|jpg|jpeg|png)$/i.test(f); });
                                            window.folderListCache[listUrl] = files;
                                            return files;
                                        });
                                    }

                                    fetchPromise.then(function (folderFiles) {
                                        if (folderFiles.length === 0) throw new Error("Folder empty");

                                        var targetFile = null;
                                        var targetNum = parseInt(String(safeDesignLabel).replace(/\D/g, ''));

                                        if (!isNaN(targetNum)) {
                                            for (var i = 0; i < folderFiles.length; i++) {
                                                var f = folderFiles[i];
                                                var nameWithoutExt = f.substring(0, f.lastIndexOf('.'));
                                                if (parseInt(nameWithoutExt.replace(/\D/g, '')) === targetNum) {
                                                    targetFile = f;
                                                    break;
                                                }
                                            }
                                        }
                                        if (!targetFile) {
                                            for (var i = 0; i < folderFiles.length; i++) {
                                                var f = folderFiles[i];
                                                var nameWithoutExt = f.substring(0, f.lastIndexOf('.'));
                                                if (nameWithoutExt.toLowerCase() === String(safeDesignLabel).toLowerCase()) {
                                                    targetFile = f;
                                                    break;
                                                }
                                            }
                                        }
                                        if (!targetFile) targetFile = folderFiles[0];

                                        var finalUrl = fbBase + encGridPath + "%2F" + encodeURIComponent(targetFile) + "?alt=media";
                                        return fetch(finalUrl).then(function (r) {
                                            if (r.ok) {
                                                return r.blob().then(function (blob) {
                                                    imgEl.src = URL.createObjectURL(blob);
                                                    saveImageToDB(finalUrl, blob);
                                                });
                                            }
                                            throw new Error("HTTP " + r.status);
                                        });
                                    }).catch(function () {
                                        imgEl.src = fallbackSVG;
                                    });
                                    return;
                                }

                                getImageFromDB(cacheKey).then(function (blob) {
                                    if (blob) {
                                        imgEl.src = URL.createObjectURL(blob);
                                    } else {
                                        imgEl.src = fallbackSVG;
                                    }
                                }).catch(function () {
                                    imgEl.src = fallbackSVG;
                                });
                            });
                        });
                    })(grouped[r]);
                }
            }, 50);
        }

        var headerCount = document.getElementById('cartCountHeader');
        if (headerCount) headerCount.innerText = count;
        var footerQty = document.getElementById('cartTotalQty');
        if (footerQty) footerQty.innerText = count + " pcs";

        localStorage.setItem("dsCart", JSON.stringify(cart));

        var panel = document.getElementById('cartPanel');
        if (panel && !panel.classList.contains('open')) {
            panel.classList.add('open');
            pushHistoryState('cart');
        }

        if (preserveScroll && cb) {
            cb.scrollTop = oldScroll;
        }

    } catch (err) {
        console.error("Cart Error: ", err);
        alert("Cart encountered an error and was reset.");
        cart = {};
        localStorage.removeItem("dsCart");
    }
}

function closeCart(skipHistory) {
    var panel = document.getElementById('cartPanel');
    if (panel) panel.classList.remove('open');
    if (!skipHistory) history.back();
}

function clearCart() {
    if (confirm("Are you sure you want to empty your cart?")) {
        cart = {};
        try { localStorage.removeItem("dsCart"); } catch (e) { }
        closeCart();
        updateCartHeader();
        renderProductGrid(displayList); // Reload main screen inputs
    }
}

// ====================================
// 📄 SAVE ORDER — GENERATES CART PDF (Lightning Fast from Cache)
// ====================================
function sendWhatsapp() {
    var keys = Object.keys(cart);
    if (keys.length === 0) return alert("Your cart is empty!");

    // Generate the cart PDF and share it natively
    if (typeof generateCartOrderPDF === 'function') {
        generateCartOrderPDF('share');
    } else {
        alert("PDF Engine not loaded!");
    }
}

// ====================================
// 💬 WHATSAPP TEXT ORDER (Legacy — PC & Mobile)
// ====================================
function sendWhatsappText() {
    var keys = Object.keys(cart);
    if (keys.length === 0) return alert("Your cart is empty!");

    var msg = "🛍️ *New Order from Durga Sarees App*\n\n";
    var totalQty = 0;
    var groups = {};

    for (var k in cart) {
        var item = cart[k];
        if (!item || !item.p) continue;
        if (!groups[item.p.id]) groups[item.p.id] = { p: item.p, items: [] };
        groups[item.p.id].items.push(item);
    }

    for (var r in groups) {
        var g = groups[r];
        msg += "🏷️ *" + g.p.name + "* (SKU: " + (g.p.sku || "-") + ")\n";
        g.items.forEach(function (item) {
            var dName = item.design === 'DIRECT' ? 'Cover' : item.design;
            msg += "  - " + dName + ": " + item.qty + " pcs\n";
            totalQty += (parseInt(item.qty) || 0);
        });
        msg += "\n";
    }
    msg += "📦 *Total Quantity:* " + totalQty + " pcs\n";
    msg += "🌐 www.durgasarees.com\n";

    var number = "919998232380";
    var encodedMsg = encodeURIComponent(msg);
    var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

    if (isMobile) {
        window.open("whatsapp://send?phone=" + number + "&text=" + encodedMsg, '_blank');
    } else {
        window.open("https://web.whatsapp.com/send?phone=" + number + "&text=" + encodedMsg, '_blank');
    }
}

// Utilities are defined at the bottom of the file

function getExactFirebaseUrl(folderPath, dId) {
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/";
    var encPath = folderPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
    var fileName = "cover.webp"; // Default to cover.webp
    try {
        if (dId === 'DIRECT' || dId === 'Cover') {
            var fMap = JSON.parse(localStorage.getItem("dsFallbackMap") || "{}");
            if (fMap[folderPath]) fileName = fMap[folderPath];
        }
    } catch (e) { }
    if (dId !== 'DIRECT' && dId !== 'Cover') {
        if (/\.(webp|jpg|jpeg|png)$/i.test(dId)) {
            fileName = dId;
        } else {
            var num = dId.replace(/\D/g, '');
            if (num.length === 1) num = "0" + num;
            if (num === "") num = dId;
            fileName = num + ".webp";
        }
    }
    return fbBase + encPath + "%2F" + encodeURIComponent(fileName) + "?alt=media";
}

// ====================================
// 🖼️ 2. MODAL & SHARE LOGIC (MULTI-IMAGE UPGRADE)
// ====================================




window.openCartFs = function (productId, designId, cartImgSrc) {
    var actualProductId = curProduct ? curProduct.id : productId;

    // THE FIX: Pre-load the swipe deck in the background so swiping works correctly!
    openDetail(actualProductId, true, true);

    // Open full screen viewer instantly with the clicked cart image
    openFs(actualProductId, 0, designId, cartImgSrc);
};



// ====================================
// UTILS & HELPERS
// ====================================
window.goToHome = function () {
    cameFromDetail = false;
    var detail = document.getElementById('detailPanel');
    var cart = document.getElementById('cartPanel');
    if (detail && detail.classList.contains('open')) closeDetail();
    if (cart && cart.classList.contains('open')) { cart.classList.remove('open'); history.back(); }
    document.querySelectorAll('.action-modal').forEach(m => m.style.display = 'none');
};
window.fetchWithRetry = async function (url, options = {}, retries = 3) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        throw new Error("Device is offline");
    }
    if (typeof url === 'string' && (url.includes('firebasestorage.googleapis.com') || url.includes('firestore.googleapis.com'))) {
        try {
            var token = "";
            if (window.CapacitorFirebaseAuthentication) {
                var tRes = await window.CapacitorFirebaseAuthentication.getIdToken();
                if (tRes && tRes.token) token = tRes.token;
            } else if (typeof firebase !== 'undefined' && firebase.auth && firebase.auth().currentUser) {
                token = await firebase.auth().currentUser.getIdToken();
            }
            if (token) {
                options.headers = options.headers || {};
                if (!options.headers['Authorization']) options.headers['Authorization'] = 'Bearer ' + token;
            }
        } catch (e) { }
    }
    for (let i = 0; i < retries; i++) {
        try {
            var res = await fetch(url, options);
            if (res.ok) return res;
            if (res.status === 404) return res; // Don't retry true 404s
            throw new Error("HTTP " + res.status);
        } catch (err) {
            if (i === retries - 1) {
                if (err.message.includes("HTTP")) return res; // Return the failed response on last try
                throw err; // Throw network errors
            }
            await new Promise(r => setTimeout(r, 1000 + (i * 1000))); // Backoff
        }
    }
    return fetch(url, options); // Last ditch
};

window.isSyncing = false;
async function syncImages(silent = false) {
    var bootScreen = document.getElementById('boot');
    var bootMsg = document.getElementById('bootMsg');
    var syncIcon = document.querySelector('.fa-sync-alt');

    if (window.isSyncing) {
        if (bootScreen && !silent) bootScreen.style.display = 'flex';
        return;
    }

    window.isSyncing = true;
    if (syncIcon) syncIcon.classList.add('fa-spin');

    // Reset per-sync caches
    coverExistsMap = {};
    try { localStorage.removeItem("dsCoverExists"); } catch (e) { }
    if (!window.dsFolderCache) {
        try { window.dsFolderCache = JSON.parse(localStorage.getItem("dsFolderCache")) || {}; } catch (e) { window.dsFolderCache = {}; }
    }
    window.syncReportResults = [];

    if (bootMsg) bootMsg.innerText = "Fetching latest product list...";

    try {
        const res = await window.fetchWithRetry(FIRESTORE_PRODUCTS_URL);
        const data = await res.json();
        var docs = data.documents || [];

        var productsToSync = [];
        docs.forEach(d => {
            var f = d.fields || {};
            var name = f.name ? f.name.stringValue : "";
            var gridUrl = f.gridUrl ? f.gridUrl.stringValue : "";
            var zoomUrl = f.zoomUrl ? f.zoomUrl.stringValue : "";
            var coverDesignId = f.coverDesignId ? f.coverDesignId.stringValue : "";
            var docId = d.name ? d.name.split('/').pop() : "";
            var isWix = JSON.stringify(f).toLowerCase().includes("wix import");

            var stock = {};
            if (f.stock && f.stock.mapValue && f.stock.mapValue.fields) {
                var sf = f.stock.mapValue.fields;
                for (var key in sf) {
                    stock[key] = parseInt(sf[key].integerValue || "0", 10);
                }
            }

            if (name && name.toLowerCase() !== "temp" && name.toLowerCase() !== "unnamed"
                && !isWix && gridUrl && gridUrl.trim() !== "" && gridUrl.toLowerCase() !== "none") {
                productsToSync.push({ name, gridUrl, zoomUrl, coverDesignId, docId, stock });
            }
        });

        if (productsToSync.length === 0) {
            window.isSyncing = false;
            if (syncIcon) syncIcon.classList.remove('fa-spin');
            if (bootScreen) bootScreen.style.display = 'none';
            alert("No products found to sync.");
            initApp();
            return;
        }

        var total = productsToSync.length;
        var count = 0;
        var failed = 0;
        var failedList = [];
        var bucket = "durga-sarees.firebasestorage.app";
        var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";

        if (bootMsg) bootMsg.innerText = "Smart syncing 0 / " + total + "...";

        // 🛡️ BATCH LIMIT: Process 1 folder at a time, but fetch its inner images in parallel (Max 5 concurrent).
        // This guarantees we never hit Samsung/Android OS TCP socket connection limits (ERR_INSUFFICIENT_RESOURCES).
        var batchSize = 40;
        for (var i = 0; i < productsToSync.length; i += batchSize) {
            var batch = productsToSync.slice(i, i + batchSize);
            await Promise.all(batch.map(async (p) => {
                var cleanGrid = decodeURIComponent(String(p.gridUrl)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
                var encGridPath = cleanGrid.split('/').map(s => encodeURIComponent(s)).join('%2F');
                var listPrefix = cleanGrid.split('/').map(s => encodeURIComponent(s)).join('/') + '/';
                var listUrl = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o?prefix=" + listPrefix + "&delimiter=/";
                var lastFailReason = "";
                var downloaded = false;

                // ── 1. Fetch Firebase folder listing ──────────────────────
                var folderFiles = []; // filenames only (e.g. "01.webp", "02.webp")
                var listSuccess = false;
                try {
                    const ctrl = new AbortController();
                    const tid = setTimeout(() => ctrl.abort(), 30000);
                    // 🛡️ CRITICAL FIX: Bulletproof retry for "failed to fetch"
                    var listRes = await window.fetchWithRetry(listUrl, { signal: ctrl.signal }, 3);
                    clearTimeout(tid);
                    if (listRes.ok) {
                        var listData = await listRes.json();
                        if (!window.dsFolderCache) window.dsFolderCache = {};
                        window.dsFolderCache[listUrl] = listData.items || [];
                        try { localStorage.setItem("dsFolderCache", JSON.stringify(window.dsFolderCache)); } catch (e) { }

                        folderFiles = (listData.items || [])
                            .map(item => item.name.substring(item.name.lastIndexOf('/') + 1))
                            .filter(f => /\.(webp|jpg|jpeg|png)$/i.test(f));
                        listSuccess = true;
                    } else {
                        lastFailReason = "List HTTP " + listRes.status;
                    }
                } catch (e) {
                    lastFailReason = "List failed: " + (e.name === 'AbortError' ? 'Timeout (15s)' : e.message);
                    window.logAppError('syncImages List', lastFailReason + " | " + p.name);
                }

                if (!listSuccess) {
                    // Offline / error — keep existing cache, log error
                    var existingCover = await checkImageInDB(p.gridUrl);
                    if (existingCover) downloaded = true;
                    else lastFailReason = lastFailReason || "Offline & no local cache";

                } else if (folderFiles.length === 0) {
                    // Firebase folder is EMPTY — keep existing cover, do NOT delete
                    downloaded = true;
                    console.log("[SYNC] Folder empty for", p.name, "- keeping cached cover.");

                } else {
                    // Sort files: 01.webp first, then 02, 03...
                    folderFiles.sort((a, b) =>
                        (parseInt(a.replace(/\D/g, '')) || 999) - (parseInt(b.replace(/\D/g, '')) || 999));

                    // Build the full Firebase URL keys that should exist in DB
                    // Cover = first file, key stored as gridUrl (bare folder path)
                    // Designs = each file, key stored as full Firebase URL
                    var coverFile;
                    if (p.coverDesignId) {
                        var cleanCoverId = String(p.coverDesignId).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                        var exact = folderFiles.find(f => f.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase() === cleanCoverId);
                        if (exact) {
                            coverFile = exact;
                        } else {
                            // AUTO-HEALING GHOST METADATA (listSuccess is already true here)
                            var patchUrl = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + p.docId + "?updateMask.fieldPaths=coverDesignId";
                            fetch(patchUrl, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { coverDesignId: { stringValue: "" } } }) }).catch(e => { });
                            p.coverDesignId = ""; // Clear locally
                        }
                    }
                    if (!coverFile) {
                        var possibleCovers = ["cover", "cover1"];
                        var foundCover = folderFiles.find(f => possibleCovers.includes(f.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase()));
                        coverFile = foundCover || folderFiles[0];
                    }
                    var coverUrl = fbBase + encGridPath + "%2F" + encodeURIComponent(coverFile) + "?alt=media";

                    var remoteItem = listData.items.find(it => it.name.endsWith("/" + coverFile));
                    var remoteTime = remoteItem && remoteItem.updated ? new Date(remoteItem.updated).getTime() : 0;
                    if (!window.dsCoverTimeCache) window.dsCoverTimeCache = JSON.parse(localStorage.getItem("dsCoverTimeCache") || "{}");

                    var encZoomPath = "";
                    if (p.zoomUrl && String(p.zoomUrl).toLowerCase() !== "none" && p.zoomUrl !== p.gridUrl) {
                        var cleanZoom = decodeURIComponent(String(p.zoomUrl)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
                        encZoomPath = cleanZoom.split('/').map(s => encodeURIComponent(s)).join('%2F');
                    }

                    var designKeys = {};
                    folderFiles.forEach(f => {
                        var gridKey = fbBase + encGridPath + "%2F" + encodeURIComponent(f) + "?alt=media";
                        designKeys[gridKey] = gridKey;
                        if (encZoomPath) {
                            var zoomKey = fbBase + encZoomPath + "%2F" + encodeURIComponent(f) + "?alt=media";
                            designKeys[zoomKey] = zoomKey;
                        }
                    });

                    // ── 2. Cleanup: Delete from DB keys NOT in Firebase anymore (Grid + Zoom) ──
                    var prefixesToClean = [fbBase + encGridPath + "%2F"];
                    if (encZoomPath) prefixesToClean.push(fbBase + encZoomPath + "%2F");

                    for (var prefix of prefixesToClean) {
                        var cachedKeys = await listDBKeysForPrefix(prefix);
                        for (var ck of cachedKeys) {
                            if (!designKeys[ck]) {
                                await deleteImageFromDB(ck);
                                console.log("[SYNC] Deleted stale cache:", ck);
                            }
                        }
                    }

                    // Save folder files for Phase 2
                    p._folderFiles = folderFiles;

                    // ——— 3. Download the COVER file (GRID ONLY) —————————————————————————————————
                    var existingCover = await checkImageInDB(p.gridUrl);
                    var localTime = window.dsCoverTimeCache[p.gridUrl] || 0;

                    if (existingCover && localTime >= remoteTime) {
                        downloaded = true;
                    } else {
                        if (existingCover) {
                            console.log("[SYNC] Updating stale cover for", p.name);
                            await deleteImageFromDB(p.gridUrl);
                        }
                        try {
                            const ctrl2 = new AbortController();
                            const tid2 = setTimeout(() => ctrl2.abort(), 30000);
                            // Add cache-buster to ensure CDN miss for updated files
                            var coverRes = await window.fetchWithRetry(coverUrl + "&_cb=" + Date.now(), { signal: ctrl2.signal }, 3);
                            clearTimeout(tid2);

                            if (coverRes.ok) {
                                var coverBlob = await coverRes.blob();
                                if (coverBlob.size === 0) {
                                    lastFailReason = "Cover image is 0 bytes (corrupted)";
                                    if (typeof window.logAppError === 'function') window.logAppError('Sync Corrupt Image', coverFile + " | " + p.name);
                                    downloaded = false;
                                } else {
                                    await saveImageToDB(p.gridUrl, coverBlob);
                                    await saveImageToDB(coverUrl, coverBlob);
                                    window.dsCoverTimeCache[p.gridUrl] = remoteTime;
                                    try { localStorage.setItem("dsCoverTimeCache", JSON.stringify(window.dsCoverTimeCache)); } catch (e) { }
                                    downloaded = true;
                                }
                            } else {
                                lastFailReason = "Cover HTTP " + coverRes.status;
                            }
                        } catch (e) {
                            lastFailReason = "Cover fetch: " + (e.name === 'AbortError' ? 'Timeout (30s)' : e.message);
                        }
                    }

                    // ——— 4. Download remaining design files (FAST PARALLEL BATCHING - GRID ONLY) ——————————————————
                    if (downloaded) {
                        var innerBatchSize = 2; // Download 2 inner images concurrently!
                        var remainingFiles = folderFiles.filter(f => f !== coverFile);
                        for (var fIdx = 0; fIdx < remainingFiles.length; fIdx += innerBatchSize) {
                            var fBatch = remainingFiles.slice(fIdx, fIdx + innerBatchSize);
                            await Promise.all(fBatch.map(async (fname) => {
                                var designUrl = fbBase + encGridPath + "%2F" + encodeURIComponent(fname) + "?alt=media";
                                var existing = await checkImageInDB(designUrl);

                                var remoteDesignItem = listData.items.find(it => it.name.endsWith("/" + fname));
                                var remoteDesignTime = remoteDesignItem && remoteDesignItem.updated ? new Date(remoteDesignItem.updated).getTime() : 0;
                                var localDesignTime = window.dsCoverTimeCache[designUrl] || 0;

                                if (!existing || localDesignTime < remoteDesignTime) {
                                    if (existing) {
                                        console.log("[SYNC] Updating stale inner image:", fname);
                                        await deleteImageFromDB(designUrl);
                                    }
                                    try {
                                        const ctrl3 = new AbortController();
                                        const tid3 = setTimeout(() => ctrl3.abort(), 30000);
                                        var dRes = await window.fetchWithRetry(designUrl + "&_cb=" + Date.now(), { signal: ctrl3.signal }, 3);
                                        clearTimeout(tid3);
                                        if (dRes.ok) {
                                            var dBlob = await dRes.blob();
                                            if (dBlob.size === 0) {
                                                if (typeof window.logAppError === 'function') window.logAppError('Sync Corrupt Image', fname + " | " + p.name);
                                                downloaded = false;
                                                lastFailReason = (lastFailReason ? lastFailReason + ", " : "Corrupted: ") + fname;
                                            } else {
                                                await saveImageToDB(designUrl, dBlob);
                                                window.dsCoverTimeCache[designUrl] = remoteDesignTime;
                                                try { localStorage.setItem("dsCoverTimeCache", JSON.stringify(window.dsCoverTimeCache)); } catch (e) { }
                                            }
                                        } else {
                                            window.logAppError('AUDITOR: Sync Engine Failure', `Missing File: HTTP ${dRes.status} | ${fname} | ${p.name}`);
                                        }
                                    } catch (e) {
                                        console.warn("[SYNC] Fast design fetch failed:", fname, e.message); if (typeof window.logAppError === 'function') window.logAppError('Sync Inner Image', e.message + " | " + p.name);
                                    }
                                }
                            }));
                        }
                    }
                }
                // ── 5. Track errors ──────────────────────────────────────────
                if (!downloaded) {
                    failed++;
                    failedList.push({ name: p.name, path: p.gridUrl, reason: lastFailReason });
                    console.error("❌ SYNC FAILED:", p.name, "|", lastFailReason);
                    if (!window.syncReportResults) window.syncReportResults = [];
                    var syncErrKey = p.gridUrl;
                    var existing2 = window.syncReportResults.find(r => r._gridUrl === syncErrKey);
                    if (existing2) {
                        existing2.error = "Sync Failed: " + lastFailReason;
                        existing2.status = 'error';
                    } else {
                        window.syncReportResults.push({
                            id: null, _gridUrl: syncErrKey,
                            name: p.name, sku: p.sku || '-',
                            error: "Sync Failed: " + lastFailReason,
                            imageCount: 0, status: 'error'
                        });
                    }
                }

                count++;
            }));

            if (bootMsg) bootMsg.innerText = "Smart syncing " + count + " / " + total + "...";

            // Yield the main thread to keep UI smooth
            await new Promise(resolve => setTimeout(resolve, 50));
        }
        if (bootScreen) bootScreen.style.display = 'none';
        window.isSyncing = false;
        if (syncIcon) syncIcon.classList.remove('fa-spin');

        // 🚀 PHASE 2: SILENT BACKGROUND ZOOM SYNC & OUT-OF-STOCK CLEANUP
        (async function () {
            var zBatchSize = 10;
            for (var i = 0; i < productsToSync.length; i += zBatchSize) {
                var batch = productsToSync.slice(i, i + zBatchSize);
                await Promise.all(batch.map(async (p) => {
                    if (!p._folderFiles || p._folderFiles.length === 0) return;
                    if (!p.zoomUrl || String(p.zoomUrl).toLowerCase() === "none" || p.zoomUrl === p.gridUrl) return;

                    var cleanZoom = decodeURIComponent(String(p.zoomUrl)).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => s.trim()).join('/');
                    var encZoomPath = cleanZoom.split('/').map(s => encodeURIComponent(s)).join('%2F');

                    // Sort exactly as UI does to match stock indices
                    var sortedFiles = Array.from(p._folderFiles);
                    if (p.coverDesignId && p.coverDesignId !== "None") {
                        var cleanCover = p.coverDesignId.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                        sortedFiles.sort((a, b) => {
                            var aClean = a.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                            var bClean = b.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                            if (aClean === cleanCover) return -1;
                            if (bClean === cleanCover) return 1;
                            return (parseInt(a.replace(/\D/g, '')) || 999) - (parseInt(b.replace(/\D/g, '')) || 999);
                        });
                    } else {
                        sortedFiles.sort((a, b) => {
                            var possible = ["cover", "cover1", "01", "1"];
                            var aClean = a.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                            var bClean = b.replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
                            if (possible.includes(aClean)) return -1;
                            if (possible.includes(bClean)) return 1;
                            return (parseInt(a.replace(/\D/g, '')) || 999) - (parseInt(b.replace(/\D/g, '')) || 999);
                        });
                    }

                    async function handleZoomImage(fname, index) {
                        var curStock = p.stock && p.stock[String(index)] !== undefined ? p.stock[String(index)] : 0;
                        var zoomImgUrl = fbBase + encZoomPath + "%2F" + encodeURIComponent(fname) + "?alt=media";
                        var existing = await checkImageInDB(zoomImgUrl);

                        if (curStock > 0) {
                            if (existing) return;
                            try {
                                var zRes = await window.fetchWithRetry(zoomImgUrl, {}, 2);
                                if (zRes.ok) {
                                    var zBlob = await zRes.blob();
                                    if (zBlob.size > 0) await saveImageToDB(zoomImgUrl, zBlob);
                                }
                            } catch (e) { }
                        } else {
                            // OUT OF STOCK - DELETE ZOOM
                            if (existing) {
                                await deleteImageFromDB(zoomImgUrl);
                                console.log("[SYNC Phase 2] Deleted out-of-stock zoom cache:", fname);
                            }
                        }
                    }

                    for (var iFile = 0; iFile < sortedFiles.length; iFile++) {
                        await handleZoomImage(sortedFiles[iFile], iFile);
                    }
                }));
                // Yield the main thread to keep UI smooth
                await new Promise(resolve => setTimeout(resolve, 50));
            }
        })();

        if (silent) {
            // Background sync update: update main screen layout with newly localized grid imagery
            renderProductGrid(displayList);
            return;
        }

        if (failed > 0) {
            var elSum = document.getElementById('syncReportSummary');
            var elDet = document.getElementById('syncReportDetails');
            if (elSum && elDet) {
                elSum.innerText = "Sync done: " + (total - failed) + " OK, " + failed + " failed.";
                elSum.style.color = "var(--myntra-pink)";
                var html = "";
                failedList.forEach(f => {
                    html += `<div style="margin-bottom: 8px; border-bottom: 1px solid #f0f0f0; padding-bottom: 8px;">
                                <span style="font-weight: bold;">${f.name}</span><br>
                                <span style="color: red;">Error: ${f.reason}</span>
                             </div>`;
                });
                elDet.innerHTML = html;
                openModal('syncResultsModal');
            } else {
                alert("Sync done. " + failed + " failed. (UI missing)");
            }
        } else {
            var elSum = document.getElementById('syncReportSummary');
            var elDet = document.getElementById('syncReportDetails');
            if (elSum && elDet) {
                elSum.innerText = "✅ Sync complete!";
                elSum.style.color = "#25D366";
                elDet.innerHTML = "<div style='text-align:center; padding: 20px;'>All " + total + " products synced successfully!</div>";
                openModal('syncResultsModal');
            } else {
                alert("✅ Sync complete! All " + total + " products synced.");
            }
        }

        initApp();

    } catch (err) {
        window.isSyncing = false;
        if (syncIcon) syncIcon.classList.remove('fa-spin');
        if (bootScreen) bootScreen.style.display = 'none';
        if (!silent) alert("Sync error: " + err.message);
        initApp();
    }
}

function openModal(id) {
    cameFromDetail = false;
    var m = document.getElementById(id);
    if (m) { m.style.display = 'flex'; pushHistoryState(id); }
}
function closeModals(fromHistory) {
    document.querySelectorAll('.action-modal').forEach(m => m.style.display = 'none');
    if (!fromHistory) history.back();
}

function pushHistoryState(modal) {
    history.pushState({ modal: modal }, '', '#' + modal);
    updateAndroidBackState();
}

function showDevLog(msg, isErr) {
    var d = document.createElement('div');
    d.style.position = 'fixed'; d.style.top = '70px'; d.style.left = '10px'; d.style.right = '10px';
    d.style.background = isErr ? '#c62828' : '#2e7d32'; d.style.color = '#fff';
    d.style.padding = '12px'; d.style.borderRadius = '8px'; d.style.zIndex = '999999';
    d.style.boxShadow = '0 4px 6px rgba(0,0,0,0.3)'; d.style.fontSize = '14px';
    d.innerText = msg;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 7000);
}

function saveProductEdit(p) {
    if (!window.isSuperAdmin) {
        console.log("Local edit only (non-admin). Not syncing to server.");
        return;
    }
    try {
        // 🚀 NEW: 2-WAY SYNC FROM PRODUCT PAGE - FIREBASE & EXCEL WEBHOOK
        if (p && p.docId) {
            showDevLog("Syncing Page: " + p.name + " -> Rate: " + p.price + " Pack: " + p.packing, false);

            // Firebase Live DB Update - Decoupled to support Granular RBAC
            var fbUpdateUrlPrice = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + p.docId + "?updateMask.fieldPaths=price";
            window.fetchWithRetry(fbUpdateUrlPrice, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fields: { price: { integerValue: p.price } } })
            }, 1).then(res => {
                if (res.ok) showDevLog("✅ Firebase Price Updated: " + p.name, false);
                else showDevLog("❌ FB Err " + res.status + " - No Admin Perms for Price?", true);
            }).catch(err => showDevLog("FB Net Err: " + err.message, true));

            var fbUpdateUrlPacking = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + p.docId + "?updateMask.fieldPaths=packing";
            window.fetchWithRetry(fbUpdateUrlPacking, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fields: { packing: { stringValue: p.packing } } })
            }, 1).then(res => {
                if (res.ok) showDevLog("✅ Firebase Packing Updated: " + p.name, false);
                else showDevLog("❌ FB Err " + res.status + " - No Perms for Packing?", true);
            }).catch(err => showDevLog("FB Net Err: " + err.message, true));

            if (window.DS_APP_SCRIPT_URL) {
                fetch(window.DS_APP_SCRIPT_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify({
                        action: 'updateProductDetails',
                        productName: p.name,
                        price: p.price,
                        packing: p.packing
                    })
                }).then(r => r.json())
                    .then(data => {
                        if (!data.success) showDevLog("❌ Excel Err: " + data.msg, true);
                        else showDevLog("✅ Excel Updated: " + p.name, false);
                    }).catch(e => showDevLog("Excel Net Err: " + e.message, true));
            } else {
                showDevLog("❌ DS_APP_SCRIPT_URL is missing!", true);
            }
        } else {
            showDevLog("❌ p or docId missing for " + (p ? p.name : "unknown"), true);
        }
    } catch (e) { console.error("Error saving product edit:", e); }
}

function setupEditableFields() {
    var priceBot = document.getElementById('dtPriceBot');
    var packBot = document.getElementById('dtPackBot');

    if (priceBot) {
        priceBot.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                priceBot.blur();
            }
        });
        priceBot.addEventListener('blur', function () {
            if (!curProduct) return;
            var val = parseFloat(priceBot.innerText.replace(/[^0-9.]/g, '').trim());
            if (!isNaN(val) && val >= 0) {
                curProduct.price = val;
                priceBot.innerText = val;
                saveProductEdit(curProduct);
                refreshCardUI(curProduct.id);
            } else {
                priceBot.innerText = curProduct.price || 0;
            }
        });
    }

    if (packBot) {
        packBot.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                packBot.blur();
            }
        });
        packBot.addEventListener('blur', function () {
            if (!curProduct) return;
            var val = packBot.innerText.trim();
            if (val !== "") {
                curProduct.packing = val;
                packBot.innerText = val;
                saveProductEdit(curProduct);
                refreshCardUI(curProduct.id);
            } else {
                packBot.innerText = curProduct.packing || "-";
            }
        });
    }
}

function updateBottomQtyFromActiveDesign() {
    if (!curProduct) return;

    var dKey = curProduct.id + '_DIRECT';
    var qty = cart[dKey] ? cart[dKey].qty : 0;

    var dtQtyInput = document.getElementById('dtQtyDirect');
    if (dtQtyInput) {
        dtQtyInput.value = qty;
    }

    var btnMinus = document.getElementById('dtQtyBotMinus');
    var btnPlus = document.getElementById('dtQtyBotPlus');

    if (btnMinus) {
        btnMinus.onclick = function () {
            changeQty(curProduct.id, 'DIRECT', -1);
        };
    }
    if (btnPlus) {
        btnPlus.onclick = function () {
            changeQty(curProduct.id, 'DIRECT', 1);
        };
    }
}

var backButtonPressedOnce = false;
var backButtonTimer = null;

function handleHardwareBack() {
    var hasActiveModal = false;

    var detailPanel = document.getElementById('detailPanel');
    var cartPanel = document.getElementById('cartPanel');
    var fsModal = document.getElementById('fsModal');

    if (fsModal && fsModal.style.display === 'flex') {
        hasActiveModal = true;
    } else if (cartPanel && cartPanel.classList.contains('open')) {
        hasActiveModal = true;
    } else if (detailPanel && detailPanel.classList.contains('open')) {
        hasActiveModal = true;
    } else {
        var actionModals = document.querySelectorAll('.action-modal');
        for (var i = 0; i < actionModals.length; i++) {
            if (actionModals[i].style.display === 'flex') {
                hasActiveModal = true;
                break;
            }
        }
    }

    if (hasActiveModal) {
        history.back(); // Step back to previous modal or home
    } else {
        // We are on the main home screen
        if (backButtonPressedOnce) {
            if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
                window.Capacitor.Plugins.App.minimizeApp();
            }
        } else {
            backButtonPressedOnce = true;

            // Show disappearing toast message
            var toastId = 'exitToast_' + Date.now();
            var toastHtml = `<div id="${toastId}" style="position:fixed; bottom:80px; left:50%; transform:translateX(-50%); background:rgba(40,40,40,0.95); color:#fff; padding:12px 24px; border-radius:30px; font-size:14px; box-shadow:0 4px 15px rgba(0,0,0,0.4); z-index:999999; text-align:center; transition: opacity 0.3s; pointer-events:none;">Press back again to exit</div>`;
            document.body.insertAdjacentHTML('beforeend', toastHtml);

            if (backButtonTimer) clearTimeout(backButtonTimer);
            backButtonTimer = setTimeout(() => {
                backButtonPressedOnce = false;
                var t = document.getElementById(toastId);
                if (t) {
                    t.style.opacity = '0';
                    setTimeout(() => t.remove(), 300);
                }
            }, 2000);
        }
    }
}

// 📱 Listen to hybrid app native backbutton event to prevent app minimization and handle stack back transition
if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
    window.Capacitor.Plugins.App.addListener('backButton', ({ canGoBack }) => {
        handleHardwareBack();
    });
} else {
    document.addEventListener("backbutton", function (e) {
        e.preventDefault();
        handleHardwareBack();
    }, false);
}

// ====================================
// 🔎 SEARCH, SORT, FILTER & FAVORITES ENGINE
// ====================================
var showOnlyFavs = false;

window.doSearch = function (val) {
    var srch = document.getElementById('srch');
    if (srch) srch.value = val;
    applyFilter();

    var detailPanel = document.getElementById('detailPanel');
    var gridWrapper = document.getElementById('gridWrapper');
    var slBody = detailPanel ? detailPanel.querySelector('.sl-body') : null;
    var dtSearchInput = document.getElementById('dtSearchInput');

    if (detailPanel && detailPanel.classList.contains('open') && dtSearchInput && dtSearchInput.style.display !== 'none' && val.trim() !== '') {
        if (slBody) slBody.style.display = 'none';
        if (gridWrapper.parentNode !== detailPanel) {
            detailPanel.insertBefore(gridWrapper, document.getElementById('detailBottomRow'));
            gridWrapper.style.flex = "1";
            gridWrapper.style.overflowY = "auto";
            gridWrapper.style.paddingBottom = "100px";
        }
    } else {
        if (slBody) slBody.style.display = 'block';
        if (gridWrapper && gridWrapper.parentNode !== document.getElementById('appBody')) {
            document.getElementById('appBody').appendChild(gridWrapper);
            gridWrapper.style.flex = "";
            gridWrapper.style.overflowY = "";
            gridWrapper.style.paddingBottom = "";
        }
    }
};

window.renderHorizontalCategories = function () {
    var stripEl = document.getElementById('horizontalCategoryStrip');
    if (!stripEl) return;

    var cats = {};
    allProducts.forEach(p => {
        if (p.cat) {
            if (!cats[p.cat]) {
                cats[p.cat] = p;
            } else if (!cats[p.cat].coverDesignId && p.coverDesignId) {
                cats[p.cat] = p; // Strongly prefer products with a custom cover image set
            } else if (!cats[p.cat].coverDesignId && !cats[p.cat].latestImageAddedAt && p.latestImageAddedAt) {
                cats[p.cat] = p; // Next best: prefer products that have *some* images uploaded
            }
        }
    });

    var sortedCats = Object.keys(cats).sort();
    var html = '';

    sortedCats.forEach(cat => {
        var activeClass = activeCategories.includes(cat) ? 'active' : '';
        var p = cats[cat];
        var imgId = 'cat-circle-img-' + encodeURIComponent(cat).replace(/[^a-zA-Z0-9]/g, '');

        html += `
        <div class="cat-circle-item ${activeClass}" onclick="toggleCategoryFilter(null, '${esc(cat)}')">
            <div class="cat-circle-img-wrap">
                <img id="${imgId}" crossorigin="anonymous" onload="if(window.autoCropImage) window.autoCropImage(this)" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" alt="${esc(cat)}">
            </div>
            <div class="cat-circle-label">${esc(cat)}</div>
        </div>`;

        // Schedule image render
        setTimeout(() => {
            var el = document.getElementById(imgId);
            if (el && window.renderWebpFromFolder) window.renderWebpFromFolder(el, p.gridUrl, null, p.coverDesignId ? p.coverDesignId.replace(/\.(webp|jpg|jpeg|png)$/i, '') + '.webp' : null);
        }, 10);
    });

    stripEl.innerHTML = html;
};

window.populateCategories = function () {
    var catListEl = document.getElementById('categoryList');
    if (!catListEl) return;

    var cats = {};
    allProducts.forEach(p => {
        if (p.cat) cats[p.cat] = true;
    });
    var sortedCats = Object.keys(cats).sort();

    var html = '';
    sortedCats.forEach(cat => {
        var activeClass = activeCategories.includes(cat) ? 'active' : '';
        html += `<div class="filter-row ${activeClass}" onclick="toggleCategoryFilter(this, '${esc(cat)}')">${esc(cat)}</div>`;
    });
    catListEl.innerHTML = html;
};

window.toggleCategoryFilter = function (element, cat) {
    cameFromDetail = false;
    var idx = activeCategories.indexOf(cat);

    if (!element) {
        // Top Round Icons: Single Selection Behavior
        if (idx === -1) {
            activeCategories = [cat];
        } else {
            if (activeCategories.length === 1) {
                activeCategories = [];
            } else {
                activeCategories = [cat];
            }
        }
        if (window.populateCategories) window.populateCategories();
    } else {
        // Bottom Filter UI: Multiple Selection Behavior
        if (idx === -1) {
            activeCategories.push(cat);
            if (element) element.classList.add('active');
        } else {
            activeCategories.splice(idx, 1);
            if (element) element.classList.remove('active');
        }
    }

    applyFilter();
    if (window.renderHorizontalCategories) window.renderHorizontalCategories();
};

window.clearCategoryFilter = function () {
    activeCategories = [];
    applyFilter();
    if (window.renderHorizontalCategories) window.renderHorizontalCategories();
    if (window.populateCategories) window.populateCategories();
};

window.togglePriceFilter = function (element, min, max) {
    cameFromDetail = false;
    var filterStr = min + '-' + max;
    var idx = activePriceFilters.indexOf(filterStr);
    if (idx === -1) {
        activePriceFilters.push(filterStr);
        if (element) element.classList.add('active');
    } else {
        activePriceFilters.splice(idx, 1);
        if (element) element.classList.remove('active');
    }
    applyFilter();
};

window.clearPriceFilters = function () {
    cameFromDetail = false;
    activePriceFilters = [];
    var modal = document.getElementById('filterModal');
    if (modal) {
        var rows = modal.querySelectorAll('.filter-row');
        rows.forEach(r => r.classList.remove('active'));
    }
    applyFilter();
};

window.closeEmptySearch = function () {
    var input = document.getElementById('srchMainInput');
    if (input && input.value.trim() === '' && input.style.display !== 'none') {
        setTimeout(function () {
            // Only pop the state if we are STILL in the search state
            // This prevents popping the 'detail' state if the user tapped a product
            if (history.state && history.state.modal === 'search') {
                history.back();
            }
        }, 150);
    }
};

window.toggleSearch = function () {
    var input = document.getElementById('srchMainInput');
    if (input) {
        if (input.style.display === 'none' || input.style.display === '') {
            pushHistoryState('search');
            applyModalState('search');
            input.focus();
        } else {
            history.back(); // This will trigger popstate which closes search
        }
    }
};

window.toggleDetailSearch = function () {
    var title = document.getElementById('dtNameTop');
    var input = document.getElementById('dtSearchInput');
    if (input.style.display === 'none') {
        title.style.display = 'none';
        input.style.display = 'block';
        input.focus();
    } else {
        input.style.display = 'none';
        title.style.display = 'block';
        input.value = '';
        doSearch('');
    }
};

window.toggleFavView = function () {
    cameFromDetail = false;
    showOnlyFavs = !showOnlyFavs;
    var favIcon = document.getElementById('favTopIcon');
    if (favIcon) {
        if (showOnlyFavs) {
            favIcon.classList.remove('far');
            favIcon.classList.add('fas');
            favIcon.style.color = 'var(--myntra-pink)';
        } else {
            favIcon.classList.remove('fas');
            favIcon.classList.add('far');
            favIcon.style.color = '';
        }
    }
    updateCartHeader();
    applyFilter();
};

window.setSort = function (type, element) {
    cameFromDetail = false;
    currentSort = type;

    var modal = document.getElementById('sortModal');
    if (modal) {
        var rows = modal.querySelectorAll('.filter-row');
        rows.forEach(r => r.classList.remove('active'));
    }
    if (element) {
        element.classList.add('active');
    }

    applyFilter();
    closeModals();
};

window.applyFilter = function () {
    var srch = document.getElementById('srch');
    var query = srch ? srch.value.trim().toLowerCase() : '';

    var filtered = allProducts.filter(p => {
        // 1. Search Query
        if (query !== "") {
            var nameMatch = p.name && p.name.toLowerCase().includes(query);
            var skuMatch = p.sku && p.sku.toLowerCase().includes(query);
            var fabricMatch = p.fabric && p.fabric.toLowerCase().includes(query);
            if (!nameMatch && !skuMatch && !fabricMatch) return false;
        }

        // 2. Category
        if (query === "" && activeCategories.length > 0) {
            if (!activeCategories.includes(p.cat)) return false;
        }

        // 3. Price
        if (query === "" && activePriceFilters.length > 0) {
            var matchPrice = false;
            activePriceFilters.forEach(f => {
                var parts = f.split('-');
                var min = parseFloat(parts[0]);
                var max = parseFloat(parts[1]);
                if (p.price >= min && p.price <= max) {
                    matchPrice = true;
                }
            });
            if (!matchPrice) return false;
        }

        // 4. Favorites
        if (query === "" && showOnlyFavs) {
            if (!favorites[p.id]) return false;
        }

        return true;
    });

    // 5. Sorting
    if (currentSort === 'priceAsc') {
        filtered.sort((a, b) => a.price - b.price);
    } else if (currentSort === 'priceDesc') {
        filtered.sort((a, b) => b.price - a.price);
    } else if (currentSort === 'new') {
        filtered.sort((a, b) => {
            var timeA = new Date(a.updateTime || 0).getTime();
            var timeB = new Date(b.updateTime || 0).getTime();
            return timeB - timeA;
        });
    }

    displayList = filtered;
    renderProductGrid(displayList);
};

// 📱 Listen to popstate to handle history back/forward navigation and close/open modals accordingly
function applyModalState(modal) {
    var detailPanel = document.getElementById('detailPanel');
    var cartPanel = document.getElementById('cartPanel');
    var fsModal = document.getElementById('fsModal');
    var actionModals = document.querySelectorAll('.action-modal');

    // 1. Sync Full Screen Modal
    if (modal === 'fs') {
        if (fsModal) fsModal.style.display = 'flex';
    } else {
        if (fsModal) {
            fsModal.style.display = 'none';
            var fsVideo = document.getElementById('fsVideo');
            if (fsVideo) {
                fsVideo.pause();
            }
        }
    }

    // 2. Sync Detail Panel
    if (modal === 'detail' || modal === 'fs') {
        if (detailPanel && !detailPanel.classList.contains('open')) {
            detailPanel.classList.add('open');
        }
    } else {
        if (detailPanel && detailPanel.classList.contains('open')) {
            if (typeof closeDetail === 'function') closeDetail(true);
        }
    }

    // 3. Sync Cart Panel
    if (modal === 'cart') {
        if (cartPanel && !cartPanel.classList.contains('open')) {
            cartPanel.classList.add('open');
        } else if (cartPanel && cartPanel.classList.contains('open')) {
            // Returning to an already open cart via hardware back button (popstate).
            // Redraw cart live to catch newly added/removed swipe designs!
            var isEditingAny = false;
            if (window.cartEditingMap) {
                for (var ed in window.cartEditingMap) {
                    if (window.cartEditingMap[ed]) isEditingAny = true;
                }
            }
            if (!isEditingAny && typeof openCart === 'function') openCart(true);
        }
    } else {
        if (cartPanel) {
            cartPanel.classList.remove('open');
        }
    }

    // 4. Sync Search
    var input = document.getElementById('srchMainInput');
    var logo = document.getElementById('appLogoImg');
    if (modal === 'search') {
        if (input && input.style.display !== 'block') {
            if (logo) logo.style.display = 'none';
            input.style.display = 'block';
        }
    } else {
        if (input && input.style.display === 'block') {
            input.style.display = 'none';
            if (logo) logo.style.display = 'block';
            input.value = '';
            doSearch('');
        }
    }

    // 5. Sync Action Modals (categoryModal, sortModal, filterModal, shareModal, waModal)
    actionModals.forEach(function (m) {
        if (m.id === modal) {
            m.style.display = 'flex';
        } else {
            m.style.display = 'none';
        }
    });
}

window.addEventListener('popstate', function (e) {
    var state = e.state || {};

    // Auto-close empty search when returning from another view
    if (state.modal === 'search') {
        var input = document.getElementById('srchMainInput');
        if (input && input.value.trim() === '') {
            history.back();
            return;
        }
    }

    applyModalState(state.modal);
    updateAndroidBackState();
});

function updateAndroidBackState() {
    try {
        var detailPanel = document.getElementById('detailPanel');
        var cartPanel = document.getElementById('cartPanel');
        var fsModal = document.getElementById('fsModal');

        var hasOpenModal = false;

        if (detailPanel && detailPanel.classList.contains('open')) {
            hasOpenModal = true;
        } else if (cartPanel && cartPanel.classList.contains('open')) {
            hasOpenModal = true;
        } else if (fsModal && fsModal.style.display === 'flex') {
            hasOpenModal = true;
        } else {
            var actionModals = document.querySelectorAll('.action-modal');
            for (var i = 0; i < actionModals.length; i++) {
                if (actionModals[i].style.display === 'flex') {
                    hasOpenModal = true;
                    break;
                }
            }
        }

        var input = document.getElementById('srchMainInput');
        if (input && input.style.display === 'block') {
            hasOpenModal = true;
        }

        if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AndroidBackBridge) {
            window.Capacitor.Plugins.AndroidBackBridge.setCanGoBack({ canGoBack: hasOpenModal });
        }
    } catch (e) {
        console.error("Error updating Android bridge back state:", e);
    }
}

// Sync back state on initial script load
updateAndroidBackState();

function toggleHdrMenu(event) {
    if (event) event.stopPropagation();
    var menu = document.getElementById('hdrMenu');
    if (menu) {
        menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
    }
}

['click', 'touchstart'].forEach(evt =>
    document.addEventListener(evt, function (e) {
        var menu = document.getElementById('hdrMenu');
        if (menu && menu.style.display === 'block') {
            if (!menu.contains(e.target) && (!e.target.closest || !e.target.closest('.fa-ellipsis-v'))) {
                menu.style.display = 'none';
            }
        }
    })
);

async function logout() {
    if (typeof toggleHdrMenu === 'function') toggleHdrMenu();
    if (!confirm('Are you sure you want to logout?')) return;
    try {
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            if (window.CapacitorFirebaseAuthentication) {
                await window.CapacitorFirebaseAuthentication.signOut();
            }
        } else {
            if (typeof firebase !== 'undefined') {
                await firebase.auth().signOut();
            }
        }
        localStorage.removeItem('dsUserToken');
        document.getElementById("appBody").style.display = "none";
        document.getElementById("loginScreen").style.display = "flex";
        document.getElementById("loginBoxPhone").style.display = "block";
        document.getElementById("loginBoxOtp").style.display = "none";
        document.getElementById("lPhone").value = "";
    } catch (err) {
        console.error("Logout failed", err);
        alert("Logout failed: " + err.message);
    }
}

// ====================================
// 📦 CART CUSTOMER DETAILS & EDIT MODALS
// ====================================

var _currentEditProductId = null;

async function fetchCustomerDetailsFromDB() {
    if (!activeUser) return null;
    try {
        var token = "";
        if (typeof firebase !== 'undefined' && firebase.auth && firebase.auth().currentUser) {
            token = await firebase.auth().currentUser.getIdToken();
        }
        var headers = {};
        if (token) headers['Authorization'] = 'Bearer ' + token;

        var query = {
            structuredQuery: {
                from: [{ collectionId: "Users" }],
                where: {
                    fieldFilter: {
                        field: { fieldPath: "phone" },
                        op: "EQUAL",
                        value: { stringValue: activeUser }
                    }
                },
                limit: 1
            }
        };
        var res = await fetch("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents:runQuery", {
            method: "POST",
            headers: headers,
            body: JSON.stringify(query)
        });
        var data = await res.json();
        if (data && data.length > 0 && data[0].document) {
            var f = data[0].document.fields;
            var d = {
                name: f.name ? f.name.stringValue : "",
                firm: f.firm ? f.firm.stringValue : "",
                station: f.station ? f.station.stringValue : "",
                state: f.state ? f.state.stringValue : "",
                phone: f.phone ? f.phone.stringValue : "",
                docId: data[0].document.name.split('/').pop()
            };
            localStorage.setItem("dsCustomerDetails", JSON.stringify(d));
            return d;
        }
    } catch (e) { console.error(e); }
    return null;
}

function loadCartCustomerDetails() {
    var detailsBody = document.getElementById('cartCustomerDetailsBody');
    if (!detailsBody) return;

    var stored = localStorage.getItem("dsCustomerDetails");
    if (stored) {
        try {
            var d = JSON.parse(stored);
            renderCustomerDetails(d, detailsBody);
        } catch (e) { }
    } else {
        detailsBody.innerText = "Fetching details...";
        fetchCustomerDetailsFromDB().then(d => {
            if (d) {
                renderCustomerDetails(d, detailsBody);
            } else {
                detailsBody.innerHTML = "<i>No details found. Please edit.</i>";
            }
        });
    }
}

function renderCustomerDetails(d, container) {
    if (!container) return;
    var primaryName = d.firm ? d.firm : d.name;
    var html = esc(primaryName) + (d.station ? ", " + esc(d.station) : "");
    container.innerHTML = html;
}

async function openCustomerDetailsModal() {
    var d = null;
    var stored = localStorage.getItem("dsCustomerDetails");
    if (stored) {
        try { d = JSON.parse(stored); } catch (e) { }
    }
    if (!d) {
        d = await fetchCustomerDetailsFromDB();
    }

    document.getElementById('cdName').value = d ? d.name : "";
    document.getElementById('cdFirm').value = d ? d.firm : "";
    document.getElementById('cdPhone').value = (d && d.phone) ? d.phone : (activeUser || "");
    document.getElementById('cdStation').value = d ? d.station : "";
    document.getElementById('cdState').value = d ? d.state : "";
    document.getElementById('cdErr').innerText = "";

    openModal('customerDetailsModal');
}

async function saveCustomerDetails() {
    var btn = document.getElementById('btnSaveCustomerDetails');
    var err = document.getElementById('cdErr');
    var name = document.getElementById('cdName').value.trim();
    var firm = document.getElementById('cdFirm').value.trim();
    var phone = document.getElementById('cdPhone').value.trim() || activeUser;
    var station = document.getElementById('cdStation').value.trim();
    var state = document.getElementById('cdState').value.trim();

    if (!name || !station || !state) {
        err.innerText = "Please fill all required fields.";
        return;
    }

    btn.innerText = "Saving...";
    var d = { name: name, firm: firm, phone: phone, station: station, state: state };
    var stored = localStorage.getItem("dsCustomerDetails");
    var docId = null;
    if (stored) {
        try { docId = JSON.parse(stored).docId; } catch (e) { }
    }
    if (docId) d.docId = docId;

    // Save locally immediately for fast UI
    localStorage.setItem("dsCustomerDetails", JSON.stringify(d));
    loadCartCustomerDetails();

    // Save to Firestore
    try {
        var doc = {
            fields: {
                name: { stringValue: name },
                firm: { stringValue: firm },
                station: { stringValue: station },
                state: { stringValue: state },
                phone: { stringValue: phone }
            }
        };

        if (docId) {
            // Update existing
            await window.fetchWithRetry("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Users/" + docId + "?updateMask.fieldPaths=name&updateMask.fieldPaths=firm&updateMask.fieldPaths=station&updateMask.fieldPaths=state&updateMask.fieldPaths=phone", {
                method: "PATCH",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(doc)
            });
        } else {
            // Create new
            doc.fields.createdAt = { timestampValue: new Date().toISOString() };
            var res = await window.fetchWithRetry("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Users", {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(doc)
            });
            var data = await res.json();
            if (data.name) {
                d.docId = data.name.split('/').pop();
                localStorage.setItem("dsCustomerDetails", JSON.stringify(d));
            }
        }
    } catch (e) { console.error("Firestore save err", e); }

    btn.innerText = "SAVE DETAILS";
    closeModals();
}

function toggleCartInlineEdit(productId) {
    window.cartEditingMap = window.cartEditingMap || {};
    window.cartEditingMap[productId] = true;
    openCart(); // Re-render to show input fields
}

function saveCartInlineEdit(productId, closeEdit = true) {
    var rateInput = document.getElementById('ie_rate_' + productId);
    var packInput = document.getElementById('ie_pack_' + productId);

    var newRate = rateInput ? parseInt(rateInput.value) || 0 : 0;
    var newPacking = packInput ? packInput.value.trim() || "1" : "1";

    var items = [];
    for (var k in cart) {
        if (cart[k].p && cart[k].p.id === productId) {
            items.push(cart[k]);
        }
    }

    var productName = items.length > 0 ? items[0].p.name : "";

    items.forEach(item => {
        var safeDesignLabel = item.design || 'DIRECT';
        var qtyInput = document.getElementById('ie_qty_' + productId + '_' + safeDesignLabel);
        if (qtyInput) {
            var newQty = parseInt(qtyInput.value) || 0;
            if (newQty <= 0) {
                delete cart[productId + "_" + item.design];
            } else {
                item.qty = newQty;
                // Clone the product object if admin mode is OFF to prevent mutating the global catalog
                if (!(window.isSuperAdmin && window.isAdminMode)) {
                    item.p = Object.assign({}, item.p);
                }
                item.p.price = newRate;
                item.p.packing = newPacking;
                cart[productId + "_" + item.design] = item;
            }
        }
    });

    if (window.isSuperAdmin && window.isAdminMode) {
        // Save to edited memory so changes persist across cart wipes
        if (items.length > 0) {
            var edited = {};
            try { edited = JSON.parse(localStorage.getItem("dsEditedProducts")) || {}; } catch (e) { }
            edited[items[0].p.name] = { price: newRate, packing: newPacking };
            localStorage.setItem("dsEditedProducts", JSON.stringify(edited));
        }
    }

    var matchP = allProducts.find(x => x.id === productId);
    if (window.isSuperAdmin && window.isAdminMode) {
        if (matchP) {
            matchP.price = newRate;
            matchP.packing = newPacking;
        }
    }

    localStorage.setItem("dsCart", JSON.stringify(cart));

    if (closeEdit) window.cartEditingMap[productId] = false;
    updateCartHeader();
    openCart(); // Re-render to show updated static text

    // 🚀 NEW: 2-WAY SYNC - FIREBASE & EXCEL WEBHOOK
    if (window.isSuperAdmin && window.isAdminMode && matchP && matchP.docId) {
        showDevLog("Syncing: " + matchP.name + " -> Rate: " + newRate + " Pack: " + newPacking, false);
        // Firebase Live DB Update - Decoupled to support Granular RBAC
        var fbUpdateUrlPrice = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + matchP.docId + "?updateMask.fieldPaths=price";
        window.fetchWithRetry(fbUpdateUrlPrice, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fields: { price: { doubleValue: Number(newRate) } } })
        }, 1).then(res => {
            if (res.ok) showDevLog("✅ Firebase Price Updated", false);
            else showDevLog("❌ FB Err " + res.status, true);
        }).catch(err => showDevLog("FB Net Err: " + err.message, true));

        var fbUpdateUrlPacking = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + matchP.docId + "?updateMask.fieldPaths=packing";
        window.fetchWithRetry(fbUpdateUrlPacking, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fields: { packing: { stringValue: newPacking } } })
        }, 1).then(res => {
            if (res.ok) showDevLog("✅ Firebase Packing Updated", false);
            else showDevLog("❌ FB Err " + res.status, true);
        }).catch(err => showDevLog("FB Net Err: " + err.message, true));

        // Excel Webhook Sync via Apps Script
        if (window.DS_APP_SCRIPT_URL) {
            fetch(window.DS_APP_SCRIPT_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify({
                    action: 'updateProductDetails',
                    productName: matchP.name,
                    price: newRate,
                    packing: newPacking
                })
            }).then(r => r.json())
                .then(data => {
                    if (!data.success) showDevLog("❌ Excel Err: " + data.msg, true);
                    else showDevLog("✅ Excel Updated: " + matchP.name, false);
                })
                .catch(e => showDevLog("Excel Net Err: " + e.message, true));
        } else {
            showDevLog("❌ DS_APP_SCRIPT_URL is missing!", true);
        }
    } else {
        showDevLog("❌ matchP or docId missing for " + productId, true);
    }
}

window.deleteCartProduct = function (productId) {
    var deletedAny = false;
    for (var k in cart) {
        if (cart[k].p && cart[k].p.id === productId) {
            delete cart[k];
            deletedAny = true;
        }
    }
    if (deletedAny) {
        var p = allProducts.find(x => x.id === productId);
        if (p) manageProductHDCache(p, 'DELETE');

        if (window.cartEditingMap) delete window.cartEditingMap[productId];
        updateCartHeader();
        localStorage.setItem("dsCart", JSON.stringify(cart));
        openCart();
    }
};

function printCartPdf() {
    var keys = Object.keys(cart);
    if (keys.length === 0) return alert("Your cart is empty!");
    if (typeof generateCartOrderPDF === 'function') {
        generateCartOrderPDF('print');
    } else {
        alert("PDF Engine not loaded!");
    }
}

// ====================================
// 📊 SYNC REPORT LOGIC
// ====================================

function openSyncReportModal() {
    closeModals();
    openModal('syncReportModal');
    window.showGlobalErrorLogs();
}

window.syncReportResults = [];

async function runSyncReport() {
    var btn = document.getElementById('btnRunSyncReport');
    var status = document.getElementById('syncReportStatus');
    var bar = document.getElementById('syncReportBar');
    var progress = document.getElementById('syncReportProgress');

    btn.disabled = true;
    progress.style.display = 'block';
    bar.style.width = '0%';
    window.syncReportResults = [];

    var productsToScan = window.allProducts.filter(p => {
        var isWix = JSON.stringify(p).toLowerCase().includes("wix import");
        return p.name && p.name.toLowerCase() !== "temp" && p.name.toLowerCase() !== "unnamed" && !isWix;
    });
    var total = productsToScan.length;

    if (total === 0) {
        status.innerText = "No products found to scan.";
        btn.disabled = false;
        return;
    }

    var bucket = "durga-sarees.firebasestorage.app";
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o?prefix=";

    for (var i = 0; i < total; i++) {
        var p = productsToScan[i];
        bar.style.width = ((i / total) * 100) + '%';
        status.innerText = "Scanning " + (i + 1) + " of " + total + ": " + p.name;

        var result = {
            id: p.id,
            name: p.name,
            sku: p.sku || '-',
            error: null,
            imageCount: 0,
            status: 'completed'
        };

        if (!p.gridUrl || String(p.gridUrl).trim() === "" || String(p.gridUrl).toLowerCase() === "none") {
            result.error = "No Grid Folder assigned";
            result.status = 'error';
            window.syncReportResults.push(result);
            renderSyncReportPartial();
            continue;
        }

        var cleanGridPath = String(p.gridUrl).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('/') + '/';

        var listUrl = fbBase + cleanGridPath + "&delimiter=/";

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);
            // 🛡️ Bulletproof Retry applied to Sync Report
            var res = await window.fetchWithRetry(listUrl, { signal: controller.signal }, 3);
            clearTimeout(timeoutId);

            if (!res.ok) {
                result.error = "HTTP Error " + res.status;
                result.status = 'error';
            } else {
                var data = await res.json();
                var items = data.items || [];
                var imgCount = items.filter(it => /\.(webp|jpg|jpeg|png)$/i.test(it.name)).length;
                result.imageCount = imgCount;
                if (imgCount === 0) {
                    result.error = "Empty folder / No images found";
                    result.status = 'error';
                }
            }
        } catch (e) {
            result.error = "Failed: " + (e.name === 'AbortError' ? 'Connection Timeout (15s)' : e.message);
            result.status = 'error';
        }

        // Ensure grid image is in memory
        try {
            var isGridInMemory = await getImageFromDB(p.gridUrl);
            if (!isGridInMemory) {
                if (result.status !== 'error') {
                    result.error = "Grid missing from memory";
                    result.status = 'error';
                } else {
                    result.error += " | Grid missing";
                }
            }
        } catch (e) { }

        window.syncReportResults.push(result);
        renderSyncReportPartial();
    }

    bar.style.width = '100%';
    var errCount = window.syncReportResults.filter(r => r.status === 'error').length;
    status.innerText = "Scan complete! Found " + errCount + " errors.";
    btn.disabled = false;
    var btnResync = document.getElementById('btnResyncErrors');
    if (btnResync) btnResync.style.display = errCount > 0 ? 'inline-block' : 'none';
}

function renderSyncReportPartial() {
    var chkElement = document.getElementById('chkShowCompletedSync');
    var showCompleted = chkElement ? chkElement.checked : false;
    var container = document.getElementById('syncReportBody');

    var html = '';
    var errorCount = 0;

    // Category Wise Tally
    var catTotals = {};
    for (var i = 0; i < window.syncReportResults.length; i++) {
        var r = window.syncReportResults[i];
        if (r.status === 'error') errorCount++;

        var pMatch = window.allProducts.find(p => p.id === r.id);
        var cat = (pMatch && pMatch.cat) ? pMatch.cat : 'Uncategorized';
        if (!catTotals[cat]) catTotals[cat] = { total: 0, error: 0, ok: 0, images: 0 };
        catTotals[cat].total++;
        if (r.status === 'error') catTotals[cat].error++;
        else {
            catTotals[cat].ok++;
            catTotals[cat].images += (r.imageCount || 0);
        }
    }

    var summaryHtml = '<div style="margin-bottom:15px; padding:10px; background:#e3f2fd; border:1px solid #bbdefb; border-radius:6px;">';
    summaryHtml += '<div style="font-weight:bold; color:#1565c0; margin-bottom:8px; font-size:14px;">Category Wise Tally</div>';
    for (var c in catTotals) {
        summaryHtml += `<div style="font-size:12px; color:#0d47a1; display:flex; justify-content:space-between; margin-bottom:4px; padding-bottom:4px; border-bottom:1px dashed #bbdefb;">
            <span><b>${c}</b></span>
            <span>Total: ${catTotals[c].total} | OK: ${catTotals[c].ok} | Err: ${catTotals[c].error} | Imgs: ${catTotals[c].images}</span>
        </div>`;
    }
    summaryHtml += '</div>';
    html += summaryHtml;

    for (var i = 0; i < window.syncReportResults.length; i++) {
        var r = window.syncReportResults[i];

        if (r.status === 'completed' && !showCompleted) continue;

        var bg = r.status === 'error' ? '#fff3f3' : '#f5fbf5';
        var border = r.status === 'error' ? '#ffcdd2' : '#c8e6c9';
        var iconColor = r.status === 'error' ? '#e53935' : '#4caf50';
        var iconCls = r.status === 'error' ? 'fa-exclamation-triangle' : 'fa-check-circle';

        html += `
        <div style="background:${bg}; border:1px solid ${border}; border-radius:6px; padding:10px; display:flex; align-items:flex-start; gap:10px;">
            <i class="fas ${iconCls}" style="color:${iconColor}; margin-top:2px;"></i>
            <div style="flex:1;">
                <div style="font-weight:bold; font-size:13px; color:var(--text-main);">${r.name}</div>
                <div style="font-size:11px; color:var(--text-light); margin-bottom:4px;">SKU: ${r.sku}</div>
                ${r.status === 'error' ? `<div style="font-size:12px; color:#c62828; font-weight:bold;">Error: ${r.error}</div>` : `<div style="font-size:12px; color:#2e7d32;">Found ${r.imageCount} images</div>`}
            </div>
        </div>
        `;
    }

    if (html === '' && window.syncReportResults.length > 0) {
        html = '<div style="text-align:center; padding:20px; color:var(--text-light); font-size:13px;">No errors to show!</div>';
    }

    container.innerHTML = html;
}

window.filterSyncReport = renderSyncReportPartial;

// ====================================
// RESYNC FAILED PRODUCTS LOGIC
// ====================================
async function resyncFailedProducts() {
    var errProducts = window.syncReportResults.filter(r => r.status === 'error');
    if (errProducts.length === 0) return;

    var btn = document.getElementById('btnRunSyncReport');
    var btnResync = document.getElementById('btnResyncErrors');
    var status = document.getElementById('syncReportStatus');
    var bar = document.getElementById('syncReportBar');
    var progress = document.getElementById('syncReportProgress');

    btn.disabled = true;
    btnResync.disabled = true;
    progress.style.display = 'block';
    bar.style.width = '0%';

    var bucket = "durga-sarees.firebasestorage.app";
    var fbBase = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o/";

    for (var i = 0; i < errProducts.length; i++) {
        var result = errProducts[i];
        bar.style.width = ((i / errProducts.length) * 100) + '%';
        status.innerText = "Resyncing " + (i + 1) + " of " + errProducts.length + ": " + result.name;

        var p = window.allProducts.find(x => x.id === result.id);
        if (!p || !p.gridUrl || p.gridUrl === "None") {
            result.error = "Detailed: Product deleted or has no Grid Folder.";
            continue;
        }

        var cleanGridPath = String(p.gridUrl).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            // 1. Fetch directory listing first
            var prefix = cleanGridPath + "/";
            var listUrl = "https://firebasestorage.googleapis.com/v0/b/" + bucket + "/o?prefix=" + prefix + "&delimiter=/";
            // 🛡️ Bulletproof Retry applied to Resync
            var listRes = await window.fetchWithRetry(listUrl, { signal: controller.signal }, 3);

            if (!listRes.ok) {
                clearTimeout(timeoutId);
                result.error = "Detailed: List HTTP " + listRes.status + " (" + listRes.statusText + ")";
                continue;
            }

            var listData = await listRes.json();
            var folderFiles = (listData.items || [])
                .map(item => item.name.substring(item.name.lastIndexOf('/') + 1))
                .filter(f => /\.(webp|jpg|jpeg|png)$/i.test(f));

            if (folderFiles.length === 0) {
                clearTimeout(timeoutId);
                result.error = "Detailed: No images found in Grid folder.";
                continue;
            }

            folderFiles.sort((a, b) => (parseInt(a.replace(/\D/g, '')) || 999) - (parseInt(b.replace(/\D/g, '')) || 999));
            var coverFile = folderFiles[0];
            var gridImgUrl = fbBase + cleanGridPath + "%2F" + encodeURIComponent(coverFile) + "?alt=media";

            // 2. Fetch the actual cover image
            var res = await window.fetchWithRetry(gridImgUrl, { signal: controller.signal }, 3);
            clearTimeout(timeoutId);

            if (res.ok) {
                var blob = await res.blob();
                await saveImageToDB(gridImgUrl, blob);
                await saveImageToDB(p.gridUrl, blob); // ðŸ›¡ï¸ CRITICAL: Save using folder path key!

                // Update local cache mappings
                window.coverExistsMap = window.coverExistsMap || {};
                window.coverExistsMap[p.gridUrl] = true;
                saveCoverExistsMap();

                result.status = 'completed';
                result.error = "Resynced successfully (" + coverFile + ").";
                result.imageCount = 1;
            } else {
                result.error = "Detailed: HTTP " + res.status + " (" + res.statusText + ") for " + coverFile;
            }
        } catch (e) {
            result.error = "Detailed: " + (e.name === 'AbortError' ? 'Connection Timeout' : e.message);
        }

        renderSyncReportPartial();

        // Small delay to prevent connection overload
        await new Promise(resolve => setTimeout(resolve, 300));
    }

    bar.style.width = '100%';
    var remainingErrCount = window.syncReportResults.filter(r => r.status === 'error').length;
    status.innerText = "Resync complete! " + remainingErrCount + " still failed.";
    btn.disabled = false;
    btnResync.disabled = false;
    if (remainingErrCount === 0) btnResync.style.display = 'none';
}


window.updateAdminStock = async function (element, docId, pid, dId, overrideVal = null) {
    if (element) element.style.backgroundColor = '#fff9c4'; // Yellow (Saving)
    try {
        var newVal = overrideVal !== null ? overrideVal : (parseInt(element.value) || 0);

        var url = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + docId + "?updateMask.fieldPaths=stock.%60" + dId + "%60";
        var payload = {
            fields: {
                stock: {
                    mapValue: {
                        fields: {
                            [dId]: { integerValue: newVal }
                        }
                    }
                }
            }
        };

        // --- AUTO-HEALING: ORPHAN OVERRIDES ---
        var autoHealPackedValue = null;
        if (dId !== 'FULLY_PACKED') {
            if (newVal > 0) {
                autoHealPackedValue = 0;
            } else if (newVal === 0) {
                var p = allProducts.find(x => x.id === pid);
                if (p && p.stock) {
                    var otherKeys = Object.keys(p.stock).filter(k => k !== 'FULLY_PACKED' && k !== dId);
                    var sum = otherKeys.reduce((a, k) => a + p.stock[k], 0);
                    if (sum === 0) {
                        autoHealPackedValue = 1;
                    }
                }
            }
        }

        if (autoHealPackedValue !== null) {
            url += "&updateMask.fieldPaths=stock.%60FULLY_PACKED%60";
            payload.fields.stock.mapValue.fields['FULLY_PACKED'] = { integerValue: autoHealPackedValue };
        }

        var res = await window.fetchWithRetry(url, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }, 1);

        if (res.ok) {
            if (element) element.style.backgroundColor = '#c8e6c9'; // Green (Success)
            var p = allProducts.find(x => x.id === pid);
            if (p) {
                if (!p.stock) p.stock = {};
                p.stock[dId] = newVal;
                if (autoHealPackedValue !== null) {
                    p.stock['FULLY_PACKED'] = autoHealPackedValue;
                }

                if (p.stock['FULLY_PACKED'] === 1) {
                    p.totalStock = 0;
                } else {
                    var allDesignKeys = Object.keys(p.stock).filter(k => k !== 'FULLY_PACKED');
                    if (allDesignKeys.length > 0) {
                        var designSum = allDesignKeys.reduce((a, k) => a + p.stock[k], 0);
                        p.totalStock = designSum > 0 ? designSum : 0;
                    } else {
                        p.totalStock = 999;
                    }
                }

                // Immediately refresh the main page card UI
                if (typeof refreshCardUI === 'function') {
                    refreshCardUI(pid);
                }
            }
            if (element) {
                setTimeout(() => { element.style.backgroundColor = ''; }, 1000);
            }
        } else {
            if (element) element.style.backgroundColor = '#ffcdd2'; // Red (Fail)
            if (typeof window.logAppError === 'function') window.logAppError('updateAdminStock', 'HTTP ' + res.status);
        }
    } catch (e) {
        if (element) element.style.backgroundColor = '#ffcdd2'; // Red (Fail)
        if (typeof window.logAppError === 'function') window.logAppError('updateAdminStock', e.message);
    }
};


window.toggleAllBulkCheckboxes = function (checked) {
    var boxes = document.querySelectorAll('.admin-bulk-check');
    boxes.forEach(box => box.checked = checked);
};

window.applyBulkAdminStock = async function () {
    var qtyInput = document.getElementById('adminBulkQtyInput');
    var boxes = document.querySelectorAll('.admin-bulk-check:checked');
    if (boxes.length === 0) { alert('No designs selected.'); return; }
    if (!qtyInput || qtyInput.value === '') { alert('Please enter a quantity.'); return; }

    var btn = event.currentTarget;
    btn.disabled = true;
    btn.innerText = 'UPDATING...';

    var allBoxes = document.querySelectorAll('.admin-bulk-check');
    var isPackingAll = (boxes.length === allBoxes.length && qtyInput.value === '0');

    // Process sequentially to avoid 409 Contention error
    for (var i = 0; i < boxes.length; i++) {
        var box = boxes[i];
        var did = box.getAttribute('data-did');
        var pid = box.getAttribute('data-pid');
        var docid = box.getAttribute('data-docid');

        // Find the input element associated with this design to pass to updateAdminStock
        // The input is right next to it in the DOM
        var stockInput = box.closest('.swipe-card').querySelector('.admin-stock-input');
        if (stockInput) {
            stockInput.value = qtyInput.value;
            // Await the update to prevent overloading firestore
            await window.updateAdminStock(stockInput, docid, pid, did);
        }
    }

    if (isPackingAll && boxes.length > 0) {
        var docid = boxes[0].getAttribute('data-docid');
        var pid = boxes[0].getAttribute('data-pid');
        await window.updateAdminStock(null, docid, pid, 'FULLY_PACKED', 1);
    } else if (boxes.length > 0) {
        var docid = boxes[0].getAttribute('data-docid');
        var pid = boxes[0].getAttribute('data-pid');
        await window.updateAdminStock(null, docid, pid, 'FULLY_PACKED', 0);
    }

    btn.disabled = false;
    btn.innerText = 'APPLY';
    // Uncheck all after applying
    document.getElementById('adminBulkCheckAll').checked = false;
    window.toggleAllBulkCheckboxes(false);
    qtyInput.value = '';
};

window.showGlobalErrorLogs = function () {
    var container = document.getElementById('syncReportBody');
    if (!container) return;

    var logs = window.globalErrorLog || [];

    if (logs.length === 0) {
        container.innerHTML = '<div style="padding:15px; color:#2e7d32; font-weight:bold; text-align:center; background:#e8f5e9; border-radius:6px;">✅ No anomalies detected. System is clean.</div>';
        return;
    }

    var html = '<div style="margin-bottom:10px; font-weight:bold; color:#d32f2f;">System Error Logs (Latest First)</div>';
    html += '<div style="margin-bottom:15px; display:flex; gap:10px;">';
    html += '<button onclick="window.globalErrorLog=[]; localStorage.setItem(\'dsGlobalErrors\',\'[]\'); window.showGlobalErrorLogs();" style="flex:1; background:#e53935; color:white; border:none; padding:8px 12px; border-radius:4px; cursor:pointer;">Clear Logs</button>';
    html += '<button onclick="if(typeof resyncFailedProducts === \'function\') { resyncFailedProducts(); } else { alert(\'Sync report not available.\'); }" style="flex:2; background:#1976d2; color:white; border:none; padding:8px 12px; border-radius:4px; cursor:pointer;">Log Resync Only</button>';
    html += '</div>';

    // Reverse loop to show the newest errors at the top
    for (var i = logs.length - 1; i >= 0; i--) {
        var log = logs[i];
        var dateStr = new Date(log.ts || new Date()).toLocaleTimeString();
        html += '<div style="margin-bottom:8px; padding:10px; border-radius:6px; background:#ffebee; border:1px solid #ffcdd2; font-size:12px; text-align:left;">';
        html += '<div style="color:#b71c1c; font-weight:bold; margin-bottom:4px; border-bottom:1px dashed #ef9a9a; padding-bottom:4px;">' + (log.src || 'AUDITOR') + ' <span style="float:right; color:#757575; font-weight:normal;">' + dateStr + '</span></div>';
        html += '<div style="color:#333; word-wrap:break-word;">' + (log.msg || log.message || JSON.stringify(log)) + '</div>';
        html += '</div>';
    }

    container.innerHTML = html;
};

// --- OUTBOX SYSTEM ---
window.saveToOutbox = function (docId, designId, fileUri, productName, bypass = false) {
    return getDB().then(db => {
        return new Promise((resolve) => {
            var tx = db.transaction("outbox", "readwrite");
            var req = tx.objectStore("outbox").put({ docId, designId, fileUri, productName, bypass, ts: Date.now(), processAfter: Date.now() + 5000 });
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => resolve(null);
        });
    });
};

window.getOutboxItems = function () {
    return getDB().then(db => {
        return new Promise((resolve) => {
            var tx = db.transaction("outbox", "readonly");
            var req = tx.objectStore("outbox").getAll();
            req.onsuccess = () => resolve(req.result || []);
        });
    });
};

window.deleteFromOutbox = function (keyId) {
    return getDB().then(db => {
        return new Promise((resolve) => {
            var tx = db.transaction("outbox", "readwrite");
            tx.objectStore("outbox").delete(keyId);
            tx.oncomplete = () => resolve(true);
        });
    });
};

window.tempCamDocId = null;
window.tempCamPhotoPath = null;
window.tempCamPid = null;

window.triggerAdminCamera = async function (docId, pid, productName = "Product Preview") {
    var defaultDesignId = "02";
    if (window.lastRenderedDesignNames) {
        var names = window.lastRenderedDesignNames.split(',');
        var maxNum = 1;
        names.forEach(n => {
            if (/^\d{1,4}$/.test(n)) {
                var num = parseInt(n, 10);
                if (num > maxNum) maxNum = num;
            }
        });
        defaultDesignId = (maxNum + 1).toString().padStart(2, '0');
    }

    try {
        // High Quality Native Camera or Gallery Selection
        // High Quality Native Camera or Gallery Selection
        var photo = await Capacitor.Plugins.Camera.getPhoto({
            quality: 100,
            allowEditing: false,
            resultType: 'uri',
            source: 'PROMPT',
            width: 2500, // Explicitly request high resolution
            preserveAspectRatio: true
        });

        window.tempCamDocId = docId;
        window.tempCamPid = pid;
        window.tempCamPhotoPath = photo.path || photo.webPath;

        var modal = document.getElementById('adminCameraPreviewModal');
        var previewImg = document.getElementById('adminPreviewImg');
        var designInput = document.getElementById('adminDesignNumberInput');
        var nameLabel = document.getElementById('adminPreviewProductName');

        if (previewImg) previewImg.src = photo.webPath;
        if (designInput) designInput.value = defaultDesignId;

        // Grab product name dynamically if not passed cleanly
        var detailTitle = document.getElementById('detailTitle');
        if (nameLabel) {
            nameLabel.value = (detailTitle && detailTitle.innerText) ? detailTitle.innerText : productName;
        }

        if (modal) modal.style.display = 'flex';

    } catch (e) {
        window.logAppError('Camera Trigger', e.message);
    }
};

window.retakeAdminPhoto = function () {
    var modal = document.getElementById('adminCameraPreviewModal');
    if (modal) modal.style.display = 'none';
    window.triggerAdminCamera(window.tempCamDocId, window.tempCamPid);
};

window.confirmAdminUpload = async function () {
    var modal = document.getElementById('adminCameraPreviewModal');
    var designInput = document.getElementById('adminDesignNumberInput');
    var finalDesignId = (designInput && designInput.value) ? designInput.value.trim().toUpperCase() : "02";

    var bypassCb = document.getElementById('adminBypassCloudinary');
    var bypass = bypassCb ? bypassCb.checked : false;

    if (modal) modal.style.display = 'none';

    var p = window.allProducts ? window.allProducts.find(x => x.id === window.tempCamPid) : null;
    if (p && (!p.gridUrl || p.gridUrl.trim() === "" || p.gridUrl.toLowerCase() === "none")) {
        p.gridUrl = "Grid/" + p.cat + "/" + p.name + "/";
        p.zoomUrl = "Zoom/" + p.cat + "/" + p.name + "/";
        var patchUrl = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + window.tempCamDocId + "?updateMask.fieldPaths=gridUrl&updateMask.fieldPaths=zoomUrl";
        fetch(patchUrl, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fields: { gridUrl: { stringValue: p.gridUrl }, zoomUrl: { stringValue: p.zoomUrl } } })
        }).catch(e => console.error("Auto-heal gridUrl failed", e));
    }

    try {
        var outboxId = await window.saveToOutbox(window.tempCamDocId, finalDesignId, window.tempCamPhotoPath, window.tempCamProductName || "", bypass);
        if (outboxId) {
            var toastId = 'undoToast_' + Date.now();
            var toastHtml = `<div id="${toastId}" style="position:fixed; top:70px; left:50%; transform:translateX(-50%); background:#323232; color:#fff; padding:12px 20px; border-radius:4px; font-size:14px; box-shadow:0 3px 10px rgba(0,0,0,0.3); z-index:9999; display:flex; align-items:center; gap:15px;">
                <span>Photo Saved to Outbox.</span>
            </div>`;
            document.body.insertAdjacentHTML('beforeend', toastHtml);

            setTimeout(() => {
                var toastEl = document.getElementById(toastId);
                if (toastEl) toastEl.remove();
                window.processCameraOutbox();
            }, 5000);
        }
    } catch (e) {
        window.logAppError('Confirm Upload', e.message);
    }
};

window.undoOutbox = async function (outboxId, toastId) {
    await window.deleteFromOutbox(outboxId);
    var toastEl = document.getElementById(toastId);
    if (toastEl) toastEl.remove();
    var feedbackHtml = `<div id="deletedToast" style="position:fixed; top:70px; left:50%; transform:translateX(-50%); background:#323232; color:#ff4081; padding:10px 20px; border-radius:4px; font-size:14px; z-index:9999;">Photo Upload Cancelled</div>`;
    document.body.insertAdjacentHTML('beforeend', feedbackHtml);
    setTimeout(() => {
        var el = document.getElementById('deletedToast');
        if (el) el.remove();
    }, 2000);
};

window.processCameraOutbox = async function () {
    if (window.isOutboxSyncing) return;
    window.isOutboxSyncing = true;
    var hasSkippedItems = false;
    try {
        var items = await window.getOutboxItems();
        for (var i = 0; i < items.length; i++) {
            var item = items[i];

            // Time-lock check: skip if still within the 5-second UNDO window
            if (item.processAfter && Date.now() < item.processAfter) {
                hasSkippedItems = true;
                continue;
            }

            var safeName = item.productName ? encodeURIComponent(item.productName) : "NA";
            if (item.bypass) {
                safeName += "___BYPASS";
            }
            var filename = `${item.docId}___${item.designId}___${safeName}___${item.ts}.jpg`;
            try {
                var uploadStartTime = Date.now();
                var fileData = await Capacitor.Plugins.Filesystem.readFile({ path: item.fileUri });
                var res = await fetch(`data:image/jpeg;base64,${fileData.data}`);
                var blob = await res.blob();

                var uploadUrl = `https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o?name=Uploads%2FRaw%2F` + encodeURIComponent(filename);

                var uploadRes = await window.fetchWithRetry(uploadUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'image/jpeg' },
                    body: blob
                }, 1);

                if (uploadRes.ok) {
                    await window.deleteFromOutbox(item.id);
                    var uploadDuration = ((Date.now() - uploadStartTime) / 1000).toFixed(2);
                    var totalJourney = ((Date.now() - item.ts) / 1000).toFixed(2);
                    window.logAppError('Upload Success', `File: ${filename} | Net Time: ${uploadDuration}s | Total Journey: ${totalJourney}s`);
                    console.log(`✅ Successfully uploaded: ${filename} in ${uploadDuration}s`);
                } else {
                    throw new Error(`Status ${uploadRes.status}`);
                }
            } catch (err) {
                window.logAppError('Outbox Uploader', 'Failed to upload ' + filename + ': ' + err.message);
            }
        }
    } catch (e) {
        console.error("Outbox process error", e);
    } finally {
        window.isOutboxSyncing = false;
        // If items were skipped due to time-lock while uploader was active, schedule a sweep
        if (hasSkippedItems) {
            setTimeout(window.processCameraOutbox, 2500);
        }
    }
};












// ==========================================
// 🖨️ NAS PRINT RELAY: HTML-TO-BITMAP TSPL ENGINE
// ==========================================

window.currentPrintType = null;
window.currentPrintCanvas = null;

function previewLabel(type) {
    if (!curProduct) return;
    window.currentPrintType = type;

    var typeLabels = { barcode: '(Barcode)', tag: '(Tag)', sticker: '(Sticker)' };
    document.getElementById('printTypeSpan').innerText = typeLabels[type] || '';

    var stickerContainer = document.getElementById('stickerPreviewContainer');
    var canvasContainer = document.getElementById('printPreviewCanvasContainer');
    var tagEditor = document.getElementById('tagEditorContainer');

    // Reset visibility
    stickerContainer.style.display = 'none';
    canvasContainer.style.display = 'block';
    tagEditor.style.display = 'none';
    window.currentPrintCanvas = null;

    var cdObj = JSON.parse(localStorage.getItem("dsCustomerDetails") || "{}");
    var firmName = cdObj.firm || "DURGA SAREES";

    if (type === 'sticker') {
        // ── LIVE EDITABLE STICKER MODE ─────────────────────────────────────
        stickerContainer.style.display = 'block';
        canvasContainer.style.display = 'none';

        var btnEdit = document.getElementById('btnEditStickerLayout');
        if (btnEdit) {
            btnEdit.style.display = window.isSuperAdmin ? 'block' : 'none';
        }

        if (typeof renderStickerTemplate === 'function') {
            renderStickerTemplate('stickerTemplate', false);
        }

        var prodImg = document.getElementById('img_' + curProduct.id);
        if (prodImg && prodImg.src) {
            var stkProductImg = document.getElementById('stkProductImg');
            if (stkProductImg) stkProductImg.src = prodImg.src;
        }

        // Generate QR code (encodes SKU so it can be scanned)
        var qrEl = document.getElementById('stkQRCode');
        qrEl.innerHTML = '';
        if (window.QRCode) {
            new QRCode(qrEl, {
                text: curProduct.sku || curProduct.name || 'DS',
                width: 100,
                height: 100,
                correctLevel: QRCode.CorrectLevel.M
            });
        }

        loadPrinters();
        openModal('printPreviewModal');
        return;
    }

    if (type === 'barcode') {
        document.getElementById('lbl_bc_firm').innerText = firmName;
        document.getElementById('lbl_bc_name').innerText = curProduct.name;
        document.getElementById('lbl_bc_price').innerText = curProduct.price || '0';
        document.getElementById('lbl_bc_pack').innerText = curProduct.packing || '1';

        var nameEl = document.getElementById('lbl_bc_name');
        nameEl.style.fontSize = '40px';
        if (curProduct.name.length > 20) nameEl.style.fontSize = '30px';
        if (curProduct.name.length > 30) nameEl.style.fontSize = '24px';

        JsBarcode("#lbl_bc_barcode", curProduct.sku || "00000", {
            format: "CODE128", width: 3, height: 100,
            displayValue: true, fontSize: 24, margin: 0
        });
    } else {
        tagEditor.style.display = 'block';

        document.getElementById('editTagDesc1').value = localStorage.getItem("dsTagDesc1") || "";
        document.getElementById('editTagDesc2').value = localStorage.getItem("dsTagDesc2") || "";
        document.getElementById('editTagCut').value = localStorage.getItem("dsTagCut") || "CUT 6 MTR + WTH BLOUSE";

        document.getElementById('lbl_tag_name').innerText = curProduct.name;
        document.getElementById('lbl_tag_desc1').innerText = document.getElementById('editTagDesc1').value;
        document.getElementById('lbl_tag_desc2').innerText = document.getElementById('editTagDesc2').value;
        document.getElementById('lbl_tag_cut').innerText = document.getElementById('editTagCut').value;
        document.getElementById('lbl_tag_sku').innerText = curProduct.sku || "-";

        var nameEl = document.getElementById('lbl_tag_name');
        nameEl.style.fontSize = '52px';
        if (curProduct.name.length > 15) nameEl.style.fontSize = '42px';
        if (curProduct.name.length > 22) nameEl.style.fontSize = '34px';
    }

    // Render barcode/tag via html2canvas
    var tplId = type === 'barcode' ? 'tpl_barcode' : 'tpl_tag';
    var tpl = document.getElementById(tplId);
    canvasContainer.innerHTML = 'Rendering...';

    loadPrinters();
    openModal('printPreviewModal');

    setTimeout(() => {
        html2canvas(tpl, { scale: 1 }).then(canvas => {
            window.currentPrintCanvas = canvas;
            var displayCanvas = document.createElement('canvas');
            var ctx = displayCanvas.getContext('2d');
            displayCanvas.width = canvas.width / 2;
            displayCanvas.height = canvas.height / 2;
            ctx.drawImage(canvas, 0, 0, displayCanvas.width, displayCanvas.height);
            displayCanvas.style.maxWidth = '100%';
            canvasContainer.innerHTML = '';
            canvasContainer.appendChild(displayCanvas);
        });
    }, 100);
}

// Called when typing in the editor inputs to live-update the canvas
function updateLiveLabel() {
    if (window.currentPrintType !== 'tag') return;

    var desc1 = document.getElementById('editTagDesc1').value;
    var desc2 = document.getElementById('editTagDesc2').value;
    var cut = document.getElementById('editTagCut').value;

    // Save defaults
    localStorage.setItem("dsTagDesc1", desc1);
    localStorage.setItem("dsTagDesc2", desc2);
    localStorage.setItem("dsTagCut", cut);

    // Update hidden HTML template
    document.getElementById('lbl_tag_desc1').innerText = desc1;
    document.getElementById('lbl_tag_desc2').innerText = desc2;
    document.getElementById('lbl_tag_cut').innerText = cut;

    // Re-render canvas
    var tpl = document.getElementById('tpl_tag');
    var container = document.getElementById('printPreviewCanvasContainer');

    html2canvas(tpl, { scale: 1 }).then(canvas => {
        window.currentPrintCanvas = canvas;
        var displayCanvas = document.createElement('canvas');
        var ctx = displayCanvas.getContext('2d');
        displayCanvas.width = canvas.width / 2;
        displayCanvas.height = canvas.height / 2;
        ctx.drawImage(canvas, 0, 0, displayCanvas.width, displayCanvas.height);
        displayCanvas.style.maxWidth = '100%';
        container.innerHTML = '';
        container.appendChild(displayCanvas);
    });
}

function confirmPrint() {
    var PRINTER_IP = document.getElementById('printerIpInput').value.trim();
    if (!PRINTER_IP) { alert("Please enter a Printer IP!"); return; }

    var qty = document.getElementById('printQtyInput').value;
    if (!qty || isNaN(qty) || parseInt(qty) < 1) return;

    var btn = document.getElementById('btnPrintConfirm');
    btn.innerText = "Rendering...";
    btn.disabled = true;

    var doSendCanvas = function (canvas) {
        var tsplPayload = generateTSPL(canvas, window.currentPrintType, parseInt(qty));
        var base64Payload = uint8ToBase64(tsplPayload);

        if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TcpSocket) {
            var TcpSocket = window.Capacitor.Plugins.TcpSocket;
            btn.innerText = "Connecting...";
            TcpSocket.connect({ ipAddress: PRINTER_IP, port: 9100 })
                .then(function (res) {
                    btn.innerText = "Sending...";
                    var clientId = res.client;
                    TcpSocket.send({ client: clientId, data: base64Payload, encoding: 'base64' })
                        .then(function () {
                            btn.innerText = "Sent ✅";
                            setTimeout(() => { TcpSocket.disconnect({ client: clientId }); }, 500);
                            setTimeout(() => { closeModals(); btn.innerText = "PRINT"; btn.disabled = false; }, 1500);
                        })
                        .catch(function (err) {
                            btn.innerText = "Send Error";
                            btn.disabled = false;
                            alert("Send failed: " + err.message);
                        });
                })
                .catch(function (err) {
                    btn.innerText = "Connect Error";
                    btn.disabled = false;
                    alert("TCP connect failed: " + err.message);
                });
        } else {
            btn.innerText = "No Printer Plugin";
            btn.disabled = false;
            alert("TcpSocket plugin not available.");
        }
    };

    if (window.currentPrintType === 'sticker') {
        // ── STICKER: render the live contenteditable template ─────────────
        var tpl = document.getElementById('stickerTemplate');

        // Temporarily hide the dashed preview border and focus indicators
        var origBorder = tpl.style.border;
        var origBoxShadow = tpl.style.boxShadow;
        tpl.style.border = 'none';
        tpl.style.boxShadow = 'none';
        // Also hide any active focus underlines on contenteditable fields
        ['stkProduct', 'stkPrice', 'stkDesign', 'stkFabric', 'stkCut'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) el.style.borderBottom = 'none';
        });

        setTimeout(function () {
            html2canvas(tpl, { scale: 2, useCORS: true, backgroundColor: '#ffffff' }).then(function (canvas) {
                // Restore the preview styling
                tpl.style.border = origBorder;
                tpl.style.boxShadow = origBoxShadow;
                window.currentPrintCanvas = canvas;
                doSendCanvas(canvas);
            }).catch(function (err) {
                tpl.style.border = origBorder;
                tpl.style.boxShadow = origBoxShadow;
                btn.innerText = "Render Error";
                btn.disabled = false;
                alert("Could not render sticker: " + err.message);
            });
        }, 50);
    } else {
        // ── BARCODE / TAG: use the pre-rendered canvas ─────────────────────
        if (!window.currentPrintCanvas) { btn.innerText = "PRINT"; btn.disabled = false; return; }
        doSendCanvas(window.currentPrintCanvas);
    }
}

// ==========================================
// MULTI-PRINTER UI LOGIC
// ==========================================
function loadPrinters() {
    var printers = JSON.parse(localStorage.getItem('dsPrinters') || "[]");
    var sel = document.getElementById('printerSelect');
    sel.innerHTML = '<option value="">-- Add New Printer --</option>';

    printers.forEach((p, i) => {
        var opt = document.createElement('option');
        opt.value = i;
        opt.innerText = p.name + " (" + p.ip + ")";
        sel.appendChild(opt);
    });

    // Auto-select the last used IP for this type
    var lastIp = window.currentPrintType === 'barcode' ? localStorage.getItem("dsBarcodePrinterIp") : localStorage.getItem("dsTagPrinterIp");

    if (lastIp) {
        var foundIdx = printers.findIndex(p => p.ip === lastIp);
        if (foundIdx !== -1) {
            sel.value = foundIdx;
            document.getElementById('printerNameInput').value = printers[foundIdx].name;
            document.getElementById('printerIpInput').value = printers[foundIdx].ip;
        } else {
            sel.value = "";
            document.getElementById('printerNameInput').value = "";
            document.getElementById('printerIpInput').value = lastIp;
        }
    } else {
        sel.value = "";
        document.getElementById('printerNameInput').value = "";
        document.getElementById('printerIpInput').value = "";
    }
}

function onPrinterSelectChange() {
    var sel = document.getElementById('printerSelect');
    var printers = JSON.parse(localStorage.getItem('dsPrinters') || "[]");

    if (sel.value === "") {
        document.getElementById('printerNameInput').value = "";
        document.getElementById('printerIpInput').value = "";
    } else {
        var p = printers[sel.value];
        document.getElementById('printerNameInput').value = p.name;
        document.getElementById('printerIpInput').value = p.ip;
    }
}

function savePrinter() {
    var name = document.getElementById('printerNameInput').value.trim();
    var ip = document.getElementById('printerIpInput').value.trim();

    if (!name || !ip) {
        alert("Please enter both Name and IP Address!");
        return;
    }

    var printers = JSON.parse(localStorage.getItem('dsPrinters') || "[]");
    var sel = document.getElementById('printerSelect');

    if (sel.value === "") {
        // Add new
        printers.push({ name: name, ip: ip });
    } else {
        // Update existing
        printers[sel.value] = { name: name, ip: ip };
    }

    localStorage.setItem('dsPrinters', JSON.stringify(printers));

    // Set as default for this type
    if (window.currentPrintType === 'barcode') localStorage.setItem("dsBarcodePrinterIp", ip);
    else localStorage.setItem("dsTagPrinterIp", ip);

    loadPrinters();
    alert("Printer saved!");
}

function deletePrinter() {
    var sel = document.getElementById('printerSelect');
    if (sel.value === "") return;

    if (!confirm("Delete this printer?")) return;

    var printers = JSON.parse(localStorage.getItem('dsPrinters') || "[]");
    printers.splice(sel.value, 1);
    localStorage.setItem('dsPrinters', JSON.stringify(printers));
    loadPrinters();
}

function generateTSPL(canvas, type, qty) {
    var ctx = canvas.getContext('2d');
    var w = canvas.width;
    var h = canvas.height;
    var imgData = ctx.getImageData(0, 0, w, h).data;

    var widthBytes = Math.ceil(w / 8);
    var bitmapLength = widthBytes * h;
    var bitmapData = new Uint8Array(bitmapLength);

    // Floyd-Steinberg or simple thresholding to 1-bit monochrome
    for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
            var i = (y * w + x) * 4;

            var r = imgData[i];
            var g = imgData[i + 1];
            var b = imgData[i + 2];
            var a = imgData[i + 3];

            // Treat transparent pixels as white (background)
            if (a < 128) {
                r = 255; g = 255; b = 255;
            }

            // RGB to Grayscale
            var gray = (r * 0.299 + g * 0.587 + b * 0.114);
            var isBlack = gray < 128; // Simple threshold

            if (isBlack) {
                var byteIndex = (y * widthBytes) + Math.floor(x / 8);
                var bitIndex = 7 - (x % 8);
                bitmapData[byteIndex] |= (1 << bitIndex);
            }
        }
    }

    // TSPL Commands
    var headerStr = "";
    if (type === 'barcode') {
        headerStr += "SIZE 72 mm, 48 mm\n";
        headerStr += "GAP 3 mm, 0 mm\n";
    } else {
        headerStr += "SIZE 78 mm, 57 mm\n";
        headerStr += "GAP 0 mm, 0 mm\n"; // Continuous tearable
    }
    headerStr += "DIRECTION 0\n";
    headerStr += "CLS\n";

    // BITMAP X,Y,width_bytes,height,mode,bitmap_data
    var bitmapCmdStr = "BITMAP 0,0," + widthBytes + "," + h + ",0,";

    var footerStr = "\nPRINT " + (qty || 1) + "\n";

    var headerBytes = new TextEncoder().encode(headerStr + bitmapCmdStr);
    var footerBytes = new TextEncoder().encode(footerStr);

    var finalPayload = new Uint8Array(headerBytes.length + bitmapData.length + footerBytes.length);
    finalPayload.set(headerBytes, 0);
    finalPayload.set(bitmapData, headerBytes.length);
    finalPayload.set(footerBytes, headerBytes.length + bitmapData.length);

    return finalPayload;
}

function uint8ToBase64(u8Arr) {
    var CHUNK_SIZE = 0x8000;
    var index = 0;
    var length = u8Arr.length;
    var result = '';
    var slice;
    while (index < length) {
        slice = u8Arr.subarray(index, Math.min(index + CHUNK_SIZE, length));
        result += String.fromCharCode.apply(null, slice);
        index += CHUNK_SIZE;
    }
    return btoa(result);
}


// Force status bar icons to be dark on startup
document.addEventListener('DOMContentLoaded', () => {
    if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.StatusBar) {
        window.Capacitor.Plugins.StatusBar.setStyle({ style: 'LIGHT' }).catch(e => console.log('StatusBar error:', e));
    }
});

// Deep Link Native Handling
window.pendingDeepLinkPid = null;
if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App) {
    window.Capacitor.Plugins.App.addListener('appUrlOpen', data => {
        if (data.url) {
            try {
                let urlObj = new URL(data.url);
                let pid = urlObj.searchParams.get('pid');
                if (pid) {
                    if (typeof allProducts !== 'undefined' && allProducts.length > 0 && typeof openDetail === 'function') {
                        openDetail(pid);
                    } else {
                        window.pendingDeepLinkPid = pid;
                    }
                }
            } catch (e) { }
        }
    });
}


window.promptRenameDesign = async function (docId, pid, oldDesignId, imgUrl) {
    if (!window.isAdminMode) return;
    var p = allProducts.find(x => x.id === pid);
    if (!p) return;

    var newDesignId = prompt("Enter new design number to rename '" + oldDesignId + "' to:", oldDesignId);
    if (!newDesignId || newDesignId.trim() === "" || newDesignId.trim() === oldDesignId) return;
    newDesignId = newDesignId.trim().toUpperCase();

    if (!imgUrl) {
        alert("Error: Could not find image URL to rename.");
        return;
    }

    document.body.insertAdjacentHTML('beforeend', '<div id="renamingLoader" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);color:#fff;display:flex;align-items:center;justify-content:center;z-index:9999;font-size:20px;font-weight:bold;">Renaming ' + oldDesignId + ' to ' + newDesignId + '...</div>');

    try {
        var folders = [];
        if (p.gridUrl && p.gridUrl.toLowerCase() !== "none") {
            folders.push(p.gridUrl);
            folders.push(p.gridUrl.replace(/\/?Grid\/?/i, "/Jpg/").replace(/^\//, ""));
            folders.push(p.gridUrl.replace(/\/?Grid\/?/i, "/Input/").replace(/^\//, ""));
        }
        if (p.zoomUrl && p.zoomUrl.toLowerCase() !== "none") {
            folders.push(p.zoomUrl);
        }

        folders = [...new Set(folders)];

        var uploadPromises = folders.map(async (folderPath) => {
            var cleanFolder = String(folderPath).trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');

            // Try .webp first
            var oldFileName = encodeURIComponent(oldDesignId + ".webp");
            var oldFileUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + cleanFolder + "%2F" + oldFileName + "?alt=media";
            var res = await fetch(oldFileUrl);
            var ext = ".webp";
            var type = "image/webp";

            if (!res.ok) {
                // Try .jpg
                oldFileName = encodeURIComponent(oldDesignId + ".jpg");
                oldFileUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + cleanFolder + "%2F" + oldFileName + "?alt=media";
                res = await fetch(oldFileUrl);
                ext = ".jpg";
                type = "image/jpeg";
            }

            if (!res.ok) return; // File not found in this folder, skip

            var blob = await res.blob();
            var newFileName = encodeURIComponent(newDesignId + ext);
            var destUploadUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o?name=" + cleanFolder + "%2F" + newFileName;
            var delUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + cleanFolder + "%2F" + oldFileName;

            await window.fetchWithRetry(destUploadUrl, {
                method: 'POST',
                headers: { 'Content-Type': type },
                body: blob
            }, 1);

            await window.fetchWithRetry(delUrl, { method: 'DELETE' }, 1).catch(e => console.log("Failed to delete", delUrl));

            // Clean up any accidental .jpg copies made during previous buggy version if this was a .webp
            if (ext === ".webp" && folderPath !== "Uploads/Raw") {
                var accidentalJpg = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + cleanFolder + "%2F" + encodeURIComponent(newDesignId + ".jpg");
                window.fetchWithRetry(accidentalJpg, { method: 'DELETE' }, 1).catch(() => { });
            }
        });

        await Promise.all(uploadPromises);

        var curStock = p.stock && p.stock[oldDesignId] !== undefined ? p.stock[oldDesignId] : 999;

        // Add both old and new fields to updateMask. Omitting the old field from 'fields' will delete it.
        var isCoverRenamed = false;
        var cleanCoverId = p.coverDesignId ? String(p.coverDesignId).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase() : '';
        var cleanOldDesignId = String(oldDesignId).replace(/\.(webp|jpg|jpeg|png)$/i, '').toLowerCase();
        if (cleanCoverId !== '' && cleanCoverId === cleanOldDesignId) {
            isCoverRenamed = true;
        }

        var fsUrl = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + docId + "?updateMask.fieldPaths=stock.%60" + encodeURIComponent(newDesignId) + "%60&updateMask.fieldPaths=stock.%60" + encodeURIComponent(oldDesignId) + "%60&updateMask.fieldPaths=updateTime";
        if (isCoverRenamed) fsUrl += "&updateMask.fieldPaths=coverDesignId";

        var payloadFields = {
            stock: {
                mapValue: {
                    fields: {
                        [newDesignId]: { integerValue: curStock }
                    }
                }
            },
            updateTime: { timestampValue: new Date().toISOString() }
        };
        if (isCoverRenamed) {
            payloadFields.coverDesignId = { stringValue: newDesignId };
            p.coverDesignId = newDesignId; // Update locally
        }

        var fsRes = await window.fetchWithRetry(fsUrl, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fields: payloadFields })
        }, 3);

        if (!fsRes.ok) throw new Error("Failed to update Firestore stock");

        // Update active shopping cart to prevent ghost references
        var oldCartKey = p.id + '_' + oldDesignId;
        if (cart[oldCartKey]) {
            var cartItem = cart[oldCartKey];
            cartItem.design = newDesignId;
            cart[p.id + '_' + newDesignId] = cartItem;
            delete cart[oldCartKey];
            try { localStorage.setItem("dsCart", JSON.stringify(cart)); } catch (e) { }
            if (typeof updateCartHeader === 'function') updateCartHeader();
        }

        alert("Successfully renamed design " + oldDesignId + " to " + newDesignId + "!");
        if (typeof applyFilter === 'function') applyFilter();
    } catch (e) {
        alert("Error renaming design: " + e.message);
    } finally {
        var ldr = document.getElementById('renamingLoader');
        if (ldr) ldr.remove();
    }
};

window.promptSetAsCover = async function (docId, pid, designId) {
    if (!confirm("Are you sure you want to set " + designId + " as the new cover image?")) {
        return;
    }

    var p = allProducts.find(x => x.docId === docId);
    if (!p) {
        alert("Error: Could not find product.");
        return;
    }

    document.body.insertAdjacentHTML('beforeend', '<div id="coverLoader" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);color:#fff;display:flex;align-items:center;justify-content:center;z-index:9999;font-size:20px;font-weight:bold;">Setting ' + designId + ' as Cover...</div>');

    var oldCoverId = p.coverDesignId;
    // Optimistic UI Update
    p.coverDesignId = designId;

    try {
        var fsUrl = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products/" + docId + "?updateMask.fieldPaths=updateTime&updateMask.fieldPaths=coverDesignId";
        var fsRes = await window.fetchWithRetry(fsUrl, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                fields: {
                    coverDesignId: { stringValue: designId },
                    updateTime: { timestampValue: new Date().toISOString() }
                }
            })
        }, 3);

        if (!fsRes.ok) throw new Error("Failed to update Firestore");

        // Clear local cache for this cover image
        if (window.coverExistsMap) {
            window.coverExistsMap[p.gridUrl] = true;
            if (typeof window.saveCoverExistsMap === 'function') window.saveCoverExistsMap();
        }
        if (window.dsFallbackMap) {
            delete window.dsFallbackMap[p.gridUrl];
            if (typeof window.saveFallbackMap === 'function') window.saveFallbackMap();
        }
        if (window.dsCoverTimeCache) {
            delete window.dsCoverTimeCache[p.gridUrl];
            try { localStorage.setItem("dsCoverTimeCache", JSON.stringify(window.dsCoverTimeCache)); } catch (e) { }
        }

        if (typeof window.deleteImageFromDB === 'function') {
            await window.deleteImageFromDB(p.gridUrl);
        } else if (typeof deleteImageFromDB === 'function') {
            await deleteImageFromDB(p.gridUrl);
        }

        alert("Successfully set " + designId + " as the new cover!");

        // Refresh the UI
        if (typeof applyFilter === 'function') applyFilter();

    } catch (e) {
        // Optimistic Revert
        p.coverDesignId = oldCoverId;
        if (typeof applyFilter === 'function') applyFilter();
        alert("Error setting cover: " + e.message + ". Reverted to previous cover.");
    } finally {
        var ldr = document.getElementById('coverLoader');
        if (ldr) ldr.remove();
    }
};

window.shareWhatsAppLink = async function () {
    if (!curProduct) return;
    var link = "https://durga-sarees.web.app/?pid=" + encodeURIComponent(curProduct.docId || curProduct.id);

    var details = [];

    var readyCount = 0;
    if (curProduct.stock) {
        for (var k in curProduct.stock) {
            if (curProduct.stock[k] > 0) readyCount++;
        }
    } else if (curProduct.ready) {
        readyCount = curProduct.ready.split(',').filter(s => s.trim().length > 0).length;
    }

    if (readyCount > 0) {
        details.push(`Designs : *${readyCount}*`);
    }

    if (curProduct.mult) {
        details.push(`Colours : ${curProduct.mult} Selected Colour Matching`);
        details.push("");
    }

    var fabricJari = [];
    if (curProduct.fabric && curProduct.fabric !== "None") fabricJari.push(curProduct.fabric);
    if (curProduct.jari && curProduct.jari !== "None") fabricJari.push(curProduct.jari);
    if (fabricJari.length > 0) {
        details.push(`Fabric : ${fabricJari.join(' & ')}`);
        details.push("");
    }

    if (curProduct.border && curProduct.border !== "None") {
        details.push(`Border : ${curProduct.border}`);
        details.push("");
    }

    if (curProduct.blouse && curProduct.blouse !== "None") {
        details.push(`Blouse : ${curProduct.blouse}`);
        details.push("");
    }

    if (curProduct.pallu && curProduct.pallu !== "None") {
        details.push(`Pallu : ${curProduct.pallu}`);
        details.push("");
    }

    if (curProduct.work && curProduct.work !== "None") {
        details.push(`Work : ${curProduct.work}`);
        details.push("");
    }

    if (curProduct.cut && curProduct.cut !== "None") {
        details.push(`Cut : ${curProduct.cut}`);
        details.push("");
    }

    details.push(`Check Ready Stock Designs here`);
    details.push(link);
    details.push("");

    details.push(`Special Price`);
    var pricePacking = [];
    if (curProduct.price) pricePacking.push(`${curProduct.price}/-`);
    if (curProduct.packing && curProduct.packing !== "None") pricePacking.push(curProduct.packing);
    if (pricePacking.length > 0) details.push(`*${pricePacking.join(' ')}*`);

    details.push("");
    details.push("**Limited Stock");
    details.push("");
    details.push("Thank You,");
    details.push("*Durga Sarees, Surat*");

    var textMsg = `*${curProduct.name}*\n\n` + details.join("\n");

    if (window.Capacitor && window.Capacitor.isNativePlatform() && window.Capacitor.Plugins.Share && window.Capacitor.Plugins.Filesystem) {
        document.body.insertAdjacentHTML('beforeend', '<div id="shareLoader" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);color:#fff;display:flex;align-items:center;justify-content:center;z-index:9999;font-size:20px;font-weight:bold;">Preparing HD Image...</div>');

        try {
            var coverSrc = "";

            // 1. Prioritize the currently open zoom image if Fullscreen modal is active
            var fsModal = document.getElementById('fsModal');
            var fsImg = document.getElementById('fsImg');
            if (fsModal && fsModal.style.display === 'flex' && fsImg && fsImg.src && !fsImg.src.endsWith(window.dsMissingImage)) {
                coverSrc = fsImg.getAttribute('data-zoom-url') || fsImg.src;
            }

            // 2. Or grab the first HD zoom image from the Product Details gallery
            if (!coverSrc) {
                var firstDesignImg = document.getElementById("design_img_" + curProduct.id + "_0");
                if (firstDesignImg && firstDesignImg.getAttribute('data-zoom-url')) {
                    coverSrc = firstDesignImg.getAttribute('data-zoom-url');
                }
            }

            // 3. Or use the coverDesignId to construct the HD URL directly!
            if (!coverSrc && curProduct.coverDesignId && curProduct.coverDesignId !== "None") {
                var folderPath = (curProduct.zoomUrl && curProduct.zoomUrl !== "None") ? curProduct.zoomUrl : curProduct.gridUrl;
                var encPath = folderPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
                coverSrc = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + encPath + "%2F" + encodeURIComponent(curProduct.coverDesignId) + "?alt=media";
            }

            // 4. Last resort: We must list the directory to find a design image
            if (!coverSrc) {
                var folderPath = (curProduct.zoomUrl && curProduct.zoomUrl !== "None") ? curProduct.zoomUrl : curProduct.gridUrl;
                var listPrefix = folderPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('/') + '/';
                var listUrl = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o?prefix=" + listPrefix + "&delimiter=/";
                var listRes = await fetch(listUrl);
                if (listRes.ok) {
                    var data = await listRes.json();
                    var items = data.items || [];
                    if (items.length > 0) {
                        var fileNames = items.map(item => item.name.substring(item.name.lastIndexOf('/') + 1)).filter(f => /\.(webp|jpg|jpeg|png)$/i.test(f));
                        if (fileNames.length > 0) {
                            var encPath = folderPath.trim().replace(/\\/g, '/').split('/').filter(Boolean).map(s => encodeURIComponent(s.trim())).join('%2F');
                            coverSrc = "https://firebasestorage.googleapis.com/v0/b/durga-sarees.firebasestorage.app/o/" + encPath + "%2F" + encodeURIComponent(fileNames[0]) + "?alt=media";
                        }
                    }
                }
            }

            if (!coverSrc) {
                throw new Error("No image found to share");
            }

            var base64data = "";
            if (coverSrc.startsWith("data:")) {
                base64data = coverSrc;
            } else {
                var blob = null;
                if (typeof window.getImageFromDB === 'function') {
                    blob = await window.getImageFromDB(coverSrc);
                }
                if (!blob) {
                    var res = await fetch(coverSrc);
                    blob = await res.blob();
                }
                base64data = await new Promise((resolve) => {
                    var reader = new FileReader();
                    reader.readAsDataURL(blob);
                    reader.onloadend = () => resolve(reader.result);
                });
            }

            var pathName = "share_" + Date.now() + ".jpg";
            var writeRes = await window.Capacitor.Plugins.Filesystem.writeFile({
                path: pathName,
                data: base64data,
                directory: 'CACHE'
            });

            await window.Capacitor.Plugins.Share.share({
                title: curProduct.name,
                text: textMsg,
                files: [writeRes.uri]
            });

        } catch (e) {
            console.error("Share error:", e);
            window.location.href = "https://wa.me/?text=" + encodeURIComponent(textMsg);
        } finally {
            var ldr = document.getElementById('shareLoader');
            if (ldr) ldr.remove();
        }
    } else {
        window.open("https://wa.me/?text=" + encodeURIComponent(textMsg), '_blank');
    }
};

window.openLiveAdmin = function () {
    openModal('adminLiveModal');
    var contentEl = document.getElementById('adminLiveContent');
    contentEl.innerHTML = '<div style="text-align:center; color:#666; padding:20px;">Fetching live activity...</div>';

    if (window.liveAdminInterval) clearInterval(window.liveAdminInterval);

    function parseFirestoreRest(fields) {
        if (!fields) return {};
        let result = {};
        for (let key in fields) {
            let type = Object.keys(fields[key])[0];
            let val = fields[key][type];
            if (type === 'timestampValue') {
                result[key] = { toDate: () => new Date(val) };
            } else if (type === 'integerValue') {
                result[key] = parseInt(val, 10);
            } else if (type === 'doubleValue') {
                result[key] = parseFloat(val);
            } else if (type === 'mapValue') {
                result[key] = parseFirestoreRest(val.fields || {});
            } else if (type === 'arrayValue') {
                result[key] = (val.values || []).map(v => {
                    let vType = Object.keys(v)[0];
                    if (vType === 'mapValue') return parseFirestoreRest(v[vType].fields || {});
                    if (vType === 'stringValue') return v[vType];
                    if (vType === 'integerValue') return parseInt(v[vType], 10);
                    return v[vType];
                });
            } else {
                result[key] = val;
            }
        }
        return result;
    }

    function fetchLiveData() {
        if (document.getElementById('adminLiveModal').style.display === 'none') {
            clearInterval(window.liveAdminInterval);
            return;
        }

        let limitDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        let url = "https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents:runQuery";
        let queryPayload = {
            structuredQuery: {
                from: [{ collectionId: "LiveSessions" }],
                where: {
                    fieldFilter: {
                        field: { fieldPath: "lastActive" },
                        op: "GREATER_THAN_OR_EQUAL",
                        value: { timestampValue: limitDate.toISOString() }
                    }
                },
                orderBy: [{ field: { fieldPath: "lastActive" }, direction: "DESCENDING" }],
                limit: 1000
            }
        };

        window.fetchWithRetry(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(queryPayload)
        })
            .then(res => res.json())
            .then(snapshot => {
                if (snapshot.error && snapshot.error.length > 0) throw new Error(snapshot.error[0].message || snapshot.error.message);
                if (snapshot.error) throw new Error(snapshot.error.message);

                contentEl.innerHTML = '';
                let hasLive = false;

                let sortedDocs = [];
                let docs = snapshot || [];
                docs.forEach(resItem => {
                    try {
                        let doc = resItem.document;
                        if (!doc || !doc.fields) return;
                        let d = parseFirestoreRest(doc.fields);
                        if (!d.lastActive || typeof d.lastActive.toDate !== 'function' || d.lastActive.toDate() < limitDate) return;
                        sortedDocs.push({ id: doc.name.split('/').pop(), data: d, time: d.lastActive.toDate() });
                    } catch (e) {
                        console.error("Error parsing live doc:", e);
                    }
                });
                sortedDocs.sort((a, b) => b.time - a.time);

                sortedDocs.forEach(item => {
                    hasLive = true;
                    let d = item.data;
                    let docId = item.id;
                    let isGuest = docId.startsWith('guest_');

                    let isLiveNow = d.lastActive && (Date.now() - d.lastActive.toDate().getTime() < 60000); // 1 minute strict
                    let lastSeenStr = d.lastActive ? d.lastActive.toDate().toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true }) : "Unknown";
                    let statusBadge = isLiveNow
                        ? `<span style="background:#4caf50; color:white; padding:4px 8px; border-radius:12px; font-size:10px; font-weight:bold;">🟢 Live Now</span>`
                        : `<span style="background:#9e9e9e; color:white; padding:4px 8px; border-radius:12px; font-size:10px; font-weight:bold;">🕒 Last seen: ${lastSeenStr}</span>`;

                    let actionsHtml = isGuest
                        ? `<span style="background:#e0e0e0; color:#555; padding:6px 12px; border-radius:4px; font-size:12px; font-weight:bold;">Guest Visitor</span>`
                        : `<div style="display:flex; gap:8px;">
                             <a href="tel:${docId}" style="background:#1976d2; color:white; padding:6px 12px; border-radius:4px; text-decoration:none; font-size:14px;"><i class="fas fa-phone"></i> Call</a>
                             <a href="https://wa.me/${docId.replace(/\D/g, '')}" target="_blank" style="background:#25D366; color:white; padding:6px 12px; border-radius:4px; text-decoration:none; font-size:14px;"><i class="fab fa-whatsapp"></i> WA</a>
                           </div>`;

                    let viewingProduct = 'None';
                    if (d.currentProduct) {
                        let p = allProducts.find(x => x.id === d.currentProduct || x.docId === d.currentProduct);
                        viewingProduct = p ? p.name : d.currentProduct;
                    }

                    let historyHtml = '';
                    if (d.historyMap && Object.keys(d.historyMap).length > 0) {
                        let sortedDates = Object.keys(d.historyMap).sort().reverse();
                        let visibleHtml = '';
                        let hiddenHtml = '';
                        let hiddenCount = 0;
                        let dateIndex = 0;

                        sortedDates.forEach(date => {
                            // Convert YYYY-MM-DD to DD/MM
                            let dateParts = date.split('-');
                            let shortDate = dateParts.length === 3 ? `${dateParts[2]}/${dateParts[1]}` : date;

                            for (let prodName in d.historyMap[date]) {
                                let mins = parseFloat(d.historyMap[date][prodName]);
                                let timeStr = mins < 1 ? Math.round(mins * 60) + "s" : Math.floor(mins) + "m " + Math.round((mins % 1) * 60) + "s";

                                let entryHtml = `<div style="font-size:12px; color:#333; margin-left:4px; margin-top:2px;">&bull; <span style="color:#777; font-size:11px;">[${shortDate}]</span> ${prodName} (${timeStr})</div>`;

                                if (dateIndex < 2) {
                                    visibleHtml += entryHtml;
                                } else {
                                    hiddenHtml += entryHtml;
                                    hiddenCount++;
                                }
                            }
                            dateIndex++;
                        });

                        historyHtml = visibleHtml;
                        if (hiddenCount > 0) {
                            historyHtml += `<details><summary style="font-size:12px; color:var(--primary); cursor:pointer; margin-top:6px; font-weight:bold; outline:none;">Show Older History (${hiddenCount} items)</summary>`;
                            historyHtml += hiddenHtml;
                            historyHtml += `</details>`;
                        }
                    } else if (d.recentHistory && d.recentHistory.length) {
                        historyHtml = `<div style="font-size:12px; color:#555; margin-top:4px;"><b>Recent:</b> ${d.recentHistory.join(', ')}</div>`;
                    }

                    let namePortion = (d.customerName && d.customerName !== "Guest") ? d.customerName : (isGuest ? "Guest" : docId);
                    let stationPortion = (d.customerStation && d.customerStation !== "Unknown") ? ' - ' + d.customerStation : '';
                    let dispName = namePortion + stationPortion;

                    if (!window.adminCustomerCache) window.adminCustomerCache = {};
                    if (dispName === docId && !window.adminCustomerCache[docId] && !isGuest) {
                        window.adminCustomerCache[docId] = "fetching";
                        fetch("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Users/" + docId)
                            .then(res => res.json())
                            .then(uDoc => {
                                if (uDoc && uDoc.fields) {
                                    let f = uDoc.fields;
                                    let uName = f.name ? f.name.stringValue : "";
                                    let uStation = f.station ? f.station.stringValue : "";
                                    window.adminCustomerCache[docId] = uName ? (uName + (uStation ? ' - ' + uStation : '')) : docId;
                                    let safeId = docId.replace(/\+/g, '');
                                    let el = document.getElementById('admin_name_' + safeId);
                                    if (el) el.innerText = window.adminCustomerCache[docId];
                                    let subEl = document.getElementById('admin_sub_' + safeId);
                                    if (subEl && window.adminCustomerCache[docId] !== docId) {
                                        subEl.innerHTML = `<span style="font-size:12px; color:#888;">${docId}</span>`;
                                    }
                                }
                            }).catch(() => { });
                    } else if (window.adminCustomerCache[docId] && window.adminCustomerCache[docId] !== "fetching") {
                        dispName = window.adminCustomerCache[docId];
                    }

                    let safeDocId = docId.replace(/\+/g, '');
                    let html = `<div style="background:white; border-radius:8px; padding:15px; box-shadow:0 2px 5px rgba(0,0,0,0.1); border-left:4px solid ${isLiveNow ? '#4caf50' : '#9e9e9e'};">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
                            <div style="display:flex; flex-direction:column; gap:4px;">
                                <span id="admin_name_${safeDocId}" style="font-weight:bold; font-size:16px;">${dispName}</span>
                                ${statusBadge}
                                <span id="admin_sub_${safeDocId}"></span>
                            </div>
                            ${actionsHtml}
                        </div>
                        <div style="font-size:14px; margin-bottom:4px; color:#333;"><b>Viewing:</b> ${viewingProduct}</div>
                        ${historyHtml}
                        ${(d.cartSummary && d.cartSummary.length) ? `<div style="font-size:12px; color:#333; margin-top:4px; border-top:1px dashed #ccc; padding-top:4px;"><b>Cart:</b><br>${d.cartSummary.join('<br>')}</div>` : ''}
                    </div>`;
                    contentEl.insertAdjacentHTML('beforeend', html);
                });
                if (!hasLive) {
                    contentEl.innerHTML = '<div style="text-align:center; color:#666; padding:20px;">No live customers in the last 30 days.</div>';
                }
            })
            .catch(err => {
                console.error("LiveSessions Fetch Error:", err);
                contentEl.innerHTML = '<div style="color:red; padding:20px;">Error fetching live data: ' + err.message + '</div>';
            });
    }

    fetchLiveData();
    window.liveAdminInterval = setInterval(fetchLiveData, 15000);
};

window.closeLiveAdmin = function () {
    closeModals();
    if (typeof window.liveAdminUnsubscribe === 'function') {
        window.liveAdminUnsubscribe();
    }
};

// ====================================
// PRODUCT DETAILS MODAL (VIEW / EDIT)
// ====================================
window.openProductDetailsModal = function (pid, event) {
    if (event) event.stopPropagation();

    var p = allProducts.find(x => x.id === pid);
    if (!p) return;

    var cv = document.getElementById('pdCustomerView');
    var av = document.getElementById('pdAdminView');

    if (window.isAdminMode) {
        cv.style.display = 'none';
        av.style.display = 'flex';

        document.getElementById('editProdId').value = p.id;
        document.getElementById('editProdCat').value = p.cat || '';
        document.getElementById('editProdName').value = p.name || '';
        document.getElementById('editProdPrice').value = p.price || '';
        document.getElementById('editProdSku').value = p.sku || '';
        document.getElementById('editProdPacking').value = p.packing || '';
        document.getElementById('editProdMult').value = p.mult || 1;
        document.getElementById('editProdFabric').value = p.fabric || '';
        document.getElementById('editProdWork').value = p.work || '';
        document.getElementById('editProdJari').value = p.jari || '';
        document.getElementById('editProdPallu').value = p.pallu || '';
        document.getElementById('editProdBorder').value = p.border || '';
        document.getElementById('editProdBlouse').value = p.blouse || '';
        document.getElementById('editProdCut').value = p.cut || '';

    } else {
        av.style.display = 'none';
        cv.style.display = 'flex';

        var fields = [
            { label: 'Category', val: p.cat },
            { label: 'Fabric', val: p.fabric },
            { label: 'Work', val: p.work },
            { label: 'Cut', val: p.cut },
            { label: 'Jari', val: p.jari },
            { label: 'Pallu', val: p.pallu },
            { label: 'Border', val: p.border },
            { label: 'Blouse', val: p.blouse },
            { label: 'Packing', val: p.packing },
            { label: 'SKU', val: p.sku }
        ];

        var html = '';
        fields.forEach(f => {
            if (f.val && String(f.val).trim() !== "") {
                html += `
                <div style="display:flex; justify-content:space-between; padding-bottom:8px; border-bottom:1px solid #f0f0f0;">
                    <span style="color:#666;">${f.label}</span>
                    <span style="font-weight:600; color:#333; text-align:right;">${esc(f.val)}</span>
                </div>`;
            }
        });
        if (html === '') html = '<div style="text-align:center; color:#999;">No detailed specifications available.</div>';

        cv.innerHTML = html;
    }

    if (typeof pushModalState === 'function') {
        pushModalState('productDetailsModal');
    } else {
        document.getElementById('productDetailsModal').style.display = 'flex';
    }
};

window.saveProductDetails = async function () {
    var pid = document.getElementById('editProdId').value;
    var p = allProducts.find(x => x.id === pid);
    if (!p) return;

    var btn = document.getElementById('pdSaveBtn');
    btn.innerText = "Saving...";
    btn.disabled = true;

    var price = document.getElementById('editProdPrice').value.trim();
    var sku = document.getElementById('editProdSku').value.trim();
    var packing = document.getElementById('editProdPacking').value.trim();
    var mult = document.getElementById('editProdMult').value.trim();
    var fabric = document.getElementById('editProdFabric').value.trim();
    var work = document.getElementById('editProdWork').value.trim();
    var jari = document.getElementById('editProdJari').value.trim();
    var pallu = document.getElementById('editProdPallu').value.trim();
    var border = document.getElementById('editProdBorder').value.trim();
    var blouse = document.getElementById('editProdBlouse').value.trim();
    var cut = document.getElementById('editProdCut').value.trim();

    var patchPayload = {
        fields: {
            price: { doubleValue: Number(price || 0) },
            sku: { stringValue: sku },
            packing: { stringValue: packing },
            mult: { doubleValue: Number(mult || 1) },
            fabric: { stringValue: fabric },
            work: { stringValue: work },
            jari: { stringValue: jari },
            pallu: { stringValue: pallu },
            border: { stringValue: border },
            blouse: { stringValue: blouse },
            cut: { stringValue: cut }
        }
    };

    var updateMask = "?updateMask.fieldPaths=price&updateMask.fieldPaths=sku&updateMask.fieldPaths=packing&updateMask.fieldPaths=mult&updateMask.fieldPaths=fabric&updateMask.fieldPaths=work&updateMask.fieldPaths=jari&updateMask.fieldPaths=pallu&updateMask.fieldPaths=border&updateMask.fieldPaths=blouse&updateMask.fieldPaths=cut";

    var url = "https://firestore.googleapis.com/v1/projects/" + firebaseConfig.projectId + "/databases/(default)/documents/Products/" + p.docId + updateMask;

    try {
        var resp = await window.fetchWithRetry(url, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(patchPayload)
        }, 1);

        if (!resp.ok) {
            var err = await resp.text();
            throw new Error(err);
        }

        // 1. Update Local Memory
        p.price = parseFloat(price) || 0;
        p.sku = sku;
        p.packing = packing;
        p.mult = parseFloat(mult) || 1;
        p.fabric = fabric;
        p.work = work;
        p.jari = jari;
        p.pallu = pallu;
        p.border = border;
        p.blouse = blouse;
        p.cut = cut;

        try { localStorage.setItem("dsOfflineProducts", JSON.stringify(window.allProducts)); } catch (e) { }

        // 2. Refresh UI
        refreshCardUI(p.id);
        if (typeof applyFilter === 'function') applyFilter();

        // 3. Sync to Google Apps Script (Webhook)
        if (window.DS_APP_SCRIPT_URL) {
            fetch(window.DS_APP_SCRIPT_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify({
                    action: 'updateProductDetailsFull', // NEW ACTION TO PREVENT CLASH
                    productName: p.name,
                    category: p.cat,
                    price: p.price,
                    sku: p.sku,
                    packing: p.packing,
                    mult: p.mult,
                    fabric: p.fabric,
                    work: p.work,
                    jari: p.jari,
                    pallu: p.pallu,
                    border: p.border,
                    blouse: p.blouse,
                    cut: p.cut
                })
            }).catch(e => console.error("Apps Script Sync Failed", e));
        }

        closeModals();
        alert("Product Details Updated Successfully!");

    } catch (error) {
        alert("Failed to update product: " + error.message);
    } finally {
        btn.innerText = "Save Changes";
        btn.disabled = false;
    }
};
window.isSkuManuallyEdited = false;

window.autoGenerateSku = function () {
    if (window.isSkuManuallyEdited) return;

    var cat = document.getElementById('addProdCat').value || "";
    var name = document.getElementById('addProdName').value || "";
    if (!name) {
        document.getElementById('addProdSku').value = "";
        return;
    }

    var prefix = "S";
    var subCat = "GN";
    var num = String(name).replace(/[^0-9]/g, '');
    if (num === "") {
        var hash = 0;
        for (var i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        num = Math.abs(hash).toString().substring(0, 3);
        if (num.length < 3) num = Math.floor(100 + Math.random() * 900);
    }

    if (cat) {
        var cleanCat = cat.toUpperCase().trim();
        if (cleanCat.indexOf("BLOUSE") > -1) prefix = "B";
        else if (cleanCat.indexOf("SHIRT") > -1) prefix = "SH";
        else if (cleanCat.indexOf("DRESS") > -1) prefix = "D";

        if (cleanCat.indexOf("TOPDYED") > -1 || cleanCat.indexOf("TOP DYED") > -1) subCat = "TD";
        else if (cleanCat.indexOf("PRINT") > -1) subCat = "PR";
        else if (cleanCat.indexOf("DYED") > -1 || cleanCat.indexOf("DYEING") > -1) subCat = "DY";
        else if (cleanCat.indexOf("DIGITAL") > -1) subCat = "DP";
        else if (cleanCat.indexOf("HANDLOOM") > -1) subCat = "HL";
        else if (cleanCat.indexOf("SILK") > -1) subCat = "SK";
        else subCat = cleanCat.substring(0, 2).replace(/[^A-Z]/g, '');
    }

    document.getElementById('addProdSku').value = (prefix + subCat + num).toUpperCase();
};

window.openAddProductModal = function () {
    window.isSkuManuallyEdited = false;
    // Populate categories
    var catSelect = document.getElementById('addProdCat');
    var catSet = new Set();
    window.allProducts.forEach(p => {
        if (p.cat) catSet.add(p.cat);
    });
    var cats = Array.from(catSet).sort();
    var catHtml = '<option value="">Select a Category...</option>';
    cats.forEach(c => {
        catHtml += `<option value="${c}">${c}</option>`;
    });
    catSelect.innerHTML = catHtml;

    // Reset other fields
    document.getElementById('addProdClone').innerHTML = '<option value="">Select a product to clone details...</option>';
    document.getElementById('addProdName').value = '';
    document.getElementById('addProdPrice').value = '';
    document.getElementById('addProdPacking').value = '';
    document.getElementById('addProdMult').value = '1';
    document.getElementById('addProdFabric').value = '';
    document.getElementById('addProdWork').value = '';
    document.getElementById('addProdJari').value = '';
    document.getElementById('addProdPallu').value = '';
    document.getElementById('addProdBorder').value = '';
    document.getElementById('addProdBlouse').value = '';
    document.getElementById('addProdCut').value = '';
    document.getElementById('addProdSku').value = '';

    openModal('addProductModal');
};

window.onAddProdCatChange = function () {
    var cat = document.getElementById('addProdCat').value;
    var cloneSelect = document.getElementById('addProdClone');
    if (!cat) {
        cloneSelect.innerHTML = '<option value="">Select a product to clone details...</option>';
        return;
    }

    var matches = window.allProducts.filter(p => p.cat === cat).sort((a, b) => a.name.localeCompare(b.name));
    var html = '<option value="">(None - Blank Product)</option>';
    matches.forEach(p => {
        html += `<option value="${p.id}">${p.name}</option>`;
    });
    cloneSelect.innerHTML = html;
};

window.onAddProdCloneChange = function () {
    var pid = document.getElementById('addProdClone').value;
    if (!pid) return;

    var p = window.allProducts.find(x => x.id === pid);
    if (p) {
        document.getElementById('addProdPrice').value = p.price || '';
        document.getElementById('addProdPacking').value = p.packing || '';
        document.getElementById('addProdMult').value = p.mult || '1';
        document.getElementById('addProdFabric').value = p.fabric || '';
        document.getElementById('addProdWork').value = p.work || '';
        document.getElementById('addProdJari').value = p.jari || '';
        document.getElementById('addProdPallu').value = p.pallu || '';
        document.getElementById('addProdBorder').value = p.border || '';
        document.getElementById('addProdBlouse').value = p.blouse || '';
        document.getElementById('addProdCut').value = p.cut || '';
        document.getElementById('addProdSku').value = p.sku ? (p.sku + '-NEW') : '';
    }
};

window.submitNewProduct = async function () {
    if (!window.isSuperAdmin) return alert("Access Denied");

    var btn = event.currentTarget;

    var cat = document.getElementById('addProdCat').value.trim();
    var name = document.getElementById('addProdName').value.trim();
    var price = document.getElementById('addProdPrice').value.trim();
    var packing = document.getElementById('addProdPacking').value.trim();
    var mult = document.getElementById('addProdMult').value.trim();
    var fabric = document.getElementById('addProdFabric').value.trim();
    var work = document.getElementById('addProdWork').value.trim();
    var jari = document.getElementById('addProdJari').value.trim();
    var pallu = document.getElementById('addProdPallu').value.trim();
    var border = document.getElementById('addProdBorder').value.trim();
    var blouse = document.getElementById('addProdBlouse').value.trim();
    var cut = document.getElementById('addProdCut').value.trim();
    var sku = document.getElementById('addProdSku').value.trim();

    if (!cat || !name || !price) {
        return alert("Category, Name, and Price are required.");
    }

    var gridUrl = "Grid/" + cat + "/" + name + "/";
    var zoomUrl = "Zoom/" + cat + "/" + name + "/";

    var payload = {
        fields: {
            name: { stringValue: name },
            cat: { stringValue: cat },
            price: { doubleValue: Number(price || 0) },
            packing: { stringValue: packing },
            mult: { doubleValue: Number(mult || 1) },
            fabric: { stringValue: fabric },
            work: { stringValue: work },
            jari: { stringValue: jari },
            pallu: { stringValue: pallu },
            border: { stringValue: border },
            blouse: { stringValue: blouse },
            cut: { stringValue: cut },
            sku: { stringValue: sku },
            gridUrl: { stringValue: gridUrl },
            zoomUrl: { stringValue: zoomUrl },
            stock: { mapValue: { fields: { DIRECT: { integerValue: "999" } } } }
        }
    };

    try {
        btn.innerText = "Creating...";
        btn.disabled = true;

        // 1. Create in Firestore
        var fbRes = await window.fetchWithRetry("https://firestore.googleapis.com/v1/projects/durga-sarees/databases/(default)/documents/Products", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        }, 2);

        if (!fbRes.ok) {
            var fbErr = await fbRes.json();
            throw new Error("Firestore " + fbRes.status + ": " + (fbErr.error ? fbErr.error.message : "Permission Denied. Check Rules."));
        }
        var fbData = await fbRes.json();

        var newDocId = fbData.name.split('/').pop();

        // 2. Transaction Safe: Notify Apps Script Webhook
        if (window.DS_APP_SCRIPT_URL) {
            try {
                await fetch(window.DS_APP_SCRIPT_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify({
                        action: 'createProduct',
                        docId: newDocId,
                        category: cat,
                        name: name,
                        price: parseFloat(price),
                        packing: packing,
                        mult: parseFloat(mult || "1"),
                        fabric: fabric,
                        work: work,
                        jari: jari,
                        pallu: pallu,
                        border: border,
                        blouse: blouse,
                        cut: cut,
                        sku: sku,
                        gridUrl: gridUrl,
                        zoomUrl: zoomUrl
                    })
                });
            } catch (sheetErr) {
                console.error("Sheet sync error (soft fail)", sheetErr);
            }
        }

        // 3. Instant Local UI Update
        var newP = {
            docId: newDocId,
            id: "p_" + Date.now(),
            name: name,
            cat: cat,
            price: parseFloat(price),
            mrp: 0,
            packing: packing,
            mult: parseFloat(mult || "1"),
            fabric: fabric,
            work: work,
            jari: jari,
            pallu: pallu,
            border: border,
            blouse: blouse,
            cut: cut,
            sku: sku,
            gridUrl: gridUrl,
            zoomUrl: zoomUrl,
            stock: { DIRECT: 999 },
            totalStock: 999
        };

        window.allProducts.push(newP);
        window.displayList = [...window.allProducts];

        try { localStorage.setItem("dsOfflineProducts", JSON.stringify(window.allProducts)); } catch (e) { console.error("Failed to update offline storage", e); }

        closeModals();
        alert("Product Created Successfully!");
        if (typeof applyFilter === 'function') applyFilter();

    } catch (e) {
        alert("Failed to create product: " + e.message);
    } finally {
        btn.innerHTML = '<i class="fas fa-save" style="margin-right: 6px;"></i> Create Product';
        btn.disabled = false;
    }
};
